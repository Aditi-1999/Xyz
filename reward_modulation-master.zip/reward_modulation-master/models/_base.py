from torch.optim.lr_scheduler import CyclicLR, ExponentialLR
from models import choose_function, choose_init_function, choose_dropout_function
from pytorch_lightning import LightningModule
from abc import ABC, abstractmethod
from torch.nn import Module
from torch.nn import init, Linear, LSTM, ModuleList, BatchNorm1d, ModuleDict, Embedding, Parameter
from torch.nn.functional import softmax
from typing import Optional
from torch.optim import Adam
import torch


class BaseModel(LightningModule, ABC):

    def __init__(self):
        super(BaseModel, self).__init__()

    def _forward_internal_layers(self, op: torch.Tensor) -> torch.Tensor:
        for layer in self.internal_layers:
            op = layer(op)
            if self.activation_func:
                op = self.activation_func(op)
            op = self.dropout(op)  # Apply dropout if internal layer
        return op

    def _forward_output_layer(self, op: torch.Tensor) -> torch.Tensor:
        op = self.output_layer(op)
        if self.output_activation_func:
            op = self.output_activation_func(op)
        return op

    @abstractmethod
    def forward(self, lstm_inp,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        ...

    @abstractmethod
    def _common_step(self, batch, btype):
        ...

    def training_step(self, batch):
        loss = self._common_step(batch, 'train')
        return loss

    def validation_step(self, batch, batch_idx):
        self._common_step(batch, 'val')

    @abstractmethod
    def predict_step(self, batch, batch_idx):
        ...

    def configure_optimizers(self):
        optimizer = Adam(self.parameters(), lr=self.lr, weight_decay=self.l2weight if self.l2reg else 0)
        if self.cycle_lr:
            lr_scheduler = CyclicLR(optimizer, mode='triangular',
                                    base_lr=self.cycle_config['base_lr'], max_lr=self.cycle_config['max_lr'],
                                    step_size_up=self.cycle_config['step_size'],
                                    step_size_down=self.cycle_config['step_size'],
                                    cycle_momentum=False)
            return {
                'optimizer': optimizer,
                'lr_scheduler': {
                    'scheduler': lr_scheduler,
                    'interval': 'step',
                    'frequency': 1,
                    'name': 'cycle_lr',
                },
            }
        elif self.exp_lr:
            lr_scheduler = ExponentialLR(optimizer, gamma=0.98)
            return {
                'optimizer': optimizer,
                'lr_scheduler': {
                    'scheduler': lr_scheduler,
                    'interval': 'epoch',
                    'frequency': 1,
                    'name': 'exp_lr',
                },
            }
        else:
            return optimizer


class MLP(Module):

    # Applying dropout to input layer is not uncommon (advocated even in the original paper)
    # Applying BN to input layer would correspond to having a "learnable" pre-processing layer
    # Here though, we have categorical features whose interpretation may get affected
    # Applying in later layers corresponds to dropping/BNing on higher level features/concepts
    # If all features are continuous, it would be "more" applicable

    def __init__(self,
                 hidden_sizes: list[int], activation_func: Optional[str],
                 output_size: int, output_activation_func: Optional[str],
                 dropout: float, batch_norm: bool, reg_op: bool,
                 ):
        super(MLP, self).__init__()

        self.activation_func = choose_function(activation_func)
        self.output_activation_func = choose_function(output_activation_func)
        self.dropout = dropout
        self.batch_norm = batch_norm
        self.reg_op = reg_op

        if self.dropout > 0 and self.batch_norm:
            raise Exception("Only one of Dropout and BatchNorm is supported")

        if self.dropout == 0 and not self.batch_norm and self.reg_op:
            raise Exception("Nothing to regularise output with")

        if len(hidden_sizes) == 1:
            assert self.activation_func is None, "If no hidden layers, activation function argument is unused"
            if not self.reg_op:
                assert self.dropout == 0, "If no hidden layers, no dropout is applied"
                assert not self.batch_norm, "If no hidden layers, batch norm is not applied"

        self.internal_layers = ModuleList([])
        for i in range(1, len(hidden_sizes)):
            ip, op = hidden_sizes[i - 1], hidden_sizes[i]
            self.internal_layers.append(Linear(in_features=ip, out_features=op, dtype=torch.double))
        self.output_layer = Linear(in_features=hidden_sizes[-1], out_features=output_size, dtype=torch.double)

        if self.dropout > 0:
            self.dropout_layer = choose_dropout_function(self.activation_func)(self.dropout)
        elif self.batch_norm:
            self.batch_norms = ModuleList([])
            for op in hidden_sizes[1:]:
                self.batch_norms.append(BatchNorm1d(op))
            if self.reg_op:
                self.op_bn = BatchNorm1d(output_size)

    def initialise(self):
        init_function = choose_init_function(self.activation_func)
        for layer in self.internal_layers:
            init_function(layer.weight)
            init.zeros_(layer.bias)
        output_init_function = choose_init_function(self.output_activation_func)
        output_init_function(self.output_layer.weight)
        init.zeros_(self.output_layer.bias)

    def _forward_internal_layers(self, op: torch.Tensor) -> torch.Tensor:
        for i in range(len(self.internal_layers)):
            layer = self.internal_layers[i]
            op = layer(op)

            if self.activation_func:
                op = self.activation_func(op)

            # Apply dropout / batch norm if internal layer
            if self.dropout > 0:
                op = self.dropout_layer(op)
            elif self.batch_norm:
                batch_norm = self.batch_norms[i]
                if len(op.shape) == 3:  # (N, time, features)
                    op = op.permute(0, 2, 1)  # (N, features, time)
                    op = batch_norm(op)  # BN applied at features level
                    op = op.permute(0, 2, 1)  # (N, time, features)
                else:
                    op = batch_norm(op)

        return op

    def _forward_output_layer(self, op: torch.Tensor) -> torch.Tensor:
        op = self.output_layer(op)
        if self.output_activation_func:
            op = self.output_activation_func(op)

        if self.reg_op:  # Regularise the output
            if self.dropout > 0:
                op = self.dropout_layer(op)
            elif self.batch_norm:
                if len(op.shape) == 3:
                    op = op.permute(0, 2, 1)
                    op = self.op_bn(op)
                    op = op.permute(0, 2, 1)
                else:
                    op = self.op_bn(op)

        return op

    def forward(self, x):
        x = self._forward_internal_layers(x)
        x = self._forward_output_layer(x)
        return x


class RNN(Module):

    supported_types = ['lstm',
                       # 'gru', 'peephole_lstm',
                       ]

    def __init__(self,
                 kind: str,
                 input_size: int, hidden_size: int, num_layers: int, bidirectional: bool, dropout: float,
                 num_subjects: int, num_blocks: int,
                 init_config: dict, attn: bool, attn_config: dict,
                 ):
        super(RNN, self).__init__()

        self.hidden_size = hidden_size
        self.bidirectional = bidirectional
        self.output_size = (2 if bidirectional else 1) * self.hidden_size
        self.effective_layers = (2 if bidirectional else 1) * num_layers

        if kind not in self.supported_types:
            raise Exception("Unknown RNN Type")

        if dropout > 0 and num_layers == 1:
            raise Exception("RNN Dropout makes sense only if num of layers are more than 1")

        self.init_size = self.effective_layers * self.hidden_size * 2  # * 2 is for LSTM - h0 and c0
        self.history = LSTM(input_size=input_size, hidden_size=hidden_size,
                            num_layers=num_layers, bidirectional=bidirectional,
                            dropout=dropout, batch_first=True)

        # Learnable Initial State
        init_sub_dim, init_block_dim = init_config.get('sub_dim', 0), init_config.get('block_dim', 0)
        self.init_embeddings = ModuleDict()
        if num_subjects > 2 and init_sub_dim > 0:
            self.init_embeddings['sub_embedding'] = Embedding(num_embeddings=num_subjects, embedding_dim=init_sub_dim)
        if num_blocks > 2 and init_block_dim > 0:
            self.init_embeddings['block_embedding'] = Embedding(num_embeddings=num_blocks, embedding_dim=init_block_dim)

        init_l_dim = init_config.get('learnable_dim', 0)
        self.init_l_dim = init_l_dim
        self.learnable_init = None
        self.init_input_dim = init_sub_dim + init_block_dim + self.init_l_dim

        if self.init_input_dim > 0:
            self.initial_state_network = MLP(
                hidden_sizes=[self.init_input_dim, ], activation_func=None,
                output_size=self.init_size, output_activation_func=None,
                dropout=0, batch_norm=False, reg_op=False
            )

        # Attention
        self.attn = attn
        if self.attn:
            attn_sub_dim, attn_block_dim = attn_config.get('sub_dim', 0), attn_config.get('block_dim', 0)
            self.attn_embeddings = ModuleDict()
            if num_subjects > 2 and attn_sub_dim > 0:
                self.attn_embeddings['sub_embedding'] = Embedding(num_embeddings=num_subjects, embedding_dim=attn_sub_dim)
            if num_blocks > 2 and attn_block_dim > 0:
                self.attn_embeddings['block_embedding'] = Embedding(num_embeddings=num_blocks, embedding_dim=attn_block_dim)
            self.attention_layer = MLP(
                hidden_sizes=[self.output_size + attn_sub_dim + attn_block_dim, ], activation_func=None,
                output_size=1, output_activation_func=None,
                dropout=0, batch_norm=False, reg_op=False
            )
        else:
            assert not attn_config, "If no attn, attn_config should be empty"

    def initialise(self):
        for name, param in self.history.named_parameters():
            if 'weight_ih' in name:
                init.xavier_uniform_(param)
            elif 'weight_hh' in name:
                init.orthogonal_(param)
            elif 'bias_ih' in name:
                init.zeros_(param)
            elif 'bias_hh' in name:
                initial_bias_data = [0] * self.hidden_size + [1] * self.hidden_size + [0] * self.hidden_size * 2
                param.data = torch.tensor(initial_bias_data, dtype=torch.double)

        for embedding in self.init_embeddings.values():
            init.uniform_(embedding.weight, -0.05, 0.05)

        if self.init_l_dim > 0:
            l_dim_data = torch.empty((1, self.init_l_dim))
            init.xavier_uniform_(l_dim_data)
            self.learnable_init = Parameter(l_dim_data, requires_grad=True)

        if self.init_input_dim > 0:
            self.initial_state_network.initialise()

        if self.attn:
            for embedding in self.attn_embeddings.values():
                init.uniform_(embedding.weight, -0.05, 0.05)

            self.attention_layer.initialise()
            attn_init_function = choose_init_function(torch.sigmoid)
            attn_init_function(self.attention_layer.output_layer.weight)

    def forward(self, x,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        N = x.shape[0]
        T = x.shape[1]

        # Learnable Init State
        init_state_inputs = []
        if self.learnable_init:
            init_state_inputs.append(self.learnable_init.repeat(N, 1))
        if 'sub_embedding' in self.init_embeddings:
            sub_embed = self.init_embeddings['sub_embedding'](sub_emb)
            init_state_inputs.append(sub_embed)
        if 'block_embedding' in self.init_embeddings:
            block_embed = self.init_embeddings['block_embedding'](block_emb)
            init_state_inputs.append(block_embed)

        if init_state_inputs:
            init_state_input = torch.concat(init_state_inputs, dim=1)  # (N, L+Sb+B)
            raw_initial_state = self.initial_state_network(init_state_input)
            initial_state = raw_initial_state.reshape(N, self.effective_layers, self.hidden_size * 2).transpose(0, 1)
            h_0 = initial_state[:, :, :self.hidden_size].contiguous()
            c_0 = initial_state[:, :, self.hidden_size:].contiguous()
            init_state = (h_0, c_0)
        else:
            init_state = None

        # out is of shape (N, T, D*H) from the last *layer* of the LSTM
        out, (h, c) = self.history(x, init_state)

        if self.attn:  # Get attention modulated summary vector

            attn_inputs = [out]

            sub_emb = sub_emb.view((-1, 1)).repeat((1, T))  # (N, T)
            block_emb = block_emb.view((-1, 1)).repeat((1, T))  # (N, T)

            if 'sub_embedding' in self.attn_embeddings:
                sub_embed = self.attn_embeddings['sub_embedding'](sub_emb)  # (N, T, Sb)
                attn_inputs.append(sub_embed)
            if 'block_embedding' in self.attn_embeddings:
                block_embed = self.attn_embeddings['block_embedding'](block_emb)  # (N, T, B)
                attn_inputs.append(block_embed)

            attn_input = torch.concat(attn_inputs, dim=2)  # (N, T, D*H+Sb+B)
            raw_attention = self.attention_layer(attn_input)  # (N, T, 1)
            attention = softmax(raw_attention, dim=1)  # (N, T, 1)
            modulated = out * attention  # (N, T, D*H)
            convex_combination = modulated.sum(dim=1)  # (N, D*H) - add across time
            return convex_combination  # (N, D*H)

        else:  # Get last cell output

            if self.bidirectional:
                last_layer_outputs = h[-2:, :, :]
                return last_layer_outputs.transpose(0, 1).reshape(N, -1)  # (N, 2*H)
            else:
                return h[-1, :, :]  # (N, H)
