import argparse
from basic.process_acc.processor_acc_sans_block import execute_study
from models.final import OnlyAccWithHistoryPercContFinal
from utils_generic import send_message


if __name__ == '__main__':
    bs = 64
    num_epochs = 100
    prefix = 'sans_block_perc_cont'

    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', dest='seed', type=int)
    parser.add_argument('--btest', dest='btest', type=int, action='append')
    args = parser.parse_args()

    for btest in args.btest:
        execute_study(OnlyAccWithHistoryPercContFinal, args.seed, btest, bs, num_epochs, prefix, [0])

    send_message(f'Acc SansBlock Perceived Contingency - {prefix} - seed = {args.seed}, btest = {args.btest} Finished')
