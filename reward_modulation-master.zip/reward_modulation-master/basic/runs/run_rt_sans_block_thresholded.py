import argparse
from basic.process_rt.processor_rt_sans_block_thresholded import execute_study
from models.final import OnlyRTWithHistoryThresholdedFinal
from utils_training import outlier_rt_threshold
from utils_generic import send_message


if __name__ == '__main__':
    bs = 64
    num_epochs = 100
    prefix = 'basic_sans_block_thresholded'

    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', dest='seed', type=int)
    parser.add_argument('--btest', dest='btest', type=int, action='append')
    args = parser.parse_args()

    for btest in args.btest:
        execute_study(OnlyRTWithHistoryThresholdedFinal, args.seed, btest, bs, num_epochs, prefix, [0],
                      outlier_rt_threshold)

    send_message(f'RT NoBlockEmb Thresholded - {prefix} - seed = {args.seed}, btest = {args.btest} Finished')
