import pandas
from config import project_dir
from utils_processing import mc_seeds
from utils_data.helper import sigmoid
from scipy.stats import wilcoxon, ttest_rel
import plotly.graph_objs as go
from utils_processing.metrics import p_val_text
from numpy import log

pred_cols = list(map(lambda x: f'acc_pred_{x}', range(len(mc_seeds))))


def conditioned_mse(result_dir, variable, annot_y, max_y):
    mc_values = pandas.read_pickle(result_dir + f'mc-values.pkl')
    mc_values[pred_cols] = mc_values[pred_cols].applymap(sigmoid)
    mc_values['acc_pred'] = mc_values[pred_cols].mean(axis=1)
    mc_values['bce'] = mc_values.apply(lambda row: -log(row.acc_pred) if row.acc_target else -log(1-row.acc_pred), axis=1)

    fig = go.Figure()

    mc_values['sub_emb'] = mc_values.sub_emb.apply(int).apply(str)

    cond = mc_values.groupby(['sub_emb', variable]).bce.mean()
    cond = cond.sort_index().reset_index()
    con0 = cond[cond[variable] == 0]
    con1 = cond[cond[variable] == 1]

    fig.add_trace(go.Bar(x=[0, 1], y=[con0.bce.mean(), con1.bce.mean()], showlegend=False))

    pt_p_val = ttest_rel(a=con0.bce, b=con1.bce, alternative='two-sided')[1]  # test if a != b
    w_p_val = wilcoxon(x=con0.bce, y=con1.bce, alternative='two-sided')[1]  # test if x != y
    fig.add_annotation(x=0.5, y=annot_y, showarrow=False,
                       text=f'0!=1<br>{p_val_text(pt_p_val)}; Paired-t<br>{p_val_text(w_p_val)}; Wilcoxon')

    for sub_emb in cond.sub_emb.unique():
        sub0 = con0.query(f'sub_emb == "{sub_emb}"')
        sub1 = con1.query(f'sub_emb == "{sub_emb}"')
        fig.add_trace(go.Scatter(x=[0, 1], y=[sub0.bce.iloc[0], sub1.bce.iloc[0]],
                                 mode='lines+markers', marker=dict(color='red'), opacity=0.3,
                                 name=f'{sub_emb}',  # showlegend=False,
                                 ))

    fig.update_layout(width=400, height=800, font_size=15)
    fig.update_xaxes(title_text=variable)
    fig.update_yaxes(title_text='BCE')
    fig.update_yaxes(range=[0, max_y])

    fig.show()


if __name__ == '__main__':
    res_dir = project_dir + 'basic/results/sans_block_bs=64_maxep=100_acc/'
    for var in ['change_fixed', 'change_variable', 'side_probed', 'reward_vr_fx', 'perc_vr_gt_fx']:
        conditioned_mse(res_dir, variable=var, annot_y=0.76, max_y=0.8)
