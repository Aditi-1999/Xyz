import pandas
import numpy
import plotly.express as px
from basic.analysis.model_choose import get_best_trials_for_block
from tqdm import tqdm
from utils_data import num_subjects, colours
from utils_processing.metrics import compute_robust_corr, compute_mse, p_val_text, distances, cosine_dist
from config import project_dir
import os

seed_list = [0, 10, 20]
bs = 64
num_epochs = 100


def scatter_embeddings_sd(model_class, prefix):
    cols = list(map(lambda x: f'x{x}', range(1, 6)))
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_rt'
    result_folder = project_dir + f'basic/results/{folder_name}/'
    file_name = result_folder + 'best_trials.pkl'

    if os.path.exists(file_name):
        trials = pandas.read_pickle(file_name)
    else:
        trials = get_best_trials_for_block(seed_list, prefix, bs, num_epochs, metric='rt')
        trials.to_pickle(file_name)

    subj_dfs = []
    for idx, row in tqdm(trials.iterrows()):
        trial = row.to_dict()
        actual_model = model_class.load_from_checkpoint(trial['folder_path'] + 'best.ckpt')
        subj_embed = numpy.array(actual_model.embeddings['sub_embedding'].weight.tolist())
        df_subj = pandas.DataFrame(subj_embed, columns=cols)
        df_subj['subject'] = list(map(str, range(num_subjects)))
        df_subj['seed'] = trial['seed']
        df_subj['btest'] = trial['btest']

        median = numpy.median(subj_embed, axis=0)
        mean = numpy.mean(subj_embed, axis=0)

        df_subj['l2_median'] = distances(subj_embed, median, 2)
        df_subj['l1_median'] = distances(subj_embed, median, 1)
        df_subj['cos_median'] = cosine_dist(subj_embed, median)
        df_subj['l2_mean'] = distances(subj_embed, mean, 2)
        df_subj['l1_mean'] = distances(subj_embed, mean, 1)
        df_subj['cos_mean'] = cosine_dist(subj_embed, mean)

        subj_dfs.append(df_subj)

    subj_df = pandas.concat(subj_dfs, ignore_index=True)
    subj_distances = subj_df.groupby(['subject']).mean()

    values_df = pandas.read_pickle(result_folder + f'overall-values.pkl')
    values_df = values_df[values_df['reward_vr_fx'] == 1].copy()
    values_df['sub_emb'] = values_df.sub_emb.apply(int).apply(str)
    values_df['block_emb'] = values_df.block_emb.apply(int).apply(str)
    actual_mses = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_mse(df, 'rt_target', 'rt_pred'))
    actual_mses.name = 'metric'
    actual_mses = actual_mses.reset_index()
    actual_mses = actual_mses.groupby(['sub_emb']).metric.mean()
    shuffled_mses = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_mse(df, 'rt_target_bs', 'rt_pred_bs'))
    shuffled_mses.name = 'metric'
    shuffled_mses = shuffled_mses.reset_index()
    shuffled_mses = shuffled_mses.groupby(['sub_emb']).metric.mean()

    data = []
    for sd_measure, measure in [
        ((actual_mses - shuffled_mses), '(Actual MSE - Shuffled MSE)'),
        ((actual_mses - shuffled_mses) / shuffled_mses, '(Actual MSE - Shuffled MSE) / Shuffled MSE'),
        ((actual_mses - shuffled_mses) / actual_mses, '(Actual MSE - Shuffled MSE) / Actual MSE'),
        ((actual_mses - shuffled_mses) / (actual_mses + shuffled_mses), '(Actual MSE - Shuffled MSE) / (Actual MSE + Shuffled MSE)'),
    ]:
        subj_distances['sd'] = sd_measure
        subj_distances_final = subj_distances.reset_index()
        for col, name in [
            ('l2_median', 'L2 Distance from Median'),
            ('l1_median', 'L1 Distance from Median'),
            ('cos_median', 'Cosine Distance from Median'),
            ('l2_mean', 'L2 Distance from Mean'),
            ('l1_mean', 'L1 Distance from Mean'),
            ('cos_mean', 'Cosine Distance from Mean'),
        ]:
            rcorr = compute_robust_corr(subj_distances_final, col, 'sd')
            datum = {
                'sd_measure': measure,
                'dist': name,
                'overall_r': rcorr['corr'],
                'overall_r_p': rcorr['pval'],
            }
            fig = px.scatter(subj_distances_final, x=col, y='sd',
                             # color='subject', color_discrete_sequence=colours,
                             title=f'RT Embeddings: R.Corr = {rcorr["corr"]:.3f}; {p_val_text(rcorr["pval"])}')
            fig.update_xaxes(title_text=name)
            fig.update_yaxes(title_text=measure + ' for Reward@VR>FX')
            fig.show()

            median_dist = subj_distances_final[col].median()
            low = subj_distances_final[subj_distances_final[col] < median_dist]
            high = subj_distances_final[subj_distances_final[col] >= median_dist]
            rcorr = compute_robust_corr(low, col, 'sd')
            datum.update({'low_r': rcorr['corr'], 'low_r_p': rcorr['pval']})
            rcorr = compute_robust_corr(high, col, 'sd')
            datum.update({'high_r': rcorr['corr'], 'high_r_p': rcorr['pval']})
            data.append(datum)

    df = pandas.DataFrame(data)
    df.to_csv(result_folder + 'rt_embeddings_vr_sd_effect.csv')


if __name__ == '__main__':
    from models.final import OnlyRTWithHistoryBasicFinal
    scatter_embeddings_sd(OnlyRTWithHistoryBasicFinal, 'sans_block')
