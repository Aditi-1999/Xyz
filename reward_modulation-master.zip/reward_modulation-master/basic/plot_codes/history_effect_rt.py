import pandas
import plotly.graph_objs as go
from config import project_dir
from scipy.stats import sem, wilcoxon, ttest_rel
from utils_processing.metrics import compute_robust_corr, compute_mse, p_val_text


def compare_correlations(values_df, title):
    values_df['sub_emb'] = values_df.sub_emb.apply(int).apply(str)
    values_df['block_emb'] = values_df.block_emb.apply(int).apply(str)

    fig = go.Figure()

    # Actual History Predictions
    actual_corrs = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_robust_corr(df, 'rt_target', 'rt_pred'))
    actual_pvals = actual_corrs.apply(lambda d: d['pval'])  # todo: need to combine p-val from here
    actual_corrs = actual_corrs.apply(lambda d: d['corr'])
    actual_corrs.name = 'metric'
    actual_corrs = actual_corrs.reset_index()
    actual_corrs = actual_corrs.groupby(['sub_emb']).metric.mean()

    # Shuffled History Predictions
    shuffled_corrs = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_robust_corr(df, 'rt_target_bs', 'rt_pred_bs'))
    shuffled_pvals = shuffled_corrs.apply(lambda d: d['pval'])  # todo: need to combine p-val from here
    shuffled_corrs = shuffled_corrs.apply(lambda d: d['corr'])
    shuffled_corrs.name = 'metric'
    shuffled_corrs = shuffled_corrs.reset_index()
    shuffled_corrs = shuffled_corrs.groupby(['sub_emb']).metric.mean()

    corr_df = pandas.DataFrame({'Actual': actual_corrs, 'Shuffled': shuffled_corrs}).reset_index()
    corr_df = pandas.melt(corr_df, id_vars=['sub_emb'], value_vars=['Actual', 'Shuffled'],
                          var_name='hist_type', value_name='robust_corr')

    stats_corr = corr_df.groupby('hist_type').robust_corr.agg(mean='mean', sem=sem).reset_index()
    fig.add_trace(go.Bar(x=stats_corr['hist_type'], y=stats_corr['mean'],
                         error_y=dict(array=stats_corr['sem'], symmetric=True), showlegend=False,
                         text=stats_corr['mean'].round(3), textposition='outside'))

    actual = corr_df.query('hist_type == "Actual"').sort_values('sub_emb').robust_corr.values
    shuffled = corr_df.query('hist_type == "Shuffled"').sort_values('sub_emb').robust_corr.values
    pt_p_val = ttest_rel(a=actual, b=shuffled, alternative='greater')[1]  # test if a > b
    w_p_val = wilcoxon(x=actual, y=shuffled, alternative='greater')[1]  # test if x > y
    fig.add_annotation(x=0.5, y=0.7, showarrow=False,
                       text=f'Actual>Shuffled<br>{p_val_text(pt_p_val)}; Paired-t<br>{p_val_text(w_p_val)}; Wilcoxon')

    for sub_emb in corr_df.sub_emb.unique():
        sub_corr_df = corr_df.query(f'sub_emb == "{sub_emb}"')
        fig.add_trace(go.Scatter(x=sub_corr_df['hist_type'], y=sub_corr_df['robust_corr'], mode='lines+markers',
                                 marker=dict(color='red'), opacity=0.3,
                                 name=f'{sub_emb}',
                                 # showlegend=False,
                                 ))

    fig.update_layout(width=400, height=800, font_size=15, title=dict(text=title, xanchor='center', x=0.5))
    fig.update_xaxes(title_text='History Type')
    fig.update_yaxes(title_text='Robust Correlation (Predicted RT, Observed RT)')
    fig.update_yaxes(range=[-0.2, 0.8])

    fig.show()


def compare_mses(values_df, title):
    values_df['sub_emb'] = values_df.sub_emb.apply(int).apply(str)
    values_df['block_emb'] = values_df.block_emb.apply(int).apply(str)

    fig = go.Figure()

    # Actual History Predictions
    actual_mses = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_mse(df, 'rt_target', 'rt_pred'))
    actual_mses.name = 'metric'
    actual_mses = actual_mses.reset_index()
    actual_mses = actual_mses.groupby(['sub_emb']).metric.mean()

    # Shuffled History Predictions
    shuffled_mses = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_mse(df, 'rt_target_bs', 'rt_pred_bs'))
    shuffled_mses.name = 'metric'
    shuffled_mses = shuffled_mses.reset_index()
    shuffled_mses = shuffled_mses.groupby(['sub_emb']).metric.mean()

    mse_df = pandas.DataFrame({'Actual': actual_mses, 'Shuffled': shuffled_mses}).reset_index()
    mse_df = pandas.melt(mse_df, id_vars=['sub_emb'], value_vars=['Actual', 'Shuffled'],
                         var_name='hist_type', value_name='mse')

    stats_mse = mse_df.groupby('hist_type').mse.agg(mean='mean', sem=sem).reset_index()
    fig.add_trace(go.Bar(x=stats_mse['hist_type'], y=stats_mse['mean'],
                         error_y=dict(array=stats_mse['sem'], symmetric=True), showlegend=False,
                         text=stats_mse['mean'].round(3), textposition='outside'))

    actual = mse_df.query('hist_type == "Actual"').sort_values('sub_emb').mse.values
    shuffled = mse_df.query('hist_type == "Shuffled"').sort_values('sub_emb').mse.values
    pt_p_val = ttest_rel(a=actual, b=shuffled, alternative='less')[1]  # test if a < b
    w_p_val = wilcoxon(x=actual, y=shuffled, alternative='less')[1]  # test if x < y
    fig.add_annotation(x=0.5, y=1.7, showarrow=False,
                       text=f'Actual<Shuffled<br>{p_val_text(pt_p_val)}; Paired-t<br>{p_val_text(w_p_val)}; Wilcoxon')

    for sub_emb in mse_df.sub_emb.unique():
        sub_mse_df = mse_df.query(f'sub_emb == "{sub_emb}"')
        fig.add_trace(go.Scatter(x=sub_mse_df['hist_type'], y=sub_mse_df['mse'], mode='lines+markers',
                                 marker=dict(color='red'), opacity=0.3,
                                 name=f'{sub_emb}',
                                 # showlegend=False,
                                 ))

    fig.update_layout(width=400, height=800, font_size=15, title=dict(text=title, xanchor='center', x=0.5))
    fig.update_xaxes(title_text='History Type')
    fig.update_yaxes(title_text='MSE (Predicted RT, Observed RT)')
    max_y = max(actual_mses.max(), shuffled_mses.max()) + 0.1
    if max_y < 2:
        max_y = 2
    fig.update_yaxes(range=[0, max_y])

    fig.show()


if __name__ == '__main__':
    result_folder = project_dir + f'basic/results/sans_block_bs=64_maxep=100_rt/'

    for fname, model_type in [
        ('overall-values.pkl', 'Overall'),
        ('noreg-values.pkl', 'No Reg'),
        ('l2reg-values.pkl', 'L2 Reg'),
        ('dropout-values.pkl', 'Dropout>0'),
    ]:
        values = pandas.read_pickle(result_folder + fname)
        compare_correlations(values, model_type)
        compare_mses(values, model_type)
