import optuna
from subj_wise import optuna_storage, rt_subjects, acc_subjects
from utils_data import num_gain_blocks
import pandas
from scipy.stats import sem
from config import project_dir


pandas.set_option('display.max_colwidth', 1000)
pandas.set_option('display.max_rows', 1000)


def get_hyper_config(prefix, user_attrs_config):
    if prefix == 'subj_wise':
        hyper_config = {
            'T': user_attrs_config['T'],
            'rnn_layers': user_attrs_config['rnn_layers'],
            'rnn_bidirectional': user_attrs_config['rnn_bidirectional'],
            'rnn_hidden_size': user_attrs_config['rnn_hidden_size'],
            'hidden_sizes': user_attrs_config['hidden_sizes'],
            'activation_func': user_attrs_config['activation_func'],
        }
        return str(hyper_config)  # to facilitate grouping
    if prefix == 'subj_wise_nohist_lstm':
        hyper_config = {
            'rnn_hidden_size': user_attrs_config['rnn_hidden_size'],
            'hidden_sizes': user_attrs_config['hidden_sizes'],
        }
        return str(hyper_config)  # to facilitate grouping
    raise Exception(f'Unknown prefix: {prefix}')


def get_all_results(seed_list, prefix, bs, num_epochs, trial_filter, metric):
    if metric == 'rt':
        subjects = rt_subjects
    elif metric == 'acc':
        subjects = acc_subjects
    else:
        raise Exception

    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_{metric}'
    storage = optuna.storages.get_storage(optuna_storage)
    all_dfs = []
    for seed in seed_list:
        for b in range(num_gain_blocks):
            for sub_num in subjects:
                study_name = f'{folder_name}_{sub_num}_{seed}_{b}'
                study = optuna.load_study(study_name=study_name, storage=storage)
                df = study.trials_dataframe()
                df = df[df.user_attrs_config.apply(trial_filter)]
                df['folder_name'] = folder_name
                df['study_name'] = study_name
                df['sub_num'] = sub_num
                df['seed'] = seed
                all_dfs.append(df)
    results_df = pandas.concat(all_dfs, ignore_index=True)
    results_df['hyper_config'] = results_df.user_attrs_config.apply(lambda c: get_hyper_config(prefix, c))
    counts: pandas.Series = results_df.groupby(['seed', 'sub_num', 'hyper_config']).number.count()
    assert (counts == num_gain_blocks).all(), f"Some hyperparameters not run for some blocks! {counts}"
    return results_df


def get_full_folder_path(row):
    return project_dir + 'subj_wise/results/' + row.folder_name + '/' + row.study_name + '/' + row.trial_id + '/'


def best_hyper_config(results_df):
    hyper_perf = results_df.groupby(['seed', 'hyper_config']).value.mean().reset_index()
    hyper_perf: pandas.DataFrame = hyper_perf.groupby('hyper_config').value.agg(val_loss='mean', sem=sem).reset_index()
    hyper_perf.sort_values(by=['val_loss'], inplace=True)
    best_config = hyper_perf.hyper_config.iloc[0]
    best_trials = results_df[results_df.hyper_config == best_config].copy()
    best_trials['trial_id'] = best_trials.user_attrs_config.apply(lambda d: d['trial_id'])
    best_trials['folder_path'] = best_trials.apply(get_full_folder_path, axis=1)
    return best_trials
