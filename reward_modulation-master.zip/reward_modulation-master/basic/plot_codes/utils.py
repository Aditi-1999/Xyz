from sklearn.manifold import TSNE
import plotly.express as px
from utils_data import colours


def plot_embeddings(subj_df, cols, ):
    df = subj_df.copy()

    tsne = TSNE(n_components=3, random_state=0, init='pca', learning_rate='auto')
    projections = tsne.fit_transform(df[cols])
    fig = px.scatter_3d(projections, x=0, y=1, z=2, color=df.subject, color_discrete_sequence=colours,
                        labels={'color': 'Subject ID', '0': 'Dimension 1', '1': 'Dimension 2', '2': 'Dimension 3'},
                        title=f"t-SNE for Subject Embeddings in 3D")
    fig.show()

    tsne = TSNE(n_components=2, random_state=0, init='pca', learning_rate='auto')
    projections = tsne.fit_transform(df[cols])
    fig = px.scatter(projections, x=0, y=1, color=df.subject, color_discrete_sequence=colours,
                     labels={'color': 'Subject ID', '0': 'Dimension 1', '1': 'Dimension 2'},
                     title=f"t-SNE for Subject Embeddings in 2D")
    fig.show()
