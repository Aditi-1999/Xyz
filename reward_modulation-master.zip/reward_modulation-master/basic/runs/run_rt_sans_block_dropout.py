import argparse
from basic.process_rt.processor_rt_sans_block_dropout import execute_study
from models.final import OnlyRTWithHistoryBasicFinal
from utils_generic import send_message


if __name__ == '__main__':
    bs = 64
    num_epochs = 100
    prefix = 'sans_block'

    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', dest='seed', type=int)
    parser.add_argument('--btest', dest='btest', type=int)
    parser.add_argument('--gpu', dest='gpu', type=int, default=0)
    parser.add_argument('--dropout', dest='dropout', type=float)
    args = parser.parse_args()

    execute_study(OnlyRTWithHistoryBasicFinal, args.seed, args.btest, bs, num_epochs, prefix, [args.gpu], 'gain_d',
                  args.dropout)

    send_message(f'RT SansBlock - {prefix} for {args} Finished')
