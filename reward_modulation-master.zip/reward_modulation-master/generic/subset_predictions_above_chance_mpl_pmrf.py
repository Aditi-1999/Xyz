from aistats_figures import rt_file, acc_file, get_sub_metrics, data_dir, p_text
from scipy.stats import ttest_rel
import matplotlib.patches as mpatches
from matplotlib.axes import Axes
from numpy.typing import NDArray
import matplotlib.lines as mlines
import matplotlib.pyplot as plt
from config import project_dir
import seaborn as sns
import pandas
import numpy
import matplotlib

font_size = 15
lfont_size = 17

color = {
    'srm': [0, 0, 1, 0.2],
}


def get_all_rt_metrics(experiment):
    rt_fname = data_dir + experiment + '/ss_rt.pkl'
    values = rt_file(rt_fname)
    corr = get_sub_metrics(values, experiment=experiment, metric='rt', measure='corr', shuffled=False)
    corr.name = 'corr'
    mse = get_sub_metrics(values, experiment=experiment, metric='rt', measure='mse', shuffled=False)
    mse.name = 'mse'
    return pandas.DataFrame([corr, mse]).transpose()


def get_all_acc_metrics(experiment):
    acc_fname = data_dir + experiment + '/ss_acc.pkl'
    values = acc_file(acc_fname)
    auroc = get_sub_metrics(values, experiment=experiment, metric='acc', measure='auroc', shuffled=False)
    auroc.name = 'auroc'
    bce = get_sub_metrics(values, experiment=experiment, metric='acc', measure='bce', shuffled=False)
    bce.name = 'bce'
    return pandas.DataFrame([auroc, bce]).transpose()


def plot_metrics(ax: Axes, vrange, measure, ss_srm, ylabel, ticks, threshold, p_ys):
    if measure in ['corr', 'auroc']:
        direction = 'greater'
    elif measure in ['mse', 'bce']:
        direction = 'less'
    else:
        raise Exception()

    ss_srm['experiment'] = 'SRM'
    df = ss_srm.copy()
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    sns.violinplot(data=df, ax=ax, x='experiment', y=measure,
                   palette=[color['srm']], saturation=1, inner=None)
    for collection in ax.collections:
        if isinstance(collection, matplotlib.collections.PolyCollection):
            collection.set_edgecolor('none')
    sns.boxplot(data=df, ax=ax, x='experiment', y=measure, color='black', fill=False, width=0.2)
    ax.set_ylim(*vrange)
    ax.set_ylabel(ylabel, fontsize=font_size)
    ax.set_yticks(ticks)
    ax.set_xticks([])
    ax.set_xlabel('')
    ax.set_xticklabels([])
    for tick in ax.get_yticklabels():
        tick.set_fontsize(font_size)

    if measure == 'corr':
        return
    elif measure == 'bce':
        ax.axhline(y=threshold[0], color='black', linestyle='--', )
        srm_p = ttest_rel(a=ss_srm[measure], b=numpy.ones_like(ss_srm[measure]) * threshold[0], alternative=direction)[1]
        srm_p = p_text(srm_p)
        ax.text(0, p_ys[0], s=srm_p, ha='center', va='center', fontsize=font_size)

    else:
        ax.axhline(y=threshold, color='black', linestyle='--')
        srm_p = ttest_rel(a=ss_srm[measure], b=numpy.ones_like(ss_srm[measure]) * threshold, alternative=direction)[1]
        srm_p = p_text(srm_p)
        ax.text(0, p_ys[0], s=srm_p, ha='center', va='center', fontsize=font_size)


def make_rt_subplots(axs: NDArray[Axes]):  # two column axes for first row
    srm_ss = get_all_rt_metrics(experiment='srm')
    plot_metrics(axs[0], [-0.2, 1], 'corr', srm_ss,
                 'R.Corr', numpy.arange(-0.2, 1, 0.2), 0.4, (0.5, 0.9))
    plot_metrics(axs[1], [0.4, 2.6], 'mse', srm_ss,
                 'MSE', numpy.arange(0.4, 2.6, 0.4), 1, (1.9, 1.5))


def make_acc_subplots(axs: NDArray[Axes]):  # two column axes for second row
    srm_ss = get_all_acc_metrics(experiment='srm')
    plot_metrics(axs[0], [0.3, 1.1], 'auroc', srm_ss,
                 'AUROC', numpy.arange(0.3, 1.1, 0.2), 0.5, (1, 1))
    plot_metrics(axs[1], [0.1, 0.9], 'bce', srm_ss,
                 'BCE', numpy.arange(0.1, 0.9, 0.2), [0.666, 0.512], (0.8, 0.8))


def plot():
    plt.rcParams['axes.unicode_minus'] = False
    plt.rcParams['font.sans-serif'] = "Arial"
    plt.rcParams['font.family'] = "sans-serif"
    fig, axs = plt.subplots(1, 4, figsize=(10, 4))

    make_rt_subplots(axs[:2])
    make_acc_subplots(axs[2:])

    fig.text(0.01, 0.95, "A", fontweight='bold', ha='left', va='center', fontsize=lfont_size)
    fig.text(0.25, 0.95, "B", fontweight='bold', ha='left', va='center', fontsize=lfont_size)

    fig.text(0.5, 0.95, "C", fontweight='bold', ha='left', va='center', fontsize=lfont_size)
    fig.text(0.75, 0.95, "D", fontweight='bold', ha='left', va='center', fontsize=lfont_size)

    threshold_legend = mlines.Line2D([], [], color='black', linestyle='--',
                                     label='Chance Level')
    legend = fig.legend(loc='upper right',  bbox_to_anchor=(1, 1),
                        borderaxespad=0, bbox_transform=fig.transFigure,
                        handles=[threshold_legend])
    legend.get_frame().set_visible(False)
    for legend_text in legend.get_texts():
        legend_text.set_fontsize(font_size)

    plt.tight_layout(rect=[0, 0, 1, 0.975])
    plt.savefig(project_dir + 'aistats_figures/plots/subset_predictions_above_chance_pmrf.png', dpi=400)
    # plt.show()


if __name__ == '__main__':
    plot()
