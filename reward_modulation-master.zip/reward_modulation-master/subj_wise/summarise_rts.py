from utils_processing.common_proc import read_data_and_preprocess
from utils_training.training_rt import make_predictions
from utils_data import num_gain_blocks, num_subjects
from utils_processing import seeds
from subj_wise import optuna_storage
from config import project_dir
from typing import Optional
import optuna
import pandas


def summarise_rt_filtered(model_class, bs: int, num_epochs: int, prefix: str, gpu_num: list[int], trial_filter,
                          threshold):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_rt'
    res_dir = project_dir + 'subj_wise/results/' + folder_name + '/'
    values_df = []
    proc_df_dict = {}

    storage = optuna.storages.get_storage(optuna_storage)

    for seed in seeds[:3]:
        for b in range(num_gain_blocks):
            btest = b
            bval = (b + 1) % num_gain_blocks

            for sub_num in range(num_subjects):
                study_name = f'{folder_name}_{sub_num}_{seed}_{b}'
                study = optuna.load_study(study_name=study_name, storage=storage)
                df = study.trials_dataframe()
                fil_df = df[df.user_attrs_config.apply(trial_filter)]
                best_config = fil_df.sort_values('value').iloc[0].user_attrs_config
                trial_id = best_config['trial_id']

                best_model_path = res_dir + f'{study_name}/{trial_id}/best.ckpt'
                best_model = model_class.load_from_checkpoint(best_model_path)

                T = best_config['T']
                if T in proc_df_dict:
                    proc_df = proc_df_dict[T]
                else:
                    proc_df = read_data_and_preprocess(T, return_raw=False)
                    proc_df_dict[T] = proc_df

                sub_df = proc_df.query(f'sub_num == {sub_num}').copy()
                value_df, sub_config = make_predictions(best_model, seed, btest, bval, bs, num_epochs, sub_df, gpu_num,
                                                        threshold)
                values_df.append(value_df)

    all_values_df = pandas.concat(values_df, ignore_index=True)
    return all_values_df


def summarise_rt(model_class, bs: int, num_epochs: int, prefix: str, gpu_num: list[int], threshold: Optional[float]):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_rt'
    res_dir = project_dir + 'subj_wise/results/' + folder_name + '/'

    def trial_filter(d):
        return True

    all_values_df = summarise_rt_filtered(model_class, bs, num_epochs, prefix, gpu_num, trial_filter, threshold)
    all_values_df.to_pickle(res_dir + f'overall-values.pkl')


def summarise_rt_T(model_class, bs: int, num_epochs: int, prefix: str, gpu_num: list[int], threshold: Optional[float]):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_rt'
    res_dir = project_dir + 'subj_wise/results/' + folder_name + '/'

    for T in [1, 3, 10, 15]:

        def trial_filter(d):
            return d['T'] == T

        all_values_df = summarise_rt_filtered(model_class, bs, num_epochs, prefix, gpu_num, trial_filter, threshold)
        all_values_df.to_pickle(res_dir + f'T={T}-values.pkl')
