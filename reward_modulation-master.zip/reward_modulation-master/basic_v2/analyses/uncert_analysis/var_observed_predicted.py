import numpy
import pandas
import plotly.graph_objs as go
from config import project_dir
from scipy.stats import sem
from utils_data import sd_types
from utils_processing import mc_seeds
from utils_data.helper import serial_dependence_measure
from basic_v2.final_analyses import get_sub_actual_corrs, get_sub_actual_mses, get_sub_actual_aurocs, \
    get_sub_actual_bces, rt_file, acc_file, get_ttest_wilcoxon_text, get_sub_shuffled_corrs, get_sub_shuffled_mses, \
    get_sub_shuffled_aurocs, get_sub_shuffled_bces
from numpy import var

sd_type = 'difference'


def compare_mses(folder):
    fig = go.Figure()
    vdf = rt_file(folder + f'mc-test_values.pkl')

    pred_cols = list(map(lambda x: f'rt_pred_{x}', range(len(mc_seeds))))

    vdf = vdf.groupby(['sub_num', 'seed', 'btest']) \
        .agg({'rt_pred': var, 'rt_target': var}) \
        .reset_index()
    vdf = vdf.groupby(['sub_num']).agg({'rt_pred': 'mean', 'rt_target': 'mean'})

    actual_mses = vdf.rt_target
    control_mses = vdf.rt_pred

    mse_df = pandas.DataFrame({'Actual': actual_mses, 'Shuffled': control_mses}).reset_index()
    mse_df = pandas.melt(mse_df, id_vars=['sub_num'], value_vars=['Actual', 'Shuffled'],
                         var_name='hist_type', value_name='mse')

    stats_mse = mse_df.groupby('hist_type').mse.agg(mean='mean', sem=sem).reset_index()
    fig.add_trace(go.Bar(x=stats_mse['hist_type'], y=stats_mse['mean'],
                         error_y=dict(array=stats_mse['sem'], symmetric=True), showlegend=False,
                         text=stats_mse['mean'].round(3), textposition='outside'))

    actual = mse_df.query('hist_type == "Actual"').sort_values('sub_num').set_index('sub_num').mse
    control = mse_df.query('hist_type == "Shuffled"').sort_values('sub_num').set_index('sub_num').mse
    sd = serial_dependence_measure(sd_type, actual, control)
    test_text = get_ttest_wilcoxon_text(sd, numpy.zeros_like(sd), 'less')
    fig.add_annotation(x=0.5, y=1.7, showarrow=False, text=f'{sd_types[sd_type]} - MSE < 0<br>{test_text}')

    for sub_num in mse_df.sub_num.unique():
        sub_mse_df = mse_df.query(f'sub_num == {sub_num}')
        fig.add_trace(go.Scatter(x=sub_mse_df['hist_type'], y=sub_mse_df['mse'], mode='lines+markers',
                                 marker=dict(color='red'), opacity=0.3,
                                 name=f'{sub_num}', showlegend=False))

    fig.update_layout(width=400, height=800, font_size=15, title=dict(text='SRM - RT', xanchor='center', x=0.5))
    fig.update_xaxes(title_text='History Type')
    fig.update_yaxes(title_text='MSE (Predicted RT, Observed RT)')
    fig.update_yaxes(range=[0, 2.1])
    fig.show()


def compare_bces(folder):
    fig = go.Figure()
    vdf = acc_file(folder + f'mc-test_values.pkl')
    actual_bces = get_sub_actual_bces(vdf)
    control_bces = get_sub_shuffled_bces(vdf)

    bce_df = pandas.DataFrame({'Actual': actual_bces, 'Shuffled': control_bces}).reset_index()
    bce_df = pandas.melt(bce_df, id_vars=['sub_num'], value_vars=['Actual', 'Shuffled'],
                         var_name='hist_type', value_name='bce')

    stats_bce = bce_df.groupby('hist_type').bce.agg(mean='mean', sem=sem).reset_index()
    fig.add_trace(go.Bar(x=stats_bce['hist_type'], y=stats_bce['mean'],
                         error_y=dict(array=stats_bce['sem'], symmetric=True), showlegend=False,
                         text=stats_bce['mean'].round(3), textposition='outside'))

    actual = bce_df.query('hist_type == "Actual"').sort_values('sub_num').set_index('sub_num').bce
    control = bce_df.query('hist_type == "Shuffled"').sort_values('sub_num').set_index('sub_num').bce
    sd = serial_dependence_measure(sd_type, actual, control)
    test_text = get_ttest_wilcoxon_text(sd, numpy.zeros_like(sd), 'less')
    fig.add_annotation(x=0.5, y=0.8, showarrow=False, text=f'{sd_types[sd_type]} - BCE < 0<br>{test_text}')

    for sub_num in bce_df.sub_num.unique():
        sub_bce_df = bce_df.query(f'sub_num == {sub_num}')
        fig.add_trace(go.Scatter(x=sub_bce_df['hist_type'], y=sub_bce_df['bce'], mode='lines+markers',
                                 marker=dict(color='red'), opacity=0.3,
                                 name=f'{sub_num}', showlegend=False))

    fig.update_layout(width=400, height=800, font_size=15, title=dict(text='SRM - Acc', xanchor='center', x=0.5))
    fig.update_xaxes(title_text='History Type')
    fig.update_yaxes(title_text='BCE (Predicted Acc, Observed Acc)')
    fig.update_yaxes(range=[0, 1])
    fig.show()


if __name__ == '__main__':
    compare_mses(project_dir + f'basic_v2/results/sans_block_v3_bs=64_maxep=100_rt/')
    # compare_bces(project_dir + f'basic_v2/results/sans_block_v3_bs=64_maxep=100_acc/')
