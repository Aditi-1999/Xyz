import requests
from config import code_update_webhook, server


def send_message(msg):
    try:
        requests.post(code_update_webhook, json={
            'text': f'*Reward Modulation Project* on {server}: {msg}'
        })
    except Exception as e:
        print(f'Error while sending msg: {msg}, error: {e}')


def get_list_as_dict(lst):
    d = {}
    for pos, item in enumerate(lst):
        d[item] = pos
    return d
