from config import server

if server in ['wellsfargo', 'magnus']:
    optuna_storage = "mysql://newraj:password@10.36.17.196/RewardModulationUncertainty"  # Point to Nova's mysql
else:
    optuna_storage = "mysql://root:password@localhost/RewardModulationUncertainty"
    # optuna_storage = "mysql://newraj:password@10.36.17.196/RewardModulationUncertainty"

wandb_project = 'RewardModulationUncertainty'
