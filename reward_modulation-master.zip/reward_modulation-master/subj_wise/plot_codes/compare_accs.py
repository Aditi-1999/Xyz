import pandas
import plotly.graph_objs as go
import plotly.express as px
from config import project_dir
from subj_wise import acc_subjects
from utils_processing.metrics import compute_auroc, compute_bce


colours = ["red", "green", "blue", "goldenrod", "magenta", "violet"]


def get_actual_metrics(values_df):
    # Actual History Predictions
    actual_aurocs = values_df.groupby(['sub_emb', 'seed']).apply(lambda df: compute_auroc(df, 'acc_target', 'acc_pred'))
    actual_aurocs.name = 'metric'
    actual_aurocs = actual_aurocs.reset_index()
    actual_aurocs = actual_aurocs.groupby(['sub_emb']).metric.mean()

    actual_bces = values_df.groupby(['sub_emb', 'seed']).apply(lambda df: compute_bce(df, 'acc_target', 'acc_pred'))
    actual_bces.name = 'metric'
    actual_bces = actual_bces.reset_index()
    actual_bces = actual_bces.groupby(['sub_emb']).metric.mean()

    return actual_aurocs, actual_bces


def compare_metrics(common_values_df, subjwise_values_df, title):
    common_auroc, common_bce = get_actual_metrics(common_values_df)
    subj_auroc, subj_bce = get_actual_metrics(subjwise_values_df)

    # AUROC Scatter
    auroc_range = [0.4, 0.85]
    auroc_df = pandas.DataFrame({'common': common_auroc, 'subj': subj_auroc}).reset_index()
    auroc_df['sub_emb'] = auroc_df.sub_emb.apply(int).apply(str)
    fig = px.scatter(auroc_df, x='common', y='subj', color='sub_emb', color_discrete_sequence=colours,
                     labels={'common': 'Common Model AUROC', 'subj': 'Subject Wise Models AUROC',
                             'sub_emb': 'Subject ID'})
    fig.add_trace(go.Scatter(x=auroc_range, y=auroc_range, mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_layout(width=900, height=800, font_size=15, xaxis_range=auroc_range, yaxis_range=auroc_range,
                      title=dict(text=title + ' - Comparing AUROC', xanchor='center', x=0.5))
    fig.show()

    # BCE Scatter
    bce_range = [0.4, 1.1]
    bce_df = pandas.DataFrame({'common': common_bce, 'subj': subj_bce}).reset_index()
    bce_df['sub_emb'] = bce_df.sub_emb.apply(int).apply(str)
    fig = px.scatter(bce_df, x='common', y='subj', color='sub_emb', color_discrete_sequence=colours,
                     labels={'common': 'Common Model BCE', 'subj': 'Subject Wise Models BCE',
                             'sub_emb': 'Subject ID'})
    fig.add_trace(go.Scatter(x=bce_range, y=bce_range, mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_layout(width=900, height=800, font_size=15,
                      title=dict(text=title + ' - Comparing BCE', xanchor='center', x=0.5))
    fig.show()


if __name__ == '__main__':
    subj_folder = project_dir + f'subj_wise/results/subj_wise_bs=32_maxep=100_acc/'
    subj_values = pandas.read_pickle(subj_folder + f'overall-values.pkl')

    common_folder = project_dir + f'basic/results/basic_bs=64_maxep=100_acc/'
    common_values = pandas.read_pickle(common_folder + f'overall-values.pkl')
    common_values = common_values.query(f'sub_emb in {acc_subjects}').query(f'seed == 0').copy()

    compare_metrics(common_values, subj_values, 'Overall')
