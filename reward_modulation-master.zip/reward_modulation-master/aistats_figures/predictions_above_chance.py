import pandas
from plotly.subplots import make_subplots
import plotly.graph_objs as go
from config import project_dir
from aistats_figures import rt_file, acc_file, get_sub_metrics, color

data_dir = project_dir + 'aistats_figures/data/'


def get_rt_metrics(rt_fname, experiment):
    values = rt_file(rt_fname)
    corr = get_sub_metrics(values, experiment=experiment, metric='rt', measure='corr', shuffled=False)
    corr.name = 'corr'
    mse = get_sub_metrics(values, experiment=experiment, metric='rt', measure='mse', shuffled=False)
    mse.name = 'mse'
    return pandas.DataFrame([corr, mse]).transpose()


def get_all_rt_metrics(experiment):
    bisann = get_rt_metrics(data_dir + experiment + '/bisann_rt.pkl', experiment=experiment)
    return bisann


def get_acc_metrics(acc_fname, experiment):
    values = acc_file(acc_fname)
    auroc = get_sub_metrics(values, experiment=experiment, metric='acc', measure='auroc', shuffled=False)
    auroc.name = 'auroc'
    bce = get_sub_metrics(values, experiment=experiment, metric='acc', measure='bce', shuffled=False)
    bce.name = 'bce'
    return pandas.DataFrame([auroc, bce]).transpose()


def get_all_acc_metrics(experiment):
    bisann = get_acc_metrics(data_dir + experiment + '/bisann_acc.pkl', experiment=experiment)
    return bisann


def plot_metrics(fig, vrange, selector, measure, bisann, experiment, x_title, showlegend):
    fig.add_trace(
        go.Violin(y=bisann[measure], box=dict(visible=True), fillcolor=color[experiment], opacity=0.7,
                  line=dict(color='black'), x0=x_title,
                  showlegend=showlegend, legendgroup=experiment.upper(), name=experiment.upper()),
        **selector,
    )
    fig.update_yaxes(range=vrange, **selector)


def make_rt_subplots(fig):
    row = 1
    srm_bisann = get_all_rt_metrics(experiment='srm')

    selector = {'row': row, 'col': 1}
    plot_metrics(fig, [-0.15, 0.6], selector, 'corr', srm_bisann, 'srm', 'R.Corr', True)

    selector = {'row': row, 'col': 2}
    plot_metrics(fig, [0.7, 2.1], selector, 'mse', srm_bisann, 'srm', 'MSE', False)

    tms_bisann = get_all_rt_metrics(experiment='tms')

    selector = {'row': row, 'col': 3}
    plot_metrics(fig, [-0.1, 0.9], selector, 'corr', tms_bisann, 'tms', 'R.Corr', True)

    selector = {'row': row, 'col': 4}
    plot_metrics(fig, [0.4, 1.25], selector, 'mse', tms_bisann, 'tms', 'MSE', False)


def make_acc_subplots(fig):
    row = 2
    srm_bisann = get_all_acc_metrics(experiment='srm')

    selector = {'row': row, 'col': 1}
    plot_metrics(fig, [0, 1], selector, 'auroc', srm_bisann, 'srm', 'AUROC', False)

    selector = {'row': row, 'col': 2}
    plot_metrics(fig, [0, 1], selector, 'bce', srm_bisann, 'srm', 'BCE', False)

    tms_bisann = get_all_acc_metrics(experiment='tms')

    selector = {'row': row, 'col': 3}
    plot_metrics(fig, [0, 1], selector, 'auroc', tms_bisann, 'tms', 'AUROC', False)

    selector = {'row': row, 'col': 4}
    plot_metrics(fig, [0, 1], selector, 'bce', tms_bisann, 'tms', 'BCE', False)


def plot():
    fig = make_subplots(2, 4)
    make_rt_subplots(fig)
    make_acc_subplots(fig)
    fig.update_xaxes(ticks='outside', showline=True, linewidth=2, linecolor='black')
    fig.update_yaxes(ticks='outside', showline=True, linewidth=2, linecolor='black')
    fig.update_layout(plot_bgcolor='white', font_size=15, width=1600, height=800)
    config = {
        'toImageButtonOptions': {
            'format': 'png',  # one of png, svg, jpeg, webp
            'filename': 'predictions_above_chance',
            'scale': 3  # Multiply title/legend/axis/canvas sizes by this factor
        }
    }
    fig.show(config=config)


if __name__ == '__main__':
    plot()
