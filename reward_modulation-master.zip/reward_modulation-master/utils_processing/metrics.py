import pingouin as pg
import torch
import numpy
from torch.nn import MSELoss, BCEWithLogitsLoss
from torchmetrics.functional.classification import binary_auroc
from scipy.stats import wilcoxon, ttest_rel


def p_val_text(p_val):
    if p_val < 0.001:
        text = f'<b>***p < 0.001</b>'
    elif p_val < 0.01:
        text = f'<b>**p = {p_val:.3f}</b>'
    elif p_val < 0.05:
        text = f'<b>*p = {p_val:.3f}</b>'
    else:
        text = f'p = {p_val:.3f}'
    return text


def compute_robust_corr(df, target, pred, alternative='two-sided') -> dict[str, float]:
    """
    :param alternative: 'two-sided' <=> Corr!=0; 'greater' <=> Corr>0; 'less' <=> Corr<0
    """
    res = pg.corr(df[target], df[pred], method='percbend', alternative=alternative)
    return {
        'corr': res['r'][0],
        'pval': res['p-val'][0],
    }


def compute_mse(df, target, pred):
    preds = torch.tensor(df[pred].tolist(), dtype=torch.float64).double().view(-1, 1)
    targets = torch.tensor(df[target].tolist(), dtype=torch.float64).double().view(-1, 1)
    return MSELoss()(preds, targets).item()


def compute_element_mse(df, target, pred):
    preds = torch.tensor(df[pred].tolist(), dtype=torch.float64).double().view(-1, 1)
    targets = torch.tensor(df[target].tolist(), dtype=torch.float64).double().view(-1, 1)
    return MSELoss(reduction='none')(preds, targets).numpy()[:, 0]


def compute_auroc(df, target, pred):  # pred has to be logits
    return binary_auroc(
        preds=torch.sigmoid(torch.tensor(df[pred].tolist(), dtype=torch.float64).double()),
        target=torch.tensor(df[target].tolist(), dtype=torch.long).long(),
    ).item()


def compute_bce(df, target, pred):
    preds = torch.tensor(df[pred].tolist(), dtype=torch.float64).double().view(-1, 1)
    targets = torch.tensor(df[target].tolist(), dtype=torch.float64).double().view(-1, 1)
    return BCEWithLogitsLoss()(preds, targets).item()


def compute_element_bce(df, target, pred):
    preds = torch.tensor(df[pred].tolist(), dtype=torch.float64).double().view(-1, 1)
    targets = torch.tensor(df[target].tolist(), dtype=torch.float64).double().view(-1, 1)
    return BCEWithLogitsLoss(reduction='none')(preds, targets).numpy()[:, 0]


def distances(matrix, compare, order):
    diff = matrix - compare
    return numpy.linalg.norm(diff, axis=1, ord=order)


def cosine_dist(matrix, compare):
    cos_sim = numpy.dot(matrix, compare) / numpy.linalg.norm(compare)
    cos_sim = numpy.divide(cos_sim, numpy.linalg.norm(matrix, axis=1))
    return 1 - cos_sim


def get_ttest_wilcoxon_text(x, y, direction):
    pt_p_val = ttest_rel(a=x, b=y, alternative=direction)[1]
    w_p_val = wilcoxon(x=x, y=y, alternative=direction)[1]
    text = f'{p_val_text(pt_p_val)}; Paired-t<br>{p_val_text(w_p_val)}; Wilcoxon'
    return text
