import pandas
import plotly.graph_objs as go
from config import project_dir
from utils_processing import mc_seeds
from scipy.stats import sem, wilcoxon, ttest_rel
from utils_data.helper import get_actual_trial_type, get_perc_trial_type
from utils_processing.metrics import compute_robust_corr, compute_mse, p_val_text


def compare_correlations(values_df, title):
    values_df['sub_emb'] = values_df.sub_emb.apply(int).apply(str)
    values_df['block_emb'] = values_df.block_emb.apply(int).apply(str)

    fig = go.Figure()

    # Intact History Predictions
    intact_corrs = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_robust_corr(df, 'rt_target', 'rt_pred'))
    intact_corrs = intact_corrs.apply(lambda d: d['corr'])
    intact_corrs.name = 'metric'
    intact_corrs = intact_corrs.reset_index()
    intact_corrs = intact_corrs.groupby(['sub_emb']).metric.mean()

    # Scrambled History Predictions
    scrambled_corrs = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_robust_corr(df, 'rt_target_bs', 'rt_pred_bs'))
    scrambled_corrs = scrambled_corrs.apply(lambda d: d['corr'])
    scrambled_corrs.name = 'metric'
    scrambled_corrs = scrambled_corrs.reset_index()
    scrambled_corrs = scrambled_corrs.groupby(['sub_emb']).metric.mean()

    corr_df = pandas.DataFrame({'Intact': intact_corrs, 'Scrambled': scrambled_corrs}).reset_index()
    corr_df = pandas.melt(corr_df, id_vars=['sub_emb'], value_vars=['Intact', 'Scrambled'],
                          var_name='hist_type', value_name='robust_corr')

    stats_corr = corr_df.groupby('hist_type').robust_corr.agg(mean='mean', sem=sem).reset_index()
    fig.add_trace(go.Bar(x=stats_corr['hist_type'], y=stats_corr['mean'],
                         error_y=dict(array=stats_corr['sem'], symmetric=True), showlegend=False,
                         text=stats_corr['mean'].round(3), textposition='outside'))

    intact = corr_df.query('hist_type == "Intact"').sort_values('sub_emb').robust_corr.values
    scrambled = corr_df.query('hist_type == "Scrambled"').sort_values('sub_emb').robust_corr.values
    pt_p_val = ttest_rel(a=intact, b=scrambled, alternative='greater')[1]  # test if a > b
    w_p_val = wilcoxon(x=intact, y=scrambled, alternative='greater')[1]  # test if x > y
    fig.add_annotation(x=0.5, y=0.7, showarrow=False,
                       text=f'Intact > Scrambled<br>{p_val_text(pt_p_val)}; Paired-t<br>{p_val_text(w_p_val)}; Wilcoxon')

    for sub_emb in corr_df.sub_emb.unique():
        sub_corr_df = corr_df.query(f'sub_emb == "{sub_emb}"')
        fig.add_trace(go.Scatter(x=sub_corr_df['hist_type'], y=sub_corr_df['robust_corr'], mode='lines+markers',
                                 marker=dict(color='red'), opacity=0.3,
                                 name=f'{sub_emb}',
                                 # showlegend=False,
                                 ))

    fig.update_layout(width=400, height=800, font_size=15, title=dict(text=title, xanchor='center', x=0.5))
    fig.update_xaxes(title_text='History Type')
    fig.update_yaxes(title_text='Robust Correlation (Predicted RT, Observed RT)')
    fig.update_yaxes(range=[-0.2, 0.8])

    fig.show()


def compare_mses(values_df, title):
    values_df['sub_emb'] = values_df.sub_emb.apply(int).apply(str)
    values_df['block_emb'] = values_df.block_emb.apply(int).apply(str)

    fig = go.Figure()

    # Intact History Predictions
    intact_mses = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_mse(df, 'rt_target', 'rt_pred'))
    intact_mses.name = 'metric'
    intact_mses = intact_mses.reset_index()
    intact_mses = intact_mses.groupby(['sub_emb']).metric.mean()

    # Scrambled History Predictions
    scrambled_mses = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_mse(df, 'rt_target_bs', 'rt_pred_bs'))
    scrambled_mses.name = 'metric'
    scrambled_mses = scrambled_mses.reset_index()
    scrambled_mses = scrambled_mses.groupby(['sub_emb']).metric.mean()

    mse_df = pandas.DataFrame({'Intact': intact_mses, 'Scrambled': scrambled_mses}).reset_index()
    mse_df = pandas.melt(mse_df, id_vars=['sub_emb'], value_vars=['Intact', 'Scrambled'],
                         var_name='hist_type', value_name='mse')

    stats_mse = mse_df.groupby('hist_type').mse.agg(mean='mean', sem=sem).reset_index()
    fig.add_trace(go.Bar(x=stats_mse['hist_type'], y=stats_mse['mean'],
                         error_y=dict(array=stats_mse['sem'], symmetric=True), showlegend=False,
                         text=stats_mse['mean'].round(3), textposition='outside'))

    intact = mse_df.query('hist_type == "Intact"').sort_values('sub_emb').mse.values
    scrambled = mse_df.query('hist_type == "Scrambled"').sort_values('sub_emb').mse.values
    pt_p_val = ttest_rel(a=intact, b=scrambled, alternative='less')[1]  # test if a < b
    w_p_val = wilcoxon(x=intact, y=scrambled, alternative='less')[1]  # test if x < y
    fig.add_annotation(x=0.5, y=1.7, showarrow=False,
                       text=f'Intact < Scrambled<br>{p_val_text(pt_p_val)}; Paired-t<br>{p_val_text(w_p_val)}; Wilcoxon')

    for sub_emb in mse_df.sub_emb.unique():
        sub_mse_df = mse_df.query(f'sub_emb == "{sub_emb}"')
        fig.add_trace(go.Scatter(x=sub_mse_df['hist_type'], y=sub_mse_df['mse'], mode='lines+markers',
                                 marker=dict(color='red'), opacity=0.3,
                                 name=f'{sub_emb}',
                                 # showlegend=False,
                                 ))

    fig.update_layout(width=400, height=800, font_size=15, title=dict(text=title, xanchor='center', x=0.5))
    fig.update_xaxes(title_text='History Type')
    fig.update_yaxes(title_text='MSE (Predicted RT, Observed RT)')
    fig.show()


if __name__ == '__main__':
    for prefix, model_type in [
        # ('sans_block_v3', f'LSTM+MC<br>0to1Range'),
        # ('probed_invert', f'LSTM+MC<br>Seed = 0<br>Invert Probed'),
        # ('probed_minus_plus', f'LSTM+MC<br>Seed = 0<br>Minus Plus Probed'),
        # ('probed_plus_minus', f'LSTM+MC<br>Seed = 0<br>Plus Minus Probed'),
        ('reencode', f'LSTM+MC<br>-1to1Range'),
        # ('reencodev2', f'LSTM+MC<br>1to-1Range'),
    ]:
        result_folder = project_dir + f'basic_v2/results/{prefix}_bs=64_maxep=100_rt/'
        values = pandas.read_pickle(result_folder + f'mc-test_values.pkl')
        pred_cols = list(map(lambda x: f'rt_pred_{x}', range(len(mc_seeds))))
        values['rt_pred'] = values[pred_cols].mean(axis=1)
        pred_cols = list(map(lambda x: f'rt_pred_bs_{x}', range(len(mc_seeds))))
        values['rt_pred_bs'] = values[pred_cols].mean(axis=1)
        values['att'] = values.apply(get_actual_trial_type, axis=1)
        values['ptt'] = values.apply(get_perc_trial_type, axis=1)
        compare_correlations(values, model_type)
        compare_mses(values, model_type)
