import os
import uuid
import wandb
import numpy
import optuna
from pytorch_lightning import Trainer
from pytorch_lightning.loggers.wandb import WandbLogger
from pytorch_lightning.utilities.seed import seed_everything
from utils_processing.gpu_related import get_trainer_gpu_kwargs
from pytorch_lightning.callbacks import LearningRateMonitor, ModelCheckpoint
from uncertainty.models import MVETrainingPhase


def phase_one_training(model, train_dataloader, val_dataloader, num_epochs, result_dir, gpu_num, wandb_logger):
    lr_monitor = LearningRateMonitor()
    checkpoint_cb = ModelCheckpoint(monitor='phase1_val/loss', mode='min', dirpath=result_dir,
                                    filename='phase1_best-{epoch}')

    trainer = Trainer(default_root_dir=result_dir, max_epochs=num_epochs,
                      logger=[wandb_logger], log_every_n_steps=1, num_sanity_val_steps=0, deterministic=True,
                      callbacks=[lr_monitor, checkpoint_cb],
                      # limit_train_batches=1, limit_val_batches=1, limit_test_batches=1, limit_predict_batches=1,
                      **get_trainer_gpu_kwargs(gpu_num))
    trainer.fit(model, train_dataloaders=train_dataloader, val_dataloaders=val_dataloader)

    # Get the best epoch number and its loss based on validation evaluation
    files = os.listdir(result_dir)
    files = filter(lambda x: x.endswith('.ckpt'), files)
    files = filter(lambda x: x.startswith('phase1'), files)
    files = list(files)
    assert len(files) == 1
    ckpt = files[0]
    phase1_best_epoch = int(ckpt.split('.ckpt')[0].split('=')[1])
    os.rename(result_dir + ckpt, result_dir + 'phase1_best.ckpt')
    phase1_val_loss = checkpoint_cb.best_model_score.item()
    return phase1_val_loss, phase1_best_epoch


def split_results(prediction_results):
    targets, preds, variances = [], [], []
    for t, p, v in prediction_results:
        targets.append(t[:, 0])
        preds.append(p[:, 0])
        variances.append(v[:, 0])
    target = numpy.concatenate(targets)
    pred = numpy.concatenate(preds)
    var = numpy.concatenate(variances)
    return target, pred, var


def get_logvar_bias(model, train_dataloader, gpu_num):
    trainer = Trainer(enable_checkpointing=False, logger=False, deterministic=True, **get_trainer_gpu_kwargs(gpu_num))
    prediction_results = trainer.predict(model, dataloaders=train_dataloader)
    target, pred, _ = split_results(prediction_results)
    errors = (target - pred) ** 2
    return numpy.log(errors.mean())


def phase_two_training(model, train_dataloader, val_dataloader, num_epochs, result_dir, gpu_num, wandb_logger):
    lr_monitor = LearningRateMonitor()
    checkpoint_cb = ModelCheckpoint(monitor='phase2_val/loss', mode='min', dirpath=result_dir,
                                    filename='phase2_best-{epoch}')

    trainer = Trainer(default_root_dir=result_dir, max_epochs=num_epochs,
                      logger=[wandb_logger], log_every_n_steps=1, num_sanity_val_steps=0, deterministic=True,
                      callbacks=[lr_monitor, checkpoint_cb],
                      # limit_train_batches=1, limit_val_batches=1, limit_test_batches=1, limit_predict_batches=1,
                      **get_trainer_gpu_kwargs(gpu_num))
    trainer.fit(model, train_dataloaders=train_dataloader, val_dataloaders=val_dataloader)

    # Get the best epoch number and its loss based on validation evaluation
    files = os.listdir(result_dir)
    files = filter(lambda x: x.endswith('.ckpt'), files)
    files = filter(lambda x: x.startswith('phase2'), files)
    files = list(files)
    assert len(files) == 1
    ckpt = files[0]
    phase2_best_epoch = int(ckpt.split('.ckpt')[0].split('=')[1])
    os.rename(result_dir + ckpt, result_dir + 'phase2_best.ckpt')
    phase2_val_loss = checkpoint_cb.best_model_score.item()
    return phase2_val_loss, phase2_best_epoch


def execute_trial(model_class, model_kwargs, train_dataloader, val_dataloader,
                  seed: int, btest: int, bval: int, bs: int, num_epochs: int, watch_model: bool,
                  res_dir: str, study_name: str, extra_kwargs: dict, gpu_num: list[int], wandb_project) -> optuna.trial.FrozenTrial:
    phase1_model = model_class(**model_kwargs, phase=MVETrainingPhase.OnlyMean)

    seed_everything(0, workers=True)

    trial_id = f'{uuid.uuid4()}'
    result_dir = res_dir + f'{study_name}/{trial_id}/'
    os.makedirs(result_dir + 'wandb', exist_ok=True)

    config = {'model_class': model_class.__name__, 'metric': model_class.metric,
              'seed': seed, 'btest': btest, 'bval': bval, 'bs': bs, 'num_epochs': num_epochs,
              'result_dir': result_dir, 'trial_id': trial_id, 'log_code': False, 'watch_model': watch_model}
    config.update(extra_kwargs)

    run = wandb.init(dir=result_dir, config=config, project=wandb_project, group=study_name,
                     tags=[model_class.metric], settings=wandb.Settings(start_method="fork"))
    wandb_logger = WandbLogger(experiment=run)
    if watch_model:
        wandb.watch(phase1_model, log='all', log_freq=1)
    phase1_val_loss, phase1_best_epoch = phase_one_training(phase1_model, train_dataloader, val_dataloader, num_epochs,
                                                            result_dir, gpu_num, wandb_logger)
    if watch_model:
        wandb.unwatch(phase1_model)

    phase1_best_model = model_class.load_from_checkpoint(result_dir + 'phase1_best.ckpt')
    logvar_bias = get_logvar_bias(phase1_best_model, train_dataloader, gpu_num)

    phase2_model = model_class.load_from_checkpoint(result_dir + 'phase1_best.ckpt', phase=MVETrainingPhase.MeanAndVar)
    phase2_model.set_logvar_bias(logvar_bias)
    if watch_model:
        wandb.watch(phase2_model, log='all', log_freq=1)
    phase2_val_loss, phase2_best_epoch = phase_two_training(phase2_model, train_dataloader, val_dataloader, num_epochs,
                                                            result_dir, gpu_num, wandb_logger)
    if watch_model:
        wandb.unwatch(phase2_model)

    wandb.config.update({
        'phase1_val_loss': phase1_val_loss, 'phase1_best_epoch': phase1_best_epoch,
        'phase2_val_loss': phase2_val_loss, 'phase2_best_epoch': phase2_best_epoch,
    })
    wandb.finish()

    # Create trial with all parameters as user_attrs
    trial_attrs = config.copy()
    trial_attrs.update(phase2_model.hparams)
    trial_attrs.update({
        'phase1_val_loss': phase1_val_loss, 'phase1_best_epoch': phase1_best_epoch,
        'phase2_val_loss': phase2_val_loss, 'phase2_best_epoch': phase2_best_epoch,
    })
    if trial_attrs.get('phase'):
        trial_attrs['phase'] = trial_attrs['phase'].value
    trial = optuna.create_trial(value=phase2_val_loss, params={}, distributions={}, user_attrs={'config': trial_attrs})
    return trial
