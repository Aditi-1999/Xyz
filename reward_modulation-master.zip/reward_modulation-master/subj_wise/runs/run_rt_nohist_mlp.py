import argparse
from subj_wise.processor_rt_nohist_mlp import execute_study
from models.final import OnlyRTWithoutHistoryMLPBasicFinal
from utils_generic import send_message


if __name__ == '__main__':
    bs = 32
    num_epochs = 100
    prefix = 'subj_wise_nohist_mlp'

    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', dest='seed', type=int)
    parser.add_argument('--btest', dest='btest', type=int, action='append')
    parser.add_argument('--sub', dest='sub', type=int)
    args = parser.parse_args()

    for btest in args.btest:
        execute_study(OnlyRTWithoutHistoryMLPBasicFinal, args.seed, btest, bs, num_epochs, prefix, [0], args.sub)

    send_message(f'SubjectWise - {prefix} - seed = {args.seed}, btest = {args.btest}, sub = {args.sub} Finished')
