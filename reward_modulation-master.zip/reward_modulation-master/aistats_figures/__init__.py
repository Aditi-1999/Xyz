from utils_processing.metrics import compute_robust_corr, compute_mse, p_val_text, compute_auroc, compute_bce
from matplotlib import font_manager
from config import project_dir
import pandas
import numpy

num_subjects = {
    'srm': 24,
    'tms': 28,
}

num_blocks = {
    'srm': 6,
    'tms': 5
}

color = {
    'srm': 'blue',
    'tms': 'red',
}

mc_seeds = list(range(0, 1000, 10))  # 100 Dropout Samples

data_dir = project_dir + 'aistats_figures/data/'


def entropy(p):
    ent = -p * numpy.log(p) - (1-p) * numpy.log(1-p)
    return ent


def p_text(p_val):
    if p_val < 0.001:
        text = f'p < 0.001'
    elif p_val < 0.01:
        text = f'p = {p_val:.3f}'
    elif p_val < 0.05:
        text = f'p = {p_val:.3f}'
    else:
        text = f'p = n.s.'
    return text


def rt_file(loc):
    values = pandas.read_pickle(loc)
    pred_cols = list(map(lambda x: f'rt_pred_{x}', range(len(mc_seeds))))
    values['rt_pred'] = values[pred_cols].mean(axis=1)
    pred_cols = list(map(lambda x: f'rt_pred_bs_{x}', range(len(mc_seeds))))
    values['rt_pred_bs'] = values[pred_cols].mean(axis=1)
    return values


def acc_file(loc):
    values = pandas.read_pickle(loc)
    pred_cols = list(map(lambda x: f'acc_pred_{x}', range(len(mc_seeds))))
    values['acc_pred'] = values[pred_cols].applymap(sigmoid).mean(axis=1).apply(inverse_sigmoid)
    pred_cols = list(map(lambda x: f'acc_pred_bs_{x}', range(len(mc_seeds))))
    values['acc_pred_bs'] = values[pred_cols].applymap(sigmoid).mean(axis=1).apply(inverse_sigmoid)
    return values


def sigmoid(x):
    return 1 / (1 + numpy.exp(-x))


def inverse_sigmoid(x):
    return numpy.log(x / (1-x))


def compute_robust_corr_only(*args):
    return compute_robust_corr(*args)['corr']


def get_sub_metrics(values_df, experiment, metric, measure, shuffled):
    if experiment == 'srm':
        group_columns = ['sub_num', 'seed', 'btest']
    elif experiment == 'tms':
        group_columns = ['subject_num', 'seed', 'ses_emb', 'btest']
    else:
        raise Exception()

    if shuffled and metric == 'rt':
        data_columns = ['rt_target_bs', 'rt_pred_bs']
    elif not shuffled and metric == 'rt':
        data_columns = ['rt_target', 'rt_pred']
    elif shuffled and metric == 'acc':
        data_columns = ['acc_target_bs', 'acc_pred_bs']
    elif not shuffled and metric == 'acc':
        data_columns = ['acc_target', 'acc_pred']

    if measure == 'corr':
        assert metric == 'rt'
        func = compute_robust_corr_only
    elif measure == 'mse':
        assert metric == 'rt'
        func = compute_mse
    elif measure == 'auroc':
        assert metric == 'acc'
        func = compute_auroc
    elif measure == 'bce':
        assert metric == 'acc'
        func = compute_bce

    measures = values_df.groupby(group_columns).apply(
        lambda df: func(df, *data_columns))
    measures.name = 'metric'
    measures = measures.reset_index()
    measures = measures.groupby(group_columns[0]).metric.mean()
    return measures
