from utils_data.msc_eda import get_probed_side_mscs
import pandas
from utils_processing import mc_seeds
from utils_processing.metrics import compute_element_mse, compute_element_bce, p_val_text, compute_robust_corr
from config import project_dir
from utils_data import sd_types
from utils_data.helper import serial_dependence_measure, sigmoid, inverse_sigmoid, probed_side, true_reward, \
    perc_reward, get_actual_trial_type, get_perc_trial_type
import plotly.graph_objects as go
from itertools import product

bs = 64
num_epochs = 100


def common(values_df, deg_window, start, end, split_col, sd_type, metric) -> pandas.DataFrame:
    assert metric in ['rt', 'acc']
    values_df['att'] = values_df.apply(get_actual_trial_type, axis=1)
    values_df['ptt'] = values_df.apply(get_perc_trial_type, axis=1)
    values_df['side_probed'] = values_df['side_probed'].apply(probed_side)
    values_df['reward_vr_fx'] = values_df['reward_vr_fx'].apply(true_reward)
    values_df['perc_vr_gt_fx'] = values_df['perc_vr_gt_fx'].apply(perc_reward)

    # MSc Information
    msc_df = get_probed_side_mscs(deg_window, start, end)
    msc_df['valid_count'] = msc_df.valid_phis.apply(len)
    msc_df['probed_count'] = msc_df.probed_phis.apply(len)
    msc_df.set_index(['sub_num', 'gain_block_num', 'trial_num'], inplace=True)
    valid_counts, probed_counts = msc_df.valid_count.to_dict(), msc_df.probed_count.to_dict()

    # Merge the two
    values_df['valid_count'] = values_df.apply(
        lambda row: valid_counts.get((row.sub_num, row.gain_block_num, row.trial_num)), axis=1)
    values_df['probed_count'] = values_df.apply(
        lambda row: probed_counts.get((row.sub_num, row.gain_block_num, row.trial_num)), axis=1)
    merged_df = values_df.dropna(subset=['valid_count'], axis=0).copy()

    actual = 'actual_bce' if metric == 'acc' else 'actual_mse'
    shuffled = 'shuffled_bce' if metric == 'acc' else 'shuffled_mse'
    merged_df.dropna(subset=[split_col], inplace=True)
    aggregated = merged_df.groupby(['sub_num', 'gain_block_num', split_col]) \
        .agg({actual: 'mean', shuffled: 'mean', 'valid_count': 'sum', 'probed_count': 'sum'}) \
        .reset_index()
    aggregated['sd_measure'] = serial_dependence_measure(sd_type, aggregated[actual], aggregated[shuffled])
    aggregated['prop_mscs'] = aggregated['probed_count'] / aggregated['valid_count']
    aggregated = aggregated.groupby(['sub_num', split_col]) \
        .agg({'sd_measure': 'mean', 'prop_mscs': 'mean'}) \
        .reset_index()
    zero_sub_nums = aggregated[aggregated.prop_mscs == 0].sub_num.unique()
    return aggregated[~aggregated.sub_num.isin(zero_sub_nums)]


def plot_figure(aggregated, split_col, metric, x_title, deg_window, start, end, sd_type):
    assert metric in ['rt', 'acc']
    fig = go.Figure()
    titles = []

    for val in aggregated[split_col].unique():
        split = aggregated[aggregated[split_col] == val].copy()
        fig.add_trace(go.Scatter(
            x=split['prop_mscs'], y=split['sd_measure'], name=val,
            mode='markers', marker=dict(size=15),
        ))
        rcorr = compute_robust_corr(split, 'prop_mscs', 'sd_measure', 'less')
        title = f'{val}: R.Corr = {rcorr["corr"]:.3f}, {p_val_text(rcorr["pval"])} for R.Corr < 0'
        titles.append(title)

    title = f'{"RT" if metric == "rt" else "Acc"}<br>' + '<br>'.join(titles)
    fig.update_layout(font_size=12, title=dict(text=title, xanchor='center', x=0.5),
                      legend=dict(yanchor='top', y=0.99, xanchor='left', x=0.01, title_text=x_title),
                      width=800, height=600)
    fig.update_xaxes(title_text=f'Prop(MScs) within {2 * deg_window}° window around Probed Side<br>'
                                f'[{start}, {end}] ms after Probe Onset in Current Trial',
                     range=[-0.1, 1.1])
    sd_text = sd_types[sd_type]
    fig.update_yaxes(title_text=f'{sd_text} - {"MSE" if metric == "rt" else "BCE"}<br>in Current Trial at Probed Side')
    fig.show()


def trial_msc_sd_rt(values_df: pandas.DataFrame, split_col, x_title, deg_window, start, end, sd_type):
    values_df = values_df.groupby(['sub_num', 'gain_block_num', 'trial_num']) \
        .agg({'rt_target': 'mean', 'rt_pred': 'mean',
              'rt_target_bs': 'mean', 'rt_pred_bs': 'mean',
              'side_probed': 'mean', 'reward_vr_fx': 'mean', 'perc_vr_gt_fx': 'mean'}) \
        .reset_index()  # Averaging values across seeds - as an estimate of the actual values
    values_df['actual_mse'] = compute_element_mse(values_df, 'rt_target', 'rt_pred')
    values_df['shuffled_mse'] = compute_element_mse(values_df, 'rt_target_bs', 'rt_pred_bs')
    aggregated = common(values_df, deg_window, start, end, split_col, sd_type, 'rt')
    plot_figure(aggregated, split_col, 'rt', x_title, deg_window, start, end, sd_type)


def trial_msc_sd_acc(values_df: pandas.DataFrame, split_col, x_title, deg_window, start, end, sd_type):
    values_df['acc_pred'] = sigmoid(values_df.acc_pred)  # Converting to probabilities for averaging
    values_df['acc_pred_bs'] = sigmoid(values_df.acc_pred_bs)
    values_df = values_df.groupby(['sub_num', 'gain_block_num', 'trial_num']) \
        .agg({'acc_target': 'mean', 'acc_pred': 'mean',
              'acc_target_bs': 'mean', 'acc_pred_bs': 'mean',
              'side_probed': 'mean', 'reward_vr_fx': 'mean', 'perc_vr_gt_fx': 'mean'}) \
        .reset_index()  # Averaging values across seeds - as an estimate of the actual values
    values_df['acc_pred'] = inverse_sigmoid(values_df.acc_pred)  # Converting to logits for loss calculations
    values_df['acc_pred_bs'] = inverse_sigmoid(values_df.acc_pred_bs)
    values_df['actual_bce'] = compute_element_bce(values_df, 'acc_target', 'acc_pred')
    values_df['shuffled_bce'] = compute_element_bce(values_df, 'acc_target_bs', 'acc_pred_bs')
    aggregated = common(values_df, deg_window, start, end, split_col, sd_type, 'acc')
    plot_figure(aggregated, split_col, 'acc', x_title, deg_window, start, end, sd_type)


def read_rt_file(pref):
    values: pandas.DataFrame = pandas.read_pickle(project_dir + f'basic_v2/results/'
                                                  f'{pref}_bs={bs}_maxep={num_epochs}_rt/mc-test_values.pkl')
    pred_cols = list(map(lambda x: f'rt_pred_{x}', range(len(mc_seeds))))
    values['rt_pred'] = values[pred_cols].mean(axis=1)
    pred_cols = list(map(lambda x: f'rt_pred_bs_{x}', range(len(mc_seeds))))
    values['rt_pred_bs'] = values[pred_cols].mean(axis=1)
    return values


def read_acc_file(pref):
    values: pandas.DataFrame = pandas.read_pickle(project_dir + f'basic_v2/results/'
                                                  f'{pref}_bs={bs}_maxep={num_epochs}_acc/mc-test_values.pkl')
    pred_cols = list(map(lambda x: f'acc_pred_{x}', range(len(mc_seeds))))
    values['acc_pred'] = values[pred_cols].applymap(sigmoid).mean(axis=1).apply(inverse_sigmoid)
    pred_cols = list(map(lambda x: f'acc_pred_bs_{x}', range(len(mc_seeds))))
    values['acc_pred_bs'] = values[pred_cols].applymap(sigmoid).mean(axis=1).apply(inverse_sigmoid)
    return values


if __name__ == '__main__':
    prefix = 'reencode'
    en = 450
    cols = [
        ('side_probed', 'Probed Side'),
        # ('reward_vr_fx', 'True Reward'),
        # ('perc_vr_gt_fx', 'Perceived Reward'),
        # ('att', 'True Attended'),
        # ('ptt', 'Perceived Attended'),
    ]
    degws = [
        30,
        45,
        60,
        90,
    ]
    strts = [
        250,
        100,
    ]
    sdtyps = [
        'difference',
        'modulated_shuffled',
        'modulated_actual',
        'modulated_sum',
    ]

    rt_values = read_rt_file(prefix)
    for (col, name), degw, strt, sdtyp in product(cols, degws, strts, sdtyps):
        trial_msc_sd_rt(rt_values.copy(), col, name, degw, strt, en, sdtyp)

    acc_values = read_acc_file(prefix)
    for (col, name), degw, strt, sdtyp in product(cols, degws, strts, sdtyps):
        trial_msc_sd_acc(acc_values.copy(), col, name, degw, strt, en, sdtyp)


def plot_avg_x_avg_y(aggregated, split_col, metric, x_title, deg_window, start, end, sd_type):
    assert metric in ['rt', 'acc']
    fig = go.Figure()

    aggregated.set_index('sub_num', inplace=True)
    condition_names = aggregated[split_col].unique()
    assert len(condition_names) == 2
    cond1 = aggregated[aggregated[split_col] == condition_names[0]]
    cond2 = aggregated[aggregated[split_col] == condition_names[1]]
    cond1.drop(columns=[split_col], inplace=True)
    cond2.drop(columns=[split_col], inplace=True)
    final = (cond1 + cond2) / 2

    fig.add_trace(go.Scatter(
        x=final['prop_mscs'], y=final['sd_measure'],
        mode='markers', marker=dict(size=15),
    ))
    rcorr = compute_robust_corr(final, 'prop_mscs', 'sd_measure', 'less')

    title = f'{"RT" if metric == "rt" else "Acc"}<br>{x_title}: R.Corr = {rcorr["corr"]:.3f}, ' \
            f'{p_val_text(rcorr["pval"])} for R.Corr < 0'
    fig.update_layout(font_size=12, title=dict(text=title, xanchor='center', x=0.5),
                      # legend=dict(yanchor='top', y=0.99, xanchor='left', x=0.01, title_text=x_title),
                      width=800, height=600)
    fig.update_xaxes(title_text=f'Prop(MScs) within {2 * deg_window}° window around Probed Side<br>'
                                f'[{start}, {end}] ms after Probe Onset in Current Trial',
                     range=[-0.1, 1.1])
    sd_text = sd_types[sd_type]
    fig.update_yaxes(title_text=f'{sd_text} - {"MSE" if metric == "rt" else "BCE"}<br>in Current Trial at Probed Side')
    fig.show()


def plot_pooled_correlation(aggregated, split_col, metric, x_title, deg_window, start, end, sd_type):
    assert metric in ['rt', 'acc']
    fig = go.Figure()

    for val in aggregated[split_col].unique():
        split = aggregated[aggregated[split_col] == val].copy()
        fig.add_trace(go.Scatter(
            x=split['prop_mscs'], y=split['sd_measure'], name=val,
            mode='markers', marker=dict(size=15),
        ))

    rcorr = compute_robust_corr(aggregated, 'prop_mscs', 'sd_measure', 'less')
    title = f'{"RT" if metric == "rt" else "Acc"}<br>Pooled R.Corr = {rcorr["corr"]:.3f}, ' \
            f'{p_val_text(rcorr["pval"])} for R.Corr < 0'
    fig.update_layout(font_size=12, title=dict(text=title, xanchor='center', x=0.5),
                      legend=dict(yanchor='top', y=0.99, xanchor='left', x=0.01, title_text=x_title),
                      width=800, height=600)
    fig.update_xaxes(title_text=f'Prop(MScs) within {2 * deg_window}° window around Probed Side<br>'
                                f'[{start}, {end}] ms after Probe Onset in Current Trial',
                     range=[-0.1, 1.1])
    sd_text = sd_types[sd_type]
    fig.update_yaxes(title_text=f'{sd_text} - {"MSE" if metric == "rt" else "BCE"}<br>in Current Trial at Probed Side')
    fig.show()
