import shap
import pandas
import torch
from tqdm import tqdm
from config import project_dir
from utils_data import num_gain_blocks
from basic.analysis.model_choose import get_trials_for_T
from basic.analysis.shap_utils import save_predictions_if_missing_rt, get_func_from_str, get_background, get_test, \
    correctness_check_rt as correctness_check
from utils_processing.common_proc import get_train_test_split_df, read_data_and_preprocess, prespast_columns
from multiprocessing import get_context
from basic.analysis.rt.shap_rt_models import SHAPForRTSansBlock

task_vars = ['reward_vr_fx', 'change_fx', 'change_vr', 'side_probed', 'stimulus_time', 'is_correct', 'is_wrong',
             'accrued_score']


def process_one_model(seed, b, model_class, trial, data_df, T):
    config = trial['user_attrs_config']
    sub_emb_dim = config['sub_emb_dim']
    sub_cols = list(map(lambda x: f'sub{x}', range(1, sub_emb_dim + 1)))
    time_steps = list(range(0, T + 1))
    lstm_vars = prespast_columns[model_class.lstm_variable()]

    # Create SHAP model
    actual_model = model_class.load_from_checkpoint(trial['folder_path'] + 'best.ckpt')

    model = SHAPForRTSansBlock(T=T, rnn_input_size=len(lstm_vars), rnn_hidden_size=config['rnn_hidden_size'],
                               rnn_layers=config['rnn_layers'], rnn_bidirectional=config['rnn_bidirectional'],
                               rnn_initial=config['rnn_initial'], rnn_init_hidden_sizes=config['rnn_init_hidden_sizes'],
                               rnn_init_activation_func=get_func_from_str(config['rnn_init_activation_func']),
                               rnn_init_output_activation_func=get_func_from_str(config['rnn_init_output_activation_func']),
                               hidden_sizes=config['hidden_sizes'], activation_func=get_func_from_str(config['activation_func']),
                               dropout=config['dropout'],
                               lr=0, cycle_lr=False, cycle_config={}, exp_lr=False, l2reg=False, l2weight=0, mseed=0)
    model.load_model(actual_model)

    # Prepare data
    d = data_df.reset_index()
    sub_embeddings = actual_model.embeddings['sub_embedding'](torch.tensor(d['sub_emb'].values, dtype=torch.int64))
    data_df[sub_cols] = pandas.DataFrame(data=sub_embeddings.detach().numpy(), index=data_df.index)
    lstm_cols = []
    for task_var, lstm_var in zip(task_vars, lstm_vars):
        new_names = list(map(lambda x: f'{task_var}{x}', time_steps))
        data_df[new_names] = pandas.DataFrame(data_df[lstm_var].tolist(), index=data_df.index)
        lstm_cols.extend(new_names)

    # Prepare background and test for SHAP
    train_test_split_df = get_train_test_split_df(seed)
    test_block = 'block{}'.format(b)
    test_idxs = list(train_test_split_df[['sub_emb', test_block]].itertuples(index=False, name=None))

    _, background = get_background(data_df, test_idxs, lstm_cols, sub_cols, ['trial_num'])
    test_df, test = get_test(data_df, test_idxs, lstm_cols, sub_cols, ['trial_num'])
    background = background[:2]
    test = test[:2]

    # Correctness check
    correctness_check(model, test, trial, seed, b)

    # Get SHAP values
    model = model.float()
    background = [x.float() for x in background]
    test = [x.float() for x in test]

    e = shap.GradientExplainer(model, background, batch_size=256)
    shap_values = e.shap_values(test, nsamples=background[0].shape[0])

    lstm_var_df = pandas.DataFrame(test[0].detach().numpy(), columns=lstm_cols)
    sub_var_df = pandas.DataFrame(test[1].detach().numpy(), columns=sub_cols)

    lstm_shap_cols = list(map(lambda x: x + '_shap', lstm_cols))
    sub_shap_cols = list(map(lambda x: x + '_shap', sub_cols))

    lstm_shap_df = pandas.DataFrame(shap_values[0], columns=lstm_shap_cols)
    sub_shap_df = pandas.DataFrame(shap_values[1], columns=sub_shap_cols)

    concatenate_df = pandas.concat([lstm_var_df, sub_var_df, lstm_shap_df, sub_shap_df], axis=1)
    concatenate_df['seed'] = seed
    concatenate_df['b'] = b
    concatenate_df['sub_emb'] = test_df.sub_emb.tolist()
    concatenate_df['block_emb'] = test_df.block_emb.tolist()
    concatenate_df['trial_num'] = test_df.trial_num.tolist()
    return concatenate_df


def get_shap_values(model_class, seed_list, prefix, bs, num_epochs, T):
    trials = get_trials_for_T(seed_list, prefix, bs, num_epochs, T, metric='rt')

    proc_df = read_data_and_preprocess(T, return_raw=False)
    proc_df.dropna(subset=['response_time'], inplace=True)

    save_predictions_if_missing_rt(model_class, seed_list, trials, bs, num_epochs, proc_df)

    shap_dfs = []
    with get_context('spawn').Pool(processes=5) as pool:
        results = []
        for seed in tqdm(seed_list, desc='Seed Dispatch'):
            for b in tqdm(range(num_gain_blocks), desc='Block Dispatch'):
                trial = trials.query(f'seed == {seed} & btest == {b}').iloc[0].to_dict()
                result = pool.apply_async(process_one_model, (seed, b, model_class, trial, proc_df.copy(), T))
                results.append(result)

        for result in tqdm(results, desc='Parallel Results'):
            concatenate_df = result.get(timeout=None)  # should we put a timelimit?
            shap_dfs.append(concatenate_df)

    all_shap_df = pandas.concat(shap_dfs)

    config = trial['user_attrs_config']
    sub_emb_dim = config['sub_emb_dim']
    sub_shap_cols = list(map(lambda x: f'sub{x}_shap', range(1, sub_emb_dim + 1)))
    all_shap_df['sub_shap'] = all_shap_df[sub_shap_cols].sum(axis=1).tolist()

    time_steps = list(range(0, T + 1))
    for time in time_steps:
        cols = list(map(lambda v: f'{v}{time}_shap', task_vars))
        all_shap_df[f't{time}_shap'] = all_shap_df[cols].sum(axis=1)

    for var in task_vars:
        cols = list(map(lambda t: f'{var}{t}_shap', time_steps))
        all_shap_df[f'{var}_shap'] = all_shap_df[cols].sum(axis=1)

    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_rt'
    all_shap_df.to_csv(project_dir + f'basic/results/{folder_name}/T={T}-shap_gradient.csv', index=False)


if __name__ == '__main__':
    from models.final import OnlyRTWithHistoryBasicFinal
    get_shap_values(OnlyRTWithHistoryBasicFinal, [0, 10, 20], 'sans_block', 64, 100, T=3)
