import pandas
import plotly.express as px
import plotly.graph_objs as go
from config import project_dir
from utils_processing import mc_seeds
from scipy.stats import wilcoxon, ttest_rel
from utils_data.helper import sigmoid, inverse_sigmoid
from utils_processing.metrics import compute_auroc, compute_bce, p_val_text


def get_actual_metrics(values_df):
    actual_aurocs = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_auroc(df, 'acc_target', 'acc_pred'))
    actual_aurocs.name = 'metric'
    actual_aurocs = actual_aurocs.reset_index()
    actual_aurocs = actual_aurocs.groupby(['sub_emb']).metric.mean()

    actual_bces = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_bce(df, 'acc_target', 'acc_pred'))
    actual_bces.name = 'metric'
    actual_bces = actual_bces.reset_index()
    actual_bces = actual_bces.groupby(['sub_emb']).metric.mean()

    return actual_aurocs, actual_bces


def compare_metrics(common_path, subjwise_path):
    common_values_df = pandas.read_pickle(common_path + f'mc-test_values.pkl')
    subjwise_values_df = pandas.read_pickle(subjwise_path + f'mc-test_values.pkl')

    pred_cols = list(map(lambda x: f'acc_pred_{x}', range(len(mc_seeds))))
    common_values_df['acc_pred'] = common_values_df[pred_cols].applymap(sigmoid).mean(axis=1).apply(inverse_sigmoid)
    subjwise_values_df['acc_pred'] = subjwise_values_df[pred_cols].applymap(sigmoid).mean(axis=1).apply(inverse_sigmoid)

    common_auroc, common_bce = get_actual_metrics(common_values_df)
    subj_auroc, subj_bce = get_actual_metrics(subjwise_values_df)

    # AUROC Scatter
    auroc_range = [0.45, 0.9]
    auroc_df = pandas.DataFrame({'common': common_auroc, 'subj': subj_auroc}).reset_index()
    pt_p_val = ttest_rel(a=auroc_df['common'], b=auroc_df['subj'], alternative='greater')[1]  # test if a > b
    w_p_val = wilcoxon(x=auroc_df['common'], y=auroc_df['subj'], alternative='greater')[1]  # test if x > y
    title = f'AUROC (Predicted Acc, Observed Acc)<br>With > Without | ' \
            f'{p_val_text(pt_p_val)}; Paired-t | {p_val_text(w_p_val)}; Wilcoxon'
    fig = px.scatter(auroc_df, x='common', y='subj',
                     labels={'common': 'Common Model With Subject Embeddings',
                             'subj': 'Common Model Without Subject Embeddings'})
    fig.add_trace(go.Scatter(x=auroc_range, y=auroc_range, mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_layout(width=900, height=800, font_size=15, xaxis_range=auroc_range, yaxis_range=auroc_range,
                      title=dict(text=title, xanchor='center', x=0.5))
    fig.show()

    # BCE Scatter
    bce_range = [0.4, 0.75]
    bce_df = pandas.DataFrame({'common': common_bce, 'subj': subj_bce}).reset_index()
    pt_p_val = ttest_rel(a=bce_df['common'], b=bce_df['subj'], alternative='less')[1]  # test if a < b
    w_p_val = wilcoxon(x=bce_df['common'], y=bce_df['subj'], alternative='less')[1]  # test if x < y
    title = f'BCE (Predicted Acc, Observed Acc)<br>With < Without | ' \
            f'{p_val_text(pt_p_val)}; Paired-t | {p_val_text(w_p_val)}; Wilcoxon'
    fig = px.scatter(bce_df, x='common', y='subj',
                     labels={'common': 'Common Model With Subject Embeddings',
                             'subj': 'Common Model Without Subject Embeddings'})
    fig.add_trace(go.Scatter(x=bce_range, y=bce_range, mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_layout(width=900, height=800, font_size=15, xaxis_range=bce_range, yaxis_range=bce_range,
                      title=dict(text=title, xanchor='center', x=0.5))
    fig.show()


if __name__ == '__main__':
    compare_metrics(common_path=project_dir + f'basic_v2/results/sans_block_v3_bs=64_maxep=100_acc/',
                    subjwise_path=project_dir + f'basic_v2/results/sans_se_bs=64_maxep=100_acc/')
