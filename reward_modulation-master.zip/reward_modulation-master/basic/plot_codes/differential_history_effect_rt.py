import pandas
import plotly.graph_objs as go
from config import project_dir
from scipy.stats import sem, wilcoxon, ttest_rel
from utils_processing.metrics import compute_mse, p_val_text


def get_trial_type(row):
    # if row['reward_vr_fx'] == 0 and row['side_probed'] == 0:
    #     # Reward@VR<FX and FX probed
    #     return 'valid'
    if row['reward_vr_fx'] == 1 and row['side_probed'] == 1:
        # Reward@VR>FX and VR probed
        return 'valid'
    # if row['reward_vr_fx'] == 0 and row['side_probed'] == 1:
    #     # Reward@VR<FX and VR probed
    #     return 'invalid'
    if row['reward_vr_fx'] == 1 and row['side_probed'] == 0:
        # Reward@VR>FX and FX probed
        return 'invalid'
    return pandas.NA


def get_main_df(df, metric):
    valid = df.loc[:, 'valid']
    invalid = df.loc[:, 'invalid']

    df = pandas.DataFrame({'Valid': valid, 'Invalid': invalid}).reset_index()
    df = pandas.melt(df, id_vars=['sub_emb'], value_vars=['Valid', 'Invalid'],
                     var_name='validity', value_name=metric)
    return df


def plot_mean_stderr(fig, df, metric):
    stats = df.groupby('validity')[metric].agg(mean='mean', sem=sem).reset_index()
    fig.add_trace(go.Bar(x=stats['validity'], y=stats['mean'],
                         error_y=dict(array=stats['sem'], symmetric=True), showlegend=False,
                         text=stats['mean'].round(3), textposition='outside'))


def plot_p(fig, df, metric, y):
    cued = df.query('validity == "Valid"').sort_values('sub_emb')[metric].values
    uncued = df.query('validity == "Invalid"').sort_values('sub_emb')[metric].values
    pt_p_val = ttest_rel(a=cued, b=uncued, alternative='two-sided')[1]  # test if a != b
    w_p_val = wilcoxon(x=cued, y=uncued, alternative='two-sided')[1]  # test if x != y
    test = 'Valid!=Invalid'
    fig.add_annotation(x=0.5, y=y, showarrow=False,
                       text=f'{test}<br>{p_val_text(pt_p_val)}; Paired-t<br>{p_val_text(w_p_val)}; Wilcoxon')


def plot_subs(fig, df, metric):
    for sub_emb in df.sub_emb.unique():
        sub_df = df.query(f'sub_emb == "{sub_emb}"')
        fig.add_trace(go.Scatter(x=sub_df['validity'], y=sub_df[metric], mode='lines+markers',
                                 marker=dict(color='red'), opacity=0.3,
                                 name=f'{sub_emb}',
                                 # showlegend=False,
                                 ))


def compare_mses(values_df, title):
    fig = go.Figure()

    actual_mses = values_df.groupby(['sub_emb', 'seed', 'block_emb', 'validity']).apply(lambda df: compute_mse(df, 'rt_target', 'rt_pred'))
    actual_mses.name = 'metric'
    actual_mses = actual_mses.reset_index()
    actual_mses = actual_mses.groupby(['sub_emb', 'validity']).metric.mean()

    shuffled_mses = values_df.groupby(['sub_emb', 'seed', 'block_emb', 'validity']).apply(lambda df: compute_mse(df, 'rt_target_bs', 'rt_pred_bs'))
    shuffled_mses.name = 'metric'
    shuffled_mses = shuffled_mses.reset_index()
    shuffled_mses = shuffled_mses.groupby(['sub_emb', 'validity']).metric.mean()

    sd_measure = (actual_mses - shuffled_mses) / (actual_mses + shuffled_mses)
    measure = '(Actual MSE - Shuffled MSE) / (Actual MSE + Shuffled MSE)'

    sd_df = get_main_df(sd_measure, 'sd_measure')
    plot_mean_stderr(fig, sd_df, 'sd_measure')
    plot_p(fig, sd_df, 'sd_measure', 0.1)
    plot_subs(fig, sd_df, 'sd_measure')

    fig.update_layout(width=400, height=800, font_size=15, title=dict(text=title, xanchor='center', x=0.5))
    fig.update_xaxes(title_text='Validity')
    fig.update_yaxes(title_text=measure)
    fig.update_yaxes(range=[-0.35, 0.15])
    fig.show()


if __name__ == '__main__':
    model_type = f'Sans Block'
    result_folder = project_dir + f'basic/results/sans_block_bs=64_maxep=100_rt/'

    values: pandas.DataFrame = pandas.read_pickle(result_folder + f'overall-values.pkl')
    values['sub_emb'] = values.sub_emb.apply(int).apply(str)
    values['block_emb'] = values.block_emb.apply(int).apply(str)
    values['validity'] = values.apply(get_trial_type, axis=1)
    values.dropna(subset=['validity'], inplace=True)

    compare_mses(values.copy(), model_type)
