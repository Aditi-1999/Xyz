from config import project_dir
import matplotlib.patches as mpatches
from matplotlib.axes import Axes
from numpy.typing import NDArray
import matplotlib.pyplot as plt
import seaborn as sns
import pandas

font_size = 13
lfont_size = 15

datum = {
    'x_title': 'History Type',
    'y_title': 'Aleatoric Uncertainty in Accuracy',
    'y_range': [0.3, 0.8],
    'y_p': 0.7,
    'violins': [
        {
            'x': '',
            'actual': {'0': 0.5372004133128061, '1': 0.6396870278987605, '10': 0.6427518677714765, '11': 0.6625617995412616, '12': 0.6311117102360465, '13': 0.4993141488361488, '14': 0.596229974412785, '15': 0.6471510880830648, '16': 0.5866972436259563, '17': 0.6110522039231051, '18': 0.6193034956367041, '19': 0.5806918647330873, '2': 0.57002254171929, '20': 0.6434689554497874, '21': 0.6287961832391609, '22': 0.6186244541427214, '23': 0.5155750221453169, '3': 0.5554296593794977, '4': 0.6250831875008909, '5': 0.46544824725075895, '6': 0.6645222328824762, '7': 0.6320460046437517, '8': 0.6804808839315881, '9': 0.6081877993258917},
            'shuffled': {'0': 0.537310323651674, '1': 0.6372194111110767, '10': 0.6418290175460295, '11': 0.6632598086468738, '12': 0.6326991489537873, '13': 0.5049357022599409, '14': 0.5997311336692233, '15': 0.6469156276682126, '16': 0.5913254164282065, '17': 0.6128841619867625, '18': 0.6255323485717227, '19': 0.5841029115807336, '2': 0.5740245156878083, '20': 0.6437644109171168, '21': 0.6303111533876924, '22': 0.6188228121247126, '23': 0.5151677091224219, '3': 0.5562194919577106, '4': 0.6268350405656494, '5': 0.4760518615526786, '6': 0.6639075847704392, '7': 0.6358346143367031, '8': 0.6805643330280886, '9': 0.6146554588272697},
            'pval': 0.0006189942359924316,
        }
    ]
}

color = [0, 0, 1, 0.2]


def p_val_text(p_val):
    if p_val < 0.001:
        text = f'***p < 0.001'
    elif p_val < 0.01:
        text = f'**p = {p_val:.3f}'
    elif p_val < 0.05:
        text = f'*p = {p_val:.3f}'
    else:
        raise Exception()  # we use bold by default, so
    return text


def plot_metrics(ax: Axes):
    p_y = datum['y_p']
    for violin in datum['violins']:
        actual = pandas.Series(violin['actual'])
        actual.name = 'values'
        actual.index.name = 'sub_num'
        actual = actual.reset_index()
        actual['x'] = f'Intact'
        shuffled = pandas.Series(violin['shuffled'])
        shuffled.name = 'values'
        shuffled.index.name = 'sub_num'
        shuffled = shuffled.reset_index()
        shuffled['x'] = f'Scrambled'
        df = pandas.concat([actual, shuffled], axis=0)
        sns.violinplot(data=df, ax=ax, x='x', y='values',
                       color=color, saturation=1, inner=None)
        sns.boxplot(data=df, ax=ax, x='x', y='values',
                    color='black', fill=False, width=0.2)
        ptext = p_val_text(violin['pval'])
        ax.text(0.5, p_y, s=ptext, ha='center', va='center', fontsize=font_size, fontweight='bold')

    for collection in ax.collections[::2]:
        collection.set_edgecolor('none')
    for collection in ax.collections[1::2]:
        collection.set_facecolor('none')
        collection.set_edgecolor(color)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.set_ylim(*datum['y_range'])
    ax.set_ylabel(datum['y_title'], fontsize=font_size)
    ax.set_xlabel(datum['x_title'], fontsize=font_size)
    for tick in ax.get_xticklabels() + ax.get_yticklabels():
        tick.set_fontsize(font_size)


def plot():
    plt.rcParams['axes.unicode_minus'] = False
    plt.rcParams['font.sans-serif'] = "Arial"
    plt.rcParams['font.family'] = "sans-serif"
    fig, axs = plt.subplots(1, 1, figsize=(4, 4))

    plot_metrics(axs)

    plt.tight_layout(rect=[0, 0, 1, 0.925])
    plt.savefig(project_dir + 'basic_v2/analyses/sd_analysis/alea.png', dpi=400)


if __name__ == '__main__':
    plot()

