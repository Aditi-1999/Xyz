from utils_data import num_gain_blocks
from basic_v2 import optuna_storage
import optuna
import pandas


def get_hyper_config(user_attrs_config, hp_keys):
    hyper_config = {}
    for key in hp_keys:
        hyper_config[key] = user_attrs_config[key]
    return str(hyper_config)  # to facilitate grouping


def hp_checks(seed_list, prefix, bs, num_epochs, trial_filter, metric, hp_keys: list[str]):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_{metric}'
    storage = optuna.storages.get_storage(optuna_storage)
    all_dfs = []
    for seed in seed_list:
        for b in range(num_gain_blocks):
            study_name = f'{folder_name}_{seed}_{b}'
            study = optuna.load_study(study_name=study_name, storage=storage)
            df = study.trials_dataframe()
            df = df[df.user_attrs_config.apply(trial_filter)]
            df['folder_name'] = folder_name
            df['study_name'] = study_name
            df['seed'] = seed
            df['b'] = b
            all_dfs.append(df)
    results_df = pandas.concat(all_dfs, ignore_index=True)
    results_df['hyper_config'] = results_df.user_attrs_config.apply(lambda c: get_hyper_config(c, hp_keys))
    counts: pandas.Series = results_df.groupby(['seed', 'hyper_config']).number.count()
    check = (counts == num_gain_blocks).all()
    if not check:  # we are in trouble
        troubles = counts[counts != num_gain_blocks]
        raise AssertionError(f'Some hyperparameters not run for some blocks!\n{troubles}')
    return results_df


if __name__ == '__main__':
    prefix = 'sans_block_v3'
    hp_keys = ['T', 'rnn_layers', 'rnn_bidirectional', 'rnn_hidden_size', 'hidden_sizes', 'dropout']
    for metric in ['rt', 'acc']:
        hp_checks([0, 10, 20], prefix, 64, 100, lambda d: True, metric, hp_keys)
        hp_checks([0, 10, 20], prefix, 64, 100, lambda d: d['dropout'] == 0.2, metric, hp_keys)
        hp_checks([0, 10, 20], prefix, 64, 100, lambda d: d['dropout'] == 0.5, metric, hp_keys)
