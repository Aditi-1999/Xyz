import argparse
from basic_v2.process_acc.processor_acc_indiv import execute_study
from models_v2.final import OnlyAccWithLSTMHistoryFinalV2
from utils_generic import send_message


if __name__ == '__main__':
    bs = 64
    num_epochs = 100
    prefix = 'indiv'

    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', dest='seed', type=int)
    parser.add_argument('--btest', dest='btest', type=int)
    parser.add_argument('--gpu', dest='gpu', type=int, default=0)
    parser.add_argument('--sub_num', dest='sub_num', type=int)
    args = parser.parse_args()

    execute_study(OnlyAccWithLSTMHistoryFinalV2, args.seed, args.btest, bs, num_epochs, prefix, [args.gpu], 'gain_d',
                  args.sub_num)

    send_message(f'Acc Indiv - {prefix} for {args} Finished')
