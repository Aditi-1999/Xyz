from aistats_figures import data_dir, p_text, sigmoid, entropy, rt_file, acc_file, get_sub_metrics
from scipy.stats import ttest_rel
import matplotlib
from matplotlib.axes import Axes
import matplotlib.patches as mpatches
from numpy.typing import NDArray
import matplotlib.pyplot as plt
from config import project_dir
from utils_data.helper import serial_dependence_measure
import seaborn as sns
import pandas
import numpy

font_size = 13
lfont_size = 15

color = {
    'srm': [0, 0, 1, 0.2],
    'tms': [1, 0, 0, 0.2],
}


def get_all_rt_metrics(experiment):
    rt_fname = data_dir + experiment + '/bisann_rt.pkl'
    values = rt_file(rt_fname)
    corr = get_sub_metrics(values, experiment=experiment, metric='rt', measure='corr', shuffled=False)
    corr.name = 'corr'
    corr_bs = get_sub_metrics(values, experiment=experiment, metric='rt', measure='corr', shuffled=True)
    corr_bs.name = 'corr_bs'
    mse = get_sub_metrics(values, experiment=experiment, metric='rt', measure='mse', shuffled=False)
    mse.name = 'mse'
    mse_bs = get_sub_metrics(values, experiment=experiment, metric='rt', measure='mse', shuffled=True)
    mse_bs.name = 'mse_bs'
    return pandas.DataFrame([corr, corr_bs, mse, mse_bs]).transpose()


def get_all_acc_metrics(experiment):
    acc_fname = data_dir + experiment + '/bisann_acc.pkl'
    values = acc_file(acc_fname)
    auroc = get_sub_metrics(values, experiment=experiment, metric='acc', measure='auroc', shuffled=False)
    auroc.name = 'auroc'
    auroc_bs = get_sub_metrics(values, experiment=experiment, metric='acc', measure='auroc', shuffled=True)
    auroc_bs.name = 'auroc_bs'
    bce = get_sub_metrics(values, experiment=experiment, metric='acc', measure='bce', shuffled=False)
    bce.name = 'bce'
    bce_bs = get_sub_metrics(values, experiment=experiment, metric='acc', measure='bce', shuffled=True)
    bce_bs.name = 'bce_bs'
    return pandas.DataFrame([auroc, auroc_bs, bce, bce_bs]).transpose()


def plot_metrics(ax: Axes, vrange, measure, bisann, ylabel, yticks, p_y, experiment):
    if measure in ['corr', 'auroc']:
        direction = 'greater'
    elif measure in ['mse', 'bce']:
        direction = 'less'
    else:
        raise Exception()

    intact = bisann[[measure]].copy()
    intact['x'] = 'Intact History'

    measure_bs = measure + '_bs'
    scrambled = bisann[[measure_bs]].copy()
    scrambled.columns = [measure]
    scrambled['x'] = 'Scrambled History'

    df = pandas.concat([intact, scrambled], axis=0)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    sns.violinplot(data=df, ax=ax, x='x', y=measure,
                   color=color[experiment], saturation=1, inner=None)
    ax.collections[0].set_edgecolor('none')
    ax.collections[1].set_facecolor('none')
    ax.collections[1].set_edgecolor(color[experiment])

    sns.boxplot(data=df, ax=ax, x='x', y=measure, color='black', fill=False, width=0.2)
    ax.set_ylim(*vrange)
    ax.set_ylabel(ylabel, fontsize=font_size)
    ax.set_yticks(yticks)
    ax.set_xlabel('')
    for tick in ax.get_xticklabels() + ax.get_yticklabels():
        tick.set_fontsize(font_size)

    sd = serial_dependence_measure('difference', bisann[measure], bisann[measure_bs])
    pval = ttest_rel(a=sd, b=numpy.zeros_like(sd), alternative=direction)[1]
    pval = p_text(pval)
    ax.text(0.5, p_y, s=pval, ha='center', va='center', fontsize=font_size)


def make_rt_subplots(axs: NDArray[Axes]):  # four column axes for first row
    srm_bisann = get_all_rt_metrics(experiment='srm')
    plot_metrics(axs[0], [-0.2, 1], 'corr', srm_bisann, 'R.Corr',
                 numpy.arange(-0.2, 1, 0.2), 0.7, 'srm')
    plot_metrics(axs[1], [0.4, 2.6], 'mse', srm_bisann, 'MSE',
                 numpy.arange(0.4, 2.6, 0.4), 1.7, 'srm')

    tms_bisann = get_all_rt_metrics(experiment='tms')
    plot_metrics(axs[2], [0, 0.8], 'corr', tms_bisann, 'R.Corr',
                 numpy.arange(0, 0.8, 0.2), 0.7, 'tms')
    plot_metrics(axs[3], [0, 1.2], 'mse', tms_bisann, 'MSE',
                 numpy.arange(0, 1.2, 0.2), 1, 'tms')


def make_acc_subplots(axs: NDArray[Axes]):  # four column axes for second row
    srm_bisann = get_all_acc_metrics(experiment='srm')
    plot_metrics(axs[0], [0, 1.1], 'auroc', srm_bisann, 'AUROC',
                 numpy.arange(0, 1.1, 0.2), 0.95, 'srm')
    plot_metrics(axs[1], [0, 1], 'bce', srm_bisann, 'BCE',
                 numpy.arange(0, 1, 0.2), 0.8, 'srm')

    tms_bisann = get_all_acc_metrics(experiment='tms')
    plot_metrics(axs[2], [0, 1.1], 'auroc', tms_bisann, 'AUROC',
                 numpy.arange(0, 1.1, 0.2), 0.95, 'tms')
    plot_metrics(axs[3], [0, 1], 'bce', tms_bisann, 'BCE',
                 numpy.arange(0, 1, 0.2), 0.8, 'tms')


def plot():
    plt.rcParams['axes.unicode_minus'] = False
    plt.rcParams['font.sans-serif'] = "Arial"
    plt.rcParams['font.family'] = "sans-serif"
    fig, axs = plt.subplots(2, 4, figsize=(16, 8))

    make_rt_subplots(axs[0])
    make_acc_subplots(axs[1])

    fig.text(0.26, 0.98, "SRC", fontweight='bold', ha='center', va='center', fontsize=lfont_size)
    fig.text(0.76, 0.98, "SPC", fontweight='bold', ha='center', va='center', fontsize=lfont_size)

    fig.text(0.01, 0.94, "A", fontweight='bold', ha='left', va='center', fontsize=lfont_size)
    fig.text(0.25, 0.94, "B", fontweight='bold', ha='left', va='center', fontsize=lfont_size)
    fig.text(0.52, 0.94, "C", fontweight='bold', ha='left', va='center', fontsize=lfont_size)
    fig.text(0.75, 0.94, "D", fontweight='bold', ha='left', va='center', fontsize=lfont_size)

    fig.text(0.01, 0.475, "E", fontweight='bold', ha='left', va='center', fontsize=lfont_size)
    fig.text(0.25, 0.475, "F", fontweight='bold', ha='left', va='center', fontsize=lfont_size)
    fig.text(0.52, 0.475, "G", fontweight='bold', ha='left', va='center', fontsize=lfont_size)
    fig.text(0.75, 0.475, "H", fontweight='bold', ha='left', va='center', fontsize=lfont_size)

    plt.tight_layout(rect=[0, 0, 1, 0.925])
    plt.savefig(project_dir + 'aistats_figures/plots/serial_dependence.png', dpi=400)
    # plt.show()


if __name__ == '__main__':
    plot()
