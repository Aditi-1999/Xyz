import numpy
import pandas
import xarray
import plotly.express as px
from utils_data import num_gain_blocks
from config import project_dir
from sklearn.metrics import confusion_matrix
from utils_processing.metrics import compute_auroc, compute_bce


def compute_normalized_confusion(df):
    df['acc_argmax'] = (df['acc_pred'] >= 0).astype(int).tolist()
    tn, fp, fn, tp = confusion_matrix(df['acc_target'], df['acc_argmax'], normalize='all').ravel()
    return [tn, fp, fn, tp]


def form_cf_matrix(row):
    tp, fp, fn, tn = row['tp'], row['fp'], row['fn'], row['tn']
    cf = numpy.array([[tp, fp],
                      [fn, tn]])
    cf = numpy.hstack((cf, cf.sum(axis=1, keepdims=True)))
    cf = numpy.vstack((cf, cf.sum(axis=0, keepdims=True)))
    return cf


def acc_confusion(values_df, title):
    values_df['sub_emb'] = values_df.sub_emb.apply(int)

    # Actual History Predictions
    actual_aurocs = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_auroc(df, 'acc_target', 'acc_pred'))
    actual_aurocs.name = 'metric'
    actual_aurocs = actual_aurocs.reset_index()
    actual_aurocs = actual_aurocs.groupby(['sub_emb']).metric.mean()
    mean_auroc = actual_aurocs.mean()

    actual_bces = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_bce(df, 'acc_target', 'acc_pred'))
    actual_bces.name = 'metric'
    actual_bces = actual_bces.reset_index()
    actual_bces = actual_bces.groupby(['sub_emb']).metric.mean()
    mean_bce = actual_bces.mean()

    ncs = values_df.groupby(['sub_emb', 'seed']).apply(compute_normalized_confusion)
    ncs.name = 'cf_values'
    ncs: pandas.DataFrame = ncs.reset_index()
    ncs[['tn', 'fp', 'fn', 'tp']] = ncs.cf_values.tolist()
    ncs.drop(columns=['cf_values'], inplace=True)
    ncs = ncs.groupby('sub_emb').mean()
    ncs.drop(columns=['seed'], inplace=True)

    cf_matrix = form_cf_matrix(ncs.mean())

    data_array = xarray.DataArray(
        data=cf_matrix,
        dims=['Predicted', 'Observed'],
        coords={
            'Predicted': ['Correct', 'Wrong', 'Sum'],
            'Observed': ['Correct', 'Wrong', 'Sum'],
        }
    )

    fig = px.imshow(data_array, text_auto='.2f', color_continuous_scale='Blues',
                    title='Actual History Predictions ' + title)
    annotation = f'Mean AUROC over Seed & Block, over Subjects = {mean_auroc:.3f}' \
                 f'<br>Mean BCE over Seed & Block, over Subjects = {mean_bce:.3f}'
    fig.add_annotation(text=annotation, align='center',
                       showarrow=False, xref='paper', yref='paper', font=dict(size=18), x=1.0, y=1.08,
                       bordercolor='black', borderwidth=1)
    fig.update_layout(width=900, height=800, font_size=15)
    fig.show()


def acc_confusion_facets(values_df, title, sub_order: list[int]):
    assert len(sub_order) == 6  # three good and three bad subjects (across corr and mse)

    values_df['sub_emb'] = values_df.sub_emb.apply(int)
    values_df = values_df.query(f'sub_emb in {sub_order}').copy()

    # Actual History Predictions
    actual_aurocs = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_auroc(df, 'acc_target', 'acc_pred'))
    actual_aurocs.name = 'metric'
    actual_aurocs = actual_aurocs.reset_index()
    actual_aurocs = actual_aurocs.groupby(['sub_emb']).metric.mean()

    actual_bces = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_bce(df, 'acc_target', 'acc_pred'))
    actual_bces.name = 'metric'
    actual_bces = actual_bces.reset_index()
    actual_bces = actual_bces.groupby(['sub_emb']).metric.mean()

    ncs = values_df.groupby(['sub_emb', 'seed']).apply(compute_normalized_confusion)
    ncs.name = 'cf_values'
    ncs: pandas.DataFrame = ncs.reset_index()
    ncs[['tn', 'fp', 'fn', 'tp']] = ncs.cf_values.tolist()
    ncs.drop(columns=['cf_values'], inplace=True)
    ncs = ncs.groupby('sub_emb').mean()
    ncs.drop(columns=['seed'], inplace=True)

    cf_matrices = ncs.apply(form_cf_matrix, axis=1)
    cf_matrix_list = cf_matrices.loc[sub_order].tolist()

    data_array = xarray.DataArray(
        data=cf_matrix_list,
        dims=['Subject ID', 'Predicted', 'Observed'],
        coords={
            'Subject ID': sub_order,
            'Predicted': ['Correct', 'Wrong', 'Sum'],
            'Observed': ['Correct', 'Wrong', 'Sum'],
        }
    )

    fig = px.imshow(data_array, text_auto='.2f', color_continuous_scale='Blues',
                    title='Actual History Predictions ' + title,
                    facet_col='Subject ID', facet_col_wrap=3)
    for a in fig.layout.annotations:
        sub_id = int(a.text.split("=")[1])
        a.text = a.text + f' | AUROC={actual_aurocs.loc[sub_id]:.3f} | BCE={actual_bces.loc[sub_id]:.3f}'

    fig.update_layout(width=1400, height=900, font_size=15)
    fig.show()


def acc_confusion_block_facet(values_df, title, sub_emb):
    values_df = values_df.query(f'sub_emb == {sub_emb}').copy()
    block_order = list(range(num_gain_blocks))

    actual_aurocs = values_df.groupby(['seed', 'block_emb']).apply(lambda df: compute_auroc(df, 'acc_target', 'acc_pred'))
    actual_bces = values_df.groupby(['seed', 'block_emb']).apply(lambda df: compute_bce(df, 'acc_target', 'acc_pred'))

    for seed in values_df.seed.unique():

        seed_df = values_df.query(f'seed == {seed}').copy()

        ncs = seed_df.groupby(['block_emb']).apply(compute_normalized_confusion)
        ncs.name = 'cf_values'
        ncs: pandas.DataFrame = ncs.reset_index()
        ncs[['tn', 'fp', 'fn', 'tp']] = ncs.cf_values.tolist()
        ncs.drop(columns=['cf_values'], inplace=True)
        ncs.set_index(['block_emb'], inplace=True)

        cf_matrices = ncs.apply(form_cf_matrix, axis=1)
        cf_matrix_list = cf_matrices.loc[block_order].tolist()

        data_array = xarray.DataArray(
            data=cf_matrix_list,
            dims=['Block#', 'Predicted', 'Observed'],
            coords={
                'Block#': block_order,
                'Predicted': ['Correct', 'Wrong', 'Sum'],
                'Observed': ['Correct', 'Wrong', 'Sum'],
            }
        )

        fig = px.imshow(data_array, text_auto='.2f', color_continuous_scale='Blues',
                        title=f'{title} for Subject ID={sub_emb} & Seed={seed}',
                        facet_col='Block#', facet_col_wrap=3)
        for a in fig.layout.annotations:
            block_num = int(a.text.split("=")[1])
            a.text = a.text + f' | AUROC={actual_aurocs.loc[seed, block_num]:.3f}' \
                              f' | BCE={actual_bces.loc[seed, block_num]:.3f}'

        fig.update_layout(width=1400, height=900, font_size=15)
        fig.show()


if __name__ == '__main__':
    model_type = f'Basic Sans Block'
    result_folder = project_dir + f'basic/results/basic_sans_block_bs=64_maxep=100_acc/'
    sub_list = [5, 13, 3, 8, 18, 6]

    values = pandas.read_pickle(result_folder + f'overall-values.pkl')
    acc_confusion(values.copy(), model_type)
    acc_confusion_facets(values.copy(), model_type, sub_list)
    acc_confusion_block_facet(values.copy(), model_type, 5)
    acc_confusion_block_facet(values.copy(), model_type, 8)
