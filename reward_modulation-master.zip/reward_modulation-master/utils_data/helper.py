from scipy.stats import ttest_rel
from scipy import special
import pandas
import numpy


def sigmoid(x):
    return 1 / (1 + numpy.exp(-x))


def inverse_sigmoid(x):
    return numpy.log(x / (1-x))


def entropy(p):
    ent = -p * numpy.log(p) - (1-p) * numpy.log(1-p)
    return ent


def perc_reward(x):
    assert x in [0, 1, 0.5]
    if x == 0:
        return 'VR<FX'
    if x == 1:
        return 'VR>FX'
    return pandas.NA


def true_reward(x):
    assert x in [0, 1]
    return 'VR>FX' if x else 'VR<FX'


def get_actual_trial_type(row):
    if row['reward_vr_fx'] == 0 and row['side_probed'] == 0:
        # Reward@VR<FX and FX probed
        return 'valid'
    if row['reward_vr_fx'] == 1 and row['side_probed'] == 1:
        # Reward@VR>FX and VR probed
        return 'valid'
    if row['reward_vr_fx'] == 0 and row['side_probed'] == 1:
        # Reward@VR<FX and VR probed
        return 'invalid'
    if row['reward_vr_fx'] == 1 and row['side_probed'] == 0:
        # Reward@VR>FX and FX probed
        return 'invalid'
    return pandas.NA


def get_perc_trial_type(row):
    if row['perc_vr_gt_fx'] == 0 and row['side_probed'] == 0:
        # Reward@VR<FX and FX probed
        return 'valid'
    if row['perc_vr_gt_fx'] == 1 and row['side_probed'] == 1:
        # Reward@VR>FX and VR probed
        return 'valid'
    if row['perc_vr_gt_fx'] == 0 and row['side_probed'] == 1:
        # Reward@VR<FX and VR probed
        return 'invalid'
    if row['perc_vr_gt_fx'] == 1 and row['side_probed'] == 0:
        # Reward@VR>FX and FX probed
        return 'invalid'
    return pandas.NA


def get_stimulus_category(row):
    low, mid, high = [0.1447161682, 0.3212404271, 0.60882871085]  # quartiles
    if row.stimulus_time < low:  # LOW = stimulus time < low
        return 'low'
    if row.stimulus_time < high:  # MID = low <= stimulus time < high
        return 'mid'
    return 'high'


def probed_side(x):
    assert x in [0, 1]
    return 'VR' if x else 'FX'


def population_difference(group1: numpy.ndarray, group2: numpy.ndarray):
    return group1.mean() - group2.mean()


def serial_dependence_measure(sd_type: str, actual: pandas.Series, shuffled: pandas.Series) -> pandas.Series:
    assert actual.index.equals(shuffled.index)
    if sd_type == 'difference':
        return actual - shuffled
    if sd_type == 'modulated_shuffled':
        return (actual - shuffled) / shuffled
    if sd_type == 'modulated_actual':
        return (actual - shuffled) / actual
    if sd_type == 'modulated_sum':
        return (actual - shuffled) / (actual + shuffled)
    raise Exception('Invalid sd_type')


def custom_t_test(x, y, direction, metric, num_repeats=1000):
    """
    Only for participant paired data
    :param x: sub_num should be present
    :param y: sub_num should be present
    :param direction: one of 'two-sided', 'less', 'greater'
    :param metric: metric to be used
    :param num_repeats: number of times we take the actual t-test to get the average t-test statistic
    :return: p-value based on a custom t-test which is "more" fair compared to original to correct for number of trials
    """
    assert direction in ['two-sided', 'less', 'greater']
    x_subs = set(x.sub_num)
    y_subs = set(y.sub_num)
    assert x_subs == y_subs, 'Participants mismatch - we need paired data'

    rng = numpy.random.default_rng(seed=0)

    tstats = []
    for i in range(num_repeats):

        paired_metric_df = pandas.DataFrame(index=list(x_subs), columns=['x', 'y'])

        for sub_num in x_subs:
            x_sub_df = x[x.sub_num == sub_num]
            y_sub_df = y[y.sub_num == sub_num]

            x_len = len(x_sub_df)
            y_len = len(y_sub_df)

            if x_len > y_len:
                x_df = x_sub_df.sample(n=y_len, random_state=rng)
                y_df = y_sub_df
            elif x_len < y_len:
                x_df = x_sub_df
                y_df = y_sub_df.sample(n=x_len, random_state=rng)
            else:
                x_df = x_sub_df
                y_df = y_sub_df

            x_metric = x_df[metric].mean()
            y_metric = y_df[metric].mean()

            paired_metric_df.loc[sub_num, 'x'] = x_metric
            paired_metric_df.loc[sub_num, 'y'] = y_metric

        tstat = ttest_rel(a=paired_metric_df.x, b=paired_metric_df.y, alternative=direction)[0]
        tstats.append(tstat)

    df = len(x_subs) - 1
    avg_tstat = numpy.mean(tstats)

    if direction == 'less':
        pval = special.stdtr(df, avg_tstat)
    elif direction == 'greater':
        pval = special.stdtr(df, -avg_tstat)
    else:  # two-sided
        pval = special.stdtr(df, -numpy.abs(avg_tstat)) * 2

    return pval
