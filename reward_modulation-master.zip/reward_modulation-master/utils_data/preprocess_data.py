from config import data_dir
import scipy.io as sio
import pandas
from utils_data import num_subjects, num_actual_blocks
from utils_generic import get_list_as_dict

raw_data_columns = [
    'trial_num', 'hemifield_probe', 'reward_left', 'reward_probe', 'change_left', 'change_right', 'contingency_type',
    'stimulus_time_wrong', 'response'
]

data_columns = [
    'sub_num', 'gain_block_num', 'trial_num',
    'block_type', 'side_fixed', 'stimulus_time', 'change_fixed', 'change_variable', 'side_probed',
    'reward_vr_fx', 'reward_yes_no',
    'perc_vr_gt_fx', 'perc_yes_gt_no', 'perc_contingency',
    'response', 'response_nc', 'response_ch',
    'accuracy', 'is_correct', 'is_wrong',
    'accrued_score',
    'response_time',
]


def get_accuracy(row):
    if pandas.isna(row.response):
        return pandas.NA
    if row.hemifield_probe == -1:
        return int(row.change_left == row.response)
    else:
        return int(row.change_right == row.response)


def save_d_data():
    spatial_data = sio.loadmat(data_dir + f'raw_data/spatial_reward_modulation.mat')['Trials_Info'][0, 0]

    dfs = []
    for sub_num in range(num_subjects):
        for actual_block_num in range(num_actual_blocks):
            sub_block_data = spatial_data['WithoutETrej'][sub_num][actual_block_num]
            stimulus_time = spatial_data['t_cuestimulus'][sub_num][actual_block_num][0]
            response_time = spatial_data['t_response'][sub_num][actual_block_num][:, 0]
            if actual_block_num == 0:
                trial_score = spatial_data['trial_score'][sub_num][actual_block_num][:, 1]
            else:
                trial_score = spatial_data['trial_score'][sub_num][actual_block_num][:, 1, actual_block_num]

            df = pandas.DataFrame(sub_block_data, columns=raw_data_columns)
            df['sub_num'] = sub_num
            df['actual_block_num'] = actual_block_num
            df['stimulus_time'] = stimulus_time
            df['response_time'] = response_time
            df['trial_score'] = trial_score
            df['accrued_score'] = df.trial_score.cumsum().shift(1, fill_value=0)  # sum of scores until last trial

            # True Reward magnitude comparison of Variable and Fixed sides. 0 - VR<FX. 1 - VR>FX.
            df['reward_vr_fx'] = (df.contingency_type == 1).apply(int)
            df['reward_yes_no'] = pandas.NA
            df['side_probed'] = (df.reward_probe > 0).apply(int)  # 0 - fixed side, 1 - variable side
            df.loc[df.response == 5, 'response'] = pandas.NA
            df['accuracy'] = df.apply(get_accuracy, axis=1)

            # Get Perceived Contingencies
            perceived_contingencies: list = [pandas.NA]
            for i in range(len(df)):
                current_perceived_contingency = perceived_contingencies[i]
                trial = df.iloc[i]
                if pandas.isna(trial.accuracy) or trial.accuracy == 0:  # inaccurate or missed
                    perceived_contingencies.append(current_perceived_contingency)
                else:  # accurate
                    if trial.side_probed == 1:  # VR side is probed
                        perceived_contingencies.append(trial.reward_vr_fx)  # 0 - VR<FX. 1 - VR>FX.
                    else:  # FX side is probed
                        perceived_contingencies.append(current_perceived_contingency)
            perceived_contingencies = perceived_contingencies[:-1]

            df['perc_contingency'] = perceived_contingencies  # NaN - Unknown. 0 - VR<FX. 1 - VR>FX.
            df['perc_vr_gt_fx'] = df['perc_contingency'].fillna(0.5)  # 0.5 - Unknown. 0 - VR<FX. 1 - VR>FX.
            df['perc_yes_gt_no'] = pandas.NA

            dfs.append(df)

    all_data_df = pandas.concat(dfs, ignore_index=True)
    all_data_df.drop(columns=['stimulus_time_wrong'], inplace=True)

    all_data_df['trial_num'] = all_data_df['trial_num'] - 1
    all_data_df['block_type'] = (all_data_df.reward_left.apply(abs) == 3).apply(int)  # 0 - loss block, 1 - gain block
    all_data_df['side_fixed'] = (all_data_df.reward_left > 0).apply(int)  # 0 - left side, 1 - right side

    # Which side changed (both can change) w.r.t fixed and variable sides
    # When left side is fixed side, then change at fixed side = change at left side
    # 0 - No Change, 1 - Change
    all_data_df.loc[all_data_df.side_fixed == 0, 'change_fixed'] = all_data_df.loc[all_data_df.side_fixed == 0, 'change_left']
    all_data_df.loc[all_data_df.side_fixed == 1, 'change_fixed'] = all_data_df.loc[all_data_df.side_fixed == 1, 'change_right']
    all_data_df.loc[all_data_df.side_fixed == 0, 'change_variable'] = all_data_df.loc[all_data_df.side_fixed == 0, 'change_right']
    all_data_df.loc[all_data_df.side_fixed == 1, 'change_variable'] = all_data_df.loc[all_data_df.side_fixed == 1, 'change_left']

    # Encoding to handle missing responses as input to model
    all_data_df['response_nc'] = (all_data_df.response == 0).apply(int)
    all_data_df['response_ch'] = (all_data_df.response == 1).apply(int)

    all_data_df['is_correct'] = (all_data_df.accuracy == 1).apply(int)
    all_data_df['is_wrong'] = (all_data_df.accuracy == 0).apply(int)

    # Scale stimulus time
    all_data_df['stimulus_time'] = (all_data_df['stimulus_time'] - 0.3) / 0.4

    # Scale previous cumulative score - scale magnitude of the score by max possible magnitude
    # In gain blocks, a response miss will decrease magnitude of accrued score. Conversely, in loss blocks, ...
    all_data_df['accrued_score'] = all_data_df['accrued_score'] * all_data_df['block_type'].apply(lambda x: -1 if x == 0 else 1) / 360

    # Data correction
    rt_issue = (all_data_df.sub_num == 20) & (all_data_df.actual_block_num == 5) & (all_data_df.trial_num == 29)
    all_data_df.loc[rt_issue, 'response_time'] = 1.499

    # Need only gain blocks for now
    all_data_df = all_data_df.query('block_type == 1').copy()
    gain_block_order = all_data_df.groupby('sub_num').actual_block_num.unique().apply(get_list_as_dict).to_dict()
    all_data_df['gain_block_num'] = all_data_df.apply(lambda row: gain_block_order[row.sub_num][row.actual_block_num],
                                                      axis=1)

    all_data_df = all_data_df[data_columns]
    all_data_df.sort_values(['sub_num', 'gain_block_num', 'trial_num'], inplace=True)
    all_data_df.to_json(data_dir + 'gain_d_data.json', orient='columns')


def save_cc_data():
    response_data = sio.loadmat(data_dir + f'raw_data/response_reward_modulation.mat')['Trials_Info'][0, 0]

    dfs = []
    for sub_num in range(num_subjects):
        for actual_block_num in range(num_actual_blocks):
            sub_block_data = response_data['WithoutETrej'][sub_num][actual_block_num]
            stimulus_time = response_data['t_cuestimulus'][sub_num][actual_block_num][0]
            response_time = response_data['t_response'][sub_num][actual_block_num][:, 0]
            if actual_block_num == 0:
                trial_score = response_data['trial_score'][sub_num][actual_block_num][:, 1]
            else:
                trial_score = response_data['trial_score'][sub_num][actual_block_num][:, 1, actual_block_num]

            df = pandas.DataFrame(sub_block_data, columns=raw_data_columns)
            df['sub_num'] = sub_num
            df['actual_block_num'] = actual_block_num
            df['stimulus_time'] = stimulus_time
            df['response_time'] = response_time
            df['trial_score'] = trial_score
            df['accrued_score'] = df.trial_score.cumsum().shift(1, fill_value=0)  # sum of scores until last trial

            # True Reward magnitude comparison of Yes and No response of VR side. 0 - Yes<No. 1 - Yes>No.
            df['reward_vr_fx'] = pandas.NA
            df['reward_yes_no'] = (df.contingency_type == 1).apply(int)
            df['side_probed'] = (df.reward_probe > 0).apply(int)  # 0 - fixed side, 1 - variable side
            df.loc[df.response == 5, 'response'] = pandas.NA
            df['accuracy'] = df.apply(get_accuracy, axis=1)

            # todo: Get Perceived Contingencies
            df['perc_contingency'] = pandas.NA  # NaN - Unknown. 0 - Yes<No. 1 - Yes>No.
            df['perc_vr_gt_fx'] = pandas.NA
            df['perc_yes_gt_no'] = df['perc_contingency'].fillna(0.5)  # 0.5 - Unknown. 0 - Yes<No. 1 - Yes>No.

            dfs.append(df)

    all_data_df = pandas.concat(dfs, ignore_index=True)
    all_data_df.drop(columns=['stimulus_time_wrong'], inplace=True)

    all_data_df['trial_num'] = all_data_df['trial_num'] - 1
    all_data_df['block_type'] = (all_data_df.reward_left.apply(abs) == 3).apply(int)  # 0 - loss block, 1 - gain block
    all_data_df['side_fixed'] = (all_data_df.reward_left > 0).apply(int)  # 0 - left side, 1 - right side

    # Which side changed (both can change) w.r.t fixed and variable sides
    # When left side is fixed side, then change at fixed side = change at left side
    # 0 - No Change, 1 - Change
    all_data_df.loc[all_data_df.side_fixed == 0, 'change_fixed'] = all_data_df.loc[all_data_df.side_fixed == 0, 'change_left']
    all_data_df.loc[all_data_df.side_fixed == 1, 'change_fixed'] = all_data_df.loc[all_data_df.side_fixed == 1, 'change_right']
    all_data_df.loc[all_data_df.side_fixed == 0, 'change_variable'] = all_data_df.loc[all_data_df.side_fixed == 0, 'change_right']
    all_data_df.loc[all_data_df.side_fixed == 1, 'change_variable'] = all_data_df.loc[all_data_df.side_fixed == 1, 'change_left']

    # Encoding to handle missing responses as input to model
    all_data_df['response_nc'] = (all_data_df.response == 0).apply(int)
    all_data_df['response_ch'] = (all_data_df.response == 1).apply(int)

    all_data_df['is_correct'] = (all_data_df.accuracy == 1).apply(int)
    all_data_df['is_wrong'] = (all_data_df.accuracy == 0).apply(int)

    # Scale stimulus time
    all_data_df['stimulus_time'] = (all_data_df['stimulus_time'] - 0.3) / 0.4

    # Scale previous cumulative score - scale magnitude of the score by max possible magnitude
    # In gain blocks, a response miss will decrease magnitude of accrued score. Conversely, in loss blocks, ...
    all_data_df['accrued_score'] = all_data_df['accrued_score'] * all_data_df['block_type'].apply(lambda x: -1 if x == 0 else 1) / 360

    # Data correction - todo: see if needed

    # Need only gain blocks for now
    all_data_df = all_data_df.query('block_type == 1').copy()
    gain_block_order = all_data_df.groupby('sub_num').actual_block_num.unique().apply(get_list_as_dict).to_dict()
    all_data_df['gain_block_num'] = all_data_df.apply(lambda row: gain_block_order[row.sub_num][row.actual_block_num],
                                                      axis=1)

    all_data_df = all_data_df[data_columns]
    all_data_df.sort_values(['sub_num', 'gain_block_num', 'trial_num'], inplace=True)
    all_data_df.to_json(data_dir + 'gain_cc_data.json', orient='columns')


if __name__ == '__main__':
    save_d_data()
    save_cc_data()
