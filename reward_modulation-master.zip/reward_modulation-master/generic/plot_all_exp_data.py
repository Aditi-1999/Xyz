import plotly.graph_objs as go
from plotly.subplots import make_subplots
from utils_processing.metrics import p_val_text
# Need plotly 5.6.0 to work properly - some bug in 5.12.0


def figure2():
    width, height = 1100, 800
    data = [
        {
            'x_title': 'Distractor Working Memory',
            'y_title': 'Circular Correlation (Predicted Response Error, Observed Response Error)',
            'y_range': [0.1, 0.3],
            'y_p': 0.25,
            'bars': [
                {
                    'x': '',
                    'actual': {
                        'mean': 0.218848,
                        'sd': 0.026721,
                    },
                    'shuffled': {
                        'mean': 0.204527,
                        'sd': 0.025432,
                    },
                    'pval': 0.006889641284942627,
                }
            ]
        },
        {
            'x_title': 'Spatial Reward Modulation',
            'y_title': 'Robust Correlation (Predicted RT, Observed RT)',
            'y_range': [0, 0.2],
            'y_p': 0.17,
            'bars': [
                {
                    'x': '',
                    'actual': {
                        'mean': 0.120436,
                        'sd': 0.024909,
                    },
                    'shuffled': {
                        'mean': 0.064185,
                        'sd': 0.012804,
                    },
                    'pval': 0.001407325267791748,
                }
            ]
        },
        {
            'x_title': 'Spatial Reward Modulation',
            'y_title': 'AUROC (Predicted Accuracy, Observed Accuracy)',
            'y_range': [0.6, 0.72],
            'y_p': 0.69,
            'bars': [
                {
                    'x': '',
                    'actual': {
                        'mean': 0.661618,
                        'sd': 0.021443,
                    },
                    'shuffled': {
                        'mean': 0.644016,
                        'sd': 0.019859,
                    },
                    'pval': 0.005758047103881836,
                }
            ]
        },
    ]
    fig = make_subplots(1, 3, horizontal_spacing=0.1)

    for c, datum in enumerate(data):
        selector = dict(row=1, col=c + 1)
        xs, actual_ys, actual_sems, shuffled_ys, shuffled_sems = [], [], [], [], []
        for bar in datum['bars']:
            xs.append(bar['x'])
            actual_ys.append(bar['actual']['mean'])
            actual_sems.append(bar['actual']['sd'])
            shuffled_ys.append(bar['shuffled']['mean'])
            shuffled_sems.append(bar['shuffled']['sd'])

        fig.add_trace(go.Bar(
            name='Actual History', x=xs, y=actual_ys,
            showlegend=c == 0,
            error_y=dict(array=actual_sems, symmetric=True),
            text=list(map(lambda x: round(x, 3), actual_ys)), textposition='outside',
            marker=dict(color='blue', )
        ), **selector)
        fig.add_trace(go.Bar(
            name='Shuffled History', x=xs, y=shuffled_ys,
            showlegend=c == 0,
            error_y=dict(array=shuffled_sems, symmetric=True),
            text=list(map(lambda x: round(x, 3), shuffled_ys)), textposition='outside',
            marker=dict(color='white', line=dict(color='blue'))
        ), **selector)

        for i, bar in enumerate(datum['bars']):
            pval = bar['pval']
            fig.add_annotation(x=i, y=datum['y_p'], showarrow=False, text=f'{p_val_text(pval)}', **selector)

        fig.update_xaxes(title=datum['x_title'], **selector)
        fig.update_yaxes(title=datum['y_title'], range=datum['y_range'], **selector)

    fig.update_layout(font_size=15, font_family='Times New Roman')

    fig.add_annotation(text='<b>a</b>', showarrow=False, xref='paper', yref='paper', x=-0.05, y=1.08, font=dict(size=20))
    fig.add_annotation(text='<b>b</b>', showarrow=False, xref='paper', yref='paper', x=0.32, y=1.08, font=dict(size=20))
    fig.add_annotation(text='<b>c</b>', showarrow=False, xref='paper', yref='paper', x=0.68, y=1.08, font=dict(size=20))

    fig.update_layout(legend=dict(yanchor="bottom", y=1.02, xanchor="right", x=1, orientation='h'))
    fig.update_layout(width=width, height=height)

    config = {
        'toImageButtonOptions': {
            'format': 'svg',  # one of png, svg, jpeg, webp
            'filename': 'custom_image',
            'scale': 6  # Multiply title/legend/axis/canvas sizes by this factor
        }
    }

    fig.show(config=config)


def figure1():
    datum = {
            'x_title': 'Cued Change Detection',
            'y_title': 'Robust Correlation (Predicted RT, Observed RT)',
            'y_range': [0.3, 0.52],
            'y_p': 0.51,
            'width': 800,
            'height': 800,
            'x_legend': 0.75,
            'bars': [
                {
                    'x': 'Condition 1',
                    'actual': {
                        'mean': 0.47585139258997,
                        'sd': 0.02022085547474522,
                    },
                    'shuffled': {
                        'mean': 0.4540383045921295,
                        'sd': 0.024433424493152788,
                    },
                    'pval': 0.012675374746322632,
                },
                # {
                #     'x': 'Condition 2',
                #     'actual': {
                #         'mean': 0.4465522273208663,
                #         'sd': 0.030476979051395528,
                #     },
                #     'shuffled': {
                #         'mean': 0.42354634570938615,
                #         'sd': 0.03308685861053397,
                #     },
                #     'pval': 0.0014664679765701294,
                # },
                {
                    'x': 'Condition 2',
                    'actual': {
                        'mean': 0.4412315687975393,
                        'sd': 0.035602902733674134,
                    },
                    'shuffled': {
                        'mean': 0.41793277007969265,
                        'sd': 0.036687811812239214,
                    },
                    'pval': 3.5122036933898926e-05,
                },
                # {
                #     'x': 'Condition 4',
                #     'actual': {
                #         'mean': 0.4651441111069114,
                #         'sd': 0.03551996272696387,
                #     },
                #     'shuffled': {
                #         'mean': 0.438614220795358,
                #         'sd': 0.037890873767409065,
                #     },
                #     'pval': 0.0003727227449417114,
                # },
                {
                    'x': 'Condition 3',
                    'actual': {
                        'mean': 0.42835091351724647,
                        'sd': 0.031721592818595046,
                    },
                    'shuffled': {
                        'mean': 0.411956150861484,
                        'sd': 0.03160894215557448,
                    },
                    'pval': 0.0007773935794830322,
                },
                # {
                #     'x': 'Condition 6',
                #     'actual': {
                #         'mean': 0.4081113841620248,
                #         'sd': 0.03617790948766847,
                #     },
                #     'shuffled': {
                #         'mean': 0.3961563797411144,
                #         'sd': 0.03497020668328475,
                #     },
                #     'pval': 0.026688717305660248,
                # }
            ]
        }
    fig = go.Figure()

    xs, actual_ys, actual_sems, shuffled_ys, shuffled_sems = [], [], [], [], []
    for bar in datum['bars']:
        xs.append(bar['x'])
        actual_ys.append(bar['actual']['mean'])
        actual_sems.append(bar['actual']['sd'])
        shuffled_ys.append(bar['shuffled']['mean'])
        shuffled_sems.append(bar['shuffled']['sd'])

    fig.add_trace(go.Bar(
        name='Actual History', x=xs, y=actual_ys,
        error_y=dict(array=actual_sems, symmetric=True),
        text=list(map(lambda x: round(x, 3), actual_ys)), textposition='outside',
        marker=dict(color='blue', )
    ))
    fig.add_trace(go.Bar(
        name='Shuffled History', x=xs, y=shuffled_ys,
        error_y=dict(array=shuffled_sems, symmetric=True),
        text=list(map(lambda x: round(x, 3), shuffled_ys)), textposition='outside',
        marker=dict(color='white', line=dict(color='blue'))
    ))

    for i, bar in enumerate(datum['bars']):
        pval = bar['pval']
        fig.add_annotation(x=i, y=datum['y_p'], showarrow=False, text=f'{p_val_text(pval)}')

    fig.update_xaxes(title=datum['x_title'])
    fig.update_yaxes(title=datum['y_title'], range=datum['y_range'])
    fig.update_layout(font_size=15, font_family='Times New Roman')
    fig.update_layout(legend=dict(yanchor="bottom", y=1.02, xanchor="right", x=1, orientation='h'))
    fig.update_layout(width=datum['width'], height=datum['height'])

    config = {
        'toImageButtonOptions': {
            'format': 'svg',  # one of png, svg, jpeg, webp
            'filename': 'custom_image',
            'scale': 6  # Multiply title/legend/axis/canvas sizes by this factor
        }
    }

    fig.show(config=config)
