import numpy
import pandas
from config import project_dir
from utils_processing import mc_seeds
from utils_data.helper import sigmoid
import plotly.graph_objs as go
from basic_v2.final_analyses import plot_subj_values, get_ttest_wilcoxon_text
from utils_data import sd_types
from numpy import log
from utils_data.helper import serial_dependence_measure


def entropy(p):
    ent = -p * log(p) - (1-p) * log(1-p)
    return ent


def conditioned_variance(result_dir, sd_type):
    values_df = pandas.read_pickle(result_dir)

    # Trial Level Uncertainty
    pred_cols = list(map(lambda x: f'acc_pred_{x}', range(len(mc_seeds))))
    values_df['acc_pred'] = values_df[pred_cols].applymap(sigmoid).mean(axis=1)
    pred_cols = list(map(lambda x: f'acc_pred_bs_{x}', range(len(mc_seeds))))
    values_df['acc_pred_bs'] = values_df[pred_cols].applymap(sigmoid).mean(axis=1)
    values_df['acc_pred_ent'] = values_df.acc_pred.apply(entropy)
    values_df['acc_pred_bs_ent'] = values_df.acc_pred_bs.apply(entropy)

    # Mean of Uncertainty Per Split, Per Block, Per Subject, Per Condition
    values_df = values_df.groupby(['sub_num', 'seed', 'btest']) \
        .agg({'acc_pred_ent': 'mean', 'acc_pred_bs_ent': 'mean'}) \
        .reset_index()

    # Median Per Subject, Per Condition
    values_df = values_df.groupby(['sub_num']) \
        .agg({'acc_pred_ent': 'mean', 'acc_pred_bs_ent': 'mean'})

    # Calculate Metric
    sd_measure = serial_dependence_measure(sd_type, values_df.acc_pred_ent, values_df.acc_pred_bs_ent)

    fig = go.Figure()
    plot_subj_values(fig, sd_measure, 'x')
    test_text = get_ttest_wilcoxon_text(sd_measure, numpy.zeros_like(sd_measure), 'greater')
    fig.add_annotation(x=0.5, y=0.2, showarrow=False, text=f'{sd_types[sd_type]} - Ent > 0<br>{test_text}')
    fig.update_layout(width=400, height=800, font_size=15)
    fig.update_yaxes(title_text=f'{sd_types[sd_type]} - Ent')
    fig.show()


if __name__ == '__main__':
    res_dir = project_dir + 'basic_v2/results/sans_block_v3_bs=64_maxep=100_acc/'
    for sd_type in sd_types.keys():
        conditioned_variance(res_dir + f'mc-test_values.pkl', sd_type)
