import pandas
from config import project_dir
import plotly.express as px
from subj_wise import rt_subjects
from scipy.stats import ks_2samp


def rt_patterns_continuous(feature):
    folder_name = f'subj_wise_nohist_lstm_bs=32_maxep=100_rt'
    df = pandas.read_pickle(project_dir + f'subj_wise/results/{folder_name}/bestHyper-T=0-values.pkl')
    df['sub_emb'] = df.sub_emb.apply(int)

    fig = px.scatter(df, x=feature, y='rt_target', trendline='ols', title='Observed RT Pattern',
                     facet_col='sub_emb', facet_col_wrap=3, category_orders={'sub_emb': rt_subjects},
                     labels={'rt_target': 'Observed RT', 'sub_emb': 'Subject ID'})
    fig.update_layout(font_size=15)
    fig.show()

    fig = px.scatter(df, x=feature, y='rt_pred', trendline='ols', title='Subj Wise Models Predicted RT Pattern',
                     facet_col='sub_emb', facet_col_wrap=3, category_orders={'sub_emb': rt_subjects},
                     labels={'rt_pred': 'Predicted RT', 'sub_emb': 'Subject ID'})
    fig.update_layout(font_size=15)
    fig.show()

    folder_name = f'basic_nohist_lstm_bs=64_maxep=100_rt'
    df = pandas.read_pickle(project_dir + f'basic/results/{folder_name}/bestHyper-T=0-values.pkl')
    df['sub_emb'] = df.sub_emb.apply(int)
    df = df[df.sub_emb.isin(rt_subjects)].copy()

    fig = px.scatter(df, x=feature, y='rt_pred', trendline='ols', title='Common Model Predicted RT Pattern',
                     facet_col='sub_emb', facet_col_wrap=3, category_orders={'sub_emb': rt_subjects},
                     labels={'rt_pred': 'Predicted RT', 'sub_emb': 'Subject ID'})
    fig.update_layout(font_size=15)
    fig.show()


def rt_patterns_discrete(feature):
    folder_name = f'subj_wise_nohist_lstm_bs=32_maxep=100_rt'
    df = pandas.read_pickle(project_dir + f'subj_wise/results/{folder_name}/bestHyper-T=0-values.pkl')
    df['sub_emb'] = df.sub_emb.apply(int)

    fig = px.histogram(df, x='rt_target', color=feature, title='Observed RT Pattern', barmode='overlay', opacity=0.5,
                       facet_col='sub_emb', facet_col_wrap=3, category_orders={'sub_emb': rt_subjects},
                       labels={'rt_target': 'Observed RT', 'sub_emb': 'Subject ID'})
    fig.update_layout(font_size=15)
    fig.show()

    fig = px.histogram(df, x='rt_pred', color=feature, title='Subj Wise Models Predicted RT Pattern', barmode='overlay', opacity=0.5,
                       facet_col='sub_emb', facet_col_wrap=3, category_orders={'sub_emb': rt_subjects},
                       labels={'rt_pred': 'Predicted RT', 'sub_emb': 'Subject ID'})
    fig.update_layout(font_size=15)
    fig.show()

    folder_name = f'basic_nohist_lstm_bs=64_maxep=100_rt'
    df = pandas.read_pickle(project_dir + f'basic/results/{folder_name}/bestHyper-T=0-values.pkl')
    df['sub_emb'] = df.sub_emb.apply(int)
    df = df[df.sub_emb.isin(rt_subjects)].copy()

    fig = px.histogram(df, x='rt_pred', color=feature, title='Common Model Predicted RT Pattern', barmode='overlay', opacity=0.5,
                       facet_col='sub_emb', facet_col_wrap=3, category_orders={'sub_emb': rt_subjects},
                       labels={'rt_pred': 'Predicted RT', 'sub_emb': 'Subject ID'})
    fig.update_layout(font_size=15)
    fig.show()


def run_ks_test(gdf, feature, col):
    result = ks_2samp(
        data1=gdf[gdf[feature] == 0][col].values,
        data2=gdf[gdf[feature] == 1][col].values,
    )
    # low p -> more evidence for distributions being different
    return result.pvalue


def rt_discrete_tests(feature):
    folder_name = f'subj_wise_nohist_lstm_bs=32_maxep=100_rt'
    df = pandas.read_pickle(project_dir + f'subj_wise/results/{folder_name}/bestHyper-T=0-values.pkl')
    df['sub_emb'] = df.sub_emb.apply(int)
    df = df[df.sub_emb.isin(rt_subjects)].copy()
    df = df.query('seed == 0').copy()

    pvals = df.groupby('sub_emb').apply(lambda gdf: run_ks_test(gdf, feature, 'rt_target'))
    print(pvals.loc[rt_subjects])

    # pvals = df.groupby('sub_emb').apply(lambda gdf: run_ks_test(gdf, feature, 'rt_pred'))
    # print(pvals.loc[rt_subjects])


if __name__ == '__main__':
    feat = 'side_probed'
    # rt_patterns_discrete(feat)
    rt_discrete_tests(feat)
