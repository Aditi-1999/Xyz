import numpy
from utils_data.msc_eda import get_probed_side_mscs
import pandas
from scipy.stats import sem, permutation_test
from utils_processing.metrics import compute_element_mse, compute_element_bce, p_val_text
from config import project_dir
from utils_data import sd_types
from utils_data.helper import serial_dependence_measure
import plotly.graph_objects as go


seed_list = [0, 10, 20]
bs = 64
num_epochs = 100


def statistic(group1: numpy.ndarray, group2: numpy.ndarray):
    return group1.mean() - group2.mean()


def trial_msc_sd_rt(prefix):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_rt'
    result_folder = project_dir + f'basic/results/{folder_name}/'
    values_df: pandas.DataFrame = pandas.read_pickle(result_folder + f'overall-values.pkl')

    values_df['actual_mse'] = compute_element_mse(values_df, 'rt_target', 'rt_pred')
    values_df['shuffled_mse'] = compute_element_mse(values_df, 'rt_target_bs', 'rt_pred_bs')
    # Averaging values across seeds - as an estimate of the actual values
    values_df = values_df.groupby(['sub_num', 'gain_block_num', 'trial_num'])\
        .agg({'actual_mse': 'mean', 'shuffled_mse': 'mean'})\
        .reset_index()

    end = 450
    for deg_window in [30]:
        for start in [250]:
            msc_df = get_probed_side_mscs(deg_window, start, end)
            msc_df['msc_in_probed'] = msc_df.probed_phis.apply(lambda x: '>0' if len(x) > 0 else '0')
            msc_df.set_index(['sub_num', 'gain_block_num', 'trial_num'], inplace=True)
            msc_in_probed = msc_df.msc_in_probed.to_dict()
            values_df['msc_in_probed'] = values_df.apply(
                lambda row: msc_in_probed.get((row.sub_num, row.gain_block_num, row.trial_num)), axis=1)
            probed_msc_df = values_df.dropna(subset=['msc_in_probed'], axis=0).copy()

            for sd_type, sd_text in list(sd_types.items())[:1]:
                probed_msc_df['sd_measure'] = serial_dependence_measure(sd_type, probed_msc_df['actual_mse'], probed_msc_df['shuffled_mse'])

                fig = go.Figure()

                msc_level = probed_msc_df.groupby(['msc_in_probed']).sd_measure \
                    .agg(mean='mean', sem=sem).reset_index()

                fig.add_trace(go.Bar(
                    x=msc_level['msc_in_probed'], y=msc_level['mean'],
                    error_y=dict(array=msc_level['sem'], symmetric=True),
                    text=msc_level['mean'].round(3), textposition='outside'
                ))

                result = permutation_test(
                    [
                        probed_msc_df[probed_msc_df.msc_in_probed == '0'].sd_measure,
                        probed_msc_df[probed_msc_df.msc_in_probed == '>0'].sd_measure,
                    ],
                    statistic=statistic,
                    permutation_type='independent',
                    n_resamples=9999,
                    alternative='two-sided',
                    random_state=0,
                )
                pval_text = p_val_text(result.pvalue)
                fig.add_annotation(x=0.5, y=-0.055, showarrow=False,
                                   text=f'"0" != ">0"<br>{pval_text}; Permutation Test')

                title = f'RT'
                fig.update_layout(font_size=15, title=dict(text=title, xanchor='center', x=0.5),
                                  width=800, height=600)
                fig.update_xaxes(title_text=f'Num(MScs) within {2 * deg_window}° window around<br>Probed Side '
                                            f'[{start}, {end}] ms after Probe Onset')
                fig.update_yaxes(title_text=f'{sd_text} - MSE in Current Trial at Probed Side')
                fig.show()


def trial_msc_sd_acc(prefix):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_acc'
    result_folder = project_dir + f'basic/results/{folder_name}/'
    values_df: pandas.DataFrame = pandas.read_pickle(result_folder + f'overall-values.pkl')

    values_df['actual_bce'] = compute_element_bce(values_df, 'acc_target', 'acc_pred')
    values_df['shuffled_bce'] = compute_element_bce(values_df, 'acc_target_bs', 'acc_pred_bs')
    # Averaging values across seeds - as an estimate of the actual values
    values_df = values_df.groupby(['sub_num', 'gain_block_num', 'trial_num'])\
        .agg({'actual_bce': 'mean', 'shuffled_bce': 'mean'})\
        .reset_index()

    end = 450
    for deg_window in [30]:
        for start in [250]:
            msc_df = get_probed_side_mscs(deg_window, start, end)
            msc_df['msc_in_probed'] = msc_df.probed_phis.apply(lambda x: '>0' if len(x) > 0 else '0')
            msc_df.set_index(['sub_num', 'gain_block_num', 'trial_num'], inplace=True)
            msc_in_probed = msc_df.msc_in_probed.to_dict()
            values_df['msc_in_probed'] = values_df.apply(lambda row: msc_in_probed.get((row.sub_num, row.gain_block_num, row.trial_num)), axis=1)
            probed_msc_df = values_df.dropna(subset=['msc_in_probed'], axis=0).copy()

            for sd_type, sd_text in list(sd_types.items())[:1]:
                probed_msc_df['sd_measure'] = serial_dependence_measure(sd_type, probed_msc_df['actual_bce'], probed_msc_df['shuffled_bce'])

                fig = go.Figure()

                msc_level = probed_msc_df.groupby(['msc_in_probed']).sd_measure\
                    .agg(mean='mean', sem=sem).reset_index()

                fig.add_trace(go.Bar(
                    x=msc_level['msc_in_probed'], y=msc_level['mean'],
                    error_y=dict(array=msc_level['sem'], symmetric=True),
                    text=msc_level['mean'].round(3), textposition='outside'
                ))

                result = permutation_test(
                    [
                        probed_msc_df[probed_msc_df.msc_in_probed == '0'].sd_measure,
                        probed_msc_df[probed_msc_df.msc_in_probed == '>0'].sd_measure,
                    ],
                    statistic=statistic,
                    permutation_type='independent',
                    n_resamples=9999,
                    alternative='two-sided',
                    random_state=0,
                )
                pval_text = p_val_text(result.pvalue)
                fig.add_annotation(x=0.5, y=-0.023, showarrow=False, text=f'"0" != ">0"<br>{pval_text}; Permutation Test')

                title = f'Acc'
                fig.update_layout(font_size=15, title=dict(text=title, xanchor='center', x=0.5),
                                  legend=dict(yanchor='top', y=0.99, xanchor='left', x=0.01, title_text='Num(Mscs)'),
                                  width=800, height=600)
                fig.update_xaxes(title_text=f'Num(MScs) within {2 * deg_window}° window around<br>Probed Side '
                                            f'[{start}, {end}] ms after Probe Onset')
                fig.update_yaxes(title_text=f'{sd_text} - BCE in Current Trial at Probed Side')
                fig.show()


if __name__ == '__main__':
    trial_msc_sd_rt('sans_block')
    trial_msc_sd_acc('sans_block')
