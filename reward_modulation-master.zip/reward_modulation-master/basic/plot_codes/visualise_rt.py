import pandas
import plotly.express as px
import plotly.graph_objs as go
from config import project_dir
from utils_data import colours, num_gain_blocks
from utils_processing.metrics import compute_robust_corr, compute_mse


def rt_scatter(values_df, title):
    values_df['sub_emb'] = values_df.sub_emb.apply(int).apply(str)
    values_df['block_emb'] = values_df.block_emb.apply(int).apply(str)

    min_value = min(values_df['rt_target'].min(), values_df['rt_pred'].min())
    max_value = max(values_df['rt_target'].max(), values_df['rt_pred'].max())

    # Actual History Predictions
    actual_corrs = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_robust_corr(df, 'rt_target', 'rt_pred')['corr'])
    actual_corrs.name = 'metric'
    actual_corrs = actual_corrs.reset_index()
    actual_corrs = actual_corrs.groupby(['sub_emb']).metric.mean()
    mean_corr = actual_corrs.mean()

    actual_mses = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_mse(df, 'rt_target', 'rt_pred'))
    actual_mses.name = 'metric'
    actual_mses = actual_mses.reset_index()
    actual_mses = actual_mses.groupby(['sub_emb']).metric.mean()
    mean_mse = actual_mses.mean()

    fig = px.scatter(values_df, x='rt_target', y='rt_pred', marginal_x='histogram', marginal_y='histogram',
                     color='sub_emb', labels={'rt_target': 'Observed RT', 'rt_pred': 'Predicted RT',
                                              'sub_emb': 'Subject ID'}, color_discrete_sequence=colours, opacity=0.6,
                     title='Actual History Predictions ' + title)
    annotation = f'Mean Robust Corr = {mean_corr:.3f}<br>Mean MSE = {mean_mse:.3f}<br>over Seed, over Subjects'
    fig.add_annotation(text=annotation, align='center',
                       showarrow=False, xref='paper', yref='paper', font=dict(size=18), x=1.0, y=0.95,
                       bordercolor='black', borderwidth=1)

    fig.add_trace(go.Scatter(
        x=[min_value, max_value], y=[min_value, max_value], mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_layout(yaxis_range=[min_value, max_value], xaxis_range=[min_value, max_value],
                      width=900, height=800, font_size=15)
    fig.show()


def rt_scatter_facets(values_df, title, sub_order: list[int]):
    assert len(sub_order) == 6  # three good and three bad subjects (across corr and mse)
    values_df = values_df.query(f'sub_emb in {sub_order}').copy()

    min_value = min(values_df['rt_target'].min(), values_df['rt_pred'].min())
    max_value = max(values_df['rt_target'].max(), values_df['rt_pred'].max())

    values_df['sub_emb'] = values_df.sub_emb.apply(int)
    values_df['block_emb'] = values_df.block_emb.apply(int)

    # Actual History Predictions
    actual_corrs = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_robust_corr(df, 'rt_target', 'rt_pred')['corr'])
    actual_corrs.name = 'metric'
    actual_corrs = actual_corrs.reset_index()
    actual_corrs = actual_corrs.groupby(['sub_emb']).metric.mean()

    actual_mses = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_mse(df, 'rt_target', 'rt_pred'))
    actual_mses.name = 'metric'
    actual_mses = actual_mses.reset_index()
    actual_mses = actual_mses.groupby(['sub_emb']).metric.mean()

    fig = px.scatter(values_df, x='rt_target', y='rt_pred',
                     facet_col='sub_emb', facet_col_wrap=3, symbol='block_emb',
                     labels={'rt_target': 'Observed RT', 'rt_pred': 'Predicted RT',
                             'sub_emb': 'Subject ID', 'block_emb': 'Block#'},
                     title='Actual History Predictions ' + title,
                     category_orders={'sub_emb': sub_order, 'block_emb': list(range(num_gain_blocks))})

    # Annotations Work
    def get_annotation_text(idx):
        sub = sub_order[idx]
        return f'Subj = {sub}<br>' \
               f'R.Corr = {round(actual_corrs[sub], 3)}<br>' \
               f'MSE = {round(actual_mses[sub], 3)}'

    annot_kwargs = dict(align='left', showarrow=False, xref='paper', yref='paper', font=dict(size=15),
                        bordercolor='black', borderwidth=1)
    fig.add_annotation(text=get_annotation_text(0), **annot_kwargs, x=0, y=0.995)
    fig.add_annotation(text=get_annotation_text(1), **annot_kwargs, x=0.395, y=0.995)
    fig.add_annotation(text=get_annotation_text(2), **annot_kwargs, x=0.79, y=0.995)
    fig.add_annotation(text=get_annotation_text(3), **annot_kwargs, x=0, y=0.4)
    fig.add_annotation(text=get_annotation_text(4), **annot_kwargs, x=0.395, y=0.4)
    fig.add_annotation(text=get_annotation_text(5), **annot_kwargs, x=0.79, y=0.4)

    # y=x line
    trace = go.Scatter(x=[min_value, max_value], y=[min_value, max_value], mode='lines', line=dict(color='red'),
                       name='y=x')
    trace.update(legendgroup='y=x line', showlegend=False)
    fig.add_trace(trace, row='all', col='all', exclude_empty_subplots=True)
    fig.update_traces(selector=-1, showlegend=True)

    fig.update_layout(width=1260, height=800, font_size=15)
    fig.update_xaxes(range=[min_value, max_value])
    fig.update_yaxes(range=[min_value, max_value])
    fig.show()


def rt_scatter_block_facet(values_df, title, sub_emb):
    values_df = values_df.query(f'sub_emb == {sub_emb}').copy()

    min_value = min(values_df['rt_target'].min(), values_df['rt_pred'].min())
    max_value = max(values_df['rt_target'].max(), values_df['rt_pred'].max())

    values_df['block_emb'] = values_df.block_emb.apply(int)

    fig = px.scatter(values_df, x='rt_target', y='rt_pred',
                     facet_col='block_emb', facet_col_wrap=3, symbol='seed',
                     labels={'rt_target': 'Observed RT', 'rt_pred': 'Predicted RT', 'block_emb': 'Block',
                             'seed': 'Seed'},
                     title=f'{title} for Subject ID={sub_emb}',
                     category_orders={'block_emb': list(range(num_gain_blocks))})

    # y=x line
    trace = go.Scatter(x=[min_value, max_value], y=[min_value, max_value], mode='lines', line=dict(color='red'),
                       name='y=x')
    trace.update(legendgroup='y=x line', showlegend=False)
    fig.add_trace(trace, row='all', col='all', exclude_empty_subplots=True)
    fig.update_traces(selector=-1, showlegend=True)

    fig.update_layout(width=1260, height=800, font_size=15)
    fig.update_xaxes(range=[min_value, max_value])
    fig.update_yaxes(range=[min_value, max_value])
    fig.show()


if __name__ == '__main__':
    result_folder = project_dir + f'basic/results/sans_block_bs=64_maxep=100_rt/'
    sub_list = [13, 5, 10, 2, 8, 14]

    values = pandas.read_pickle(result_folder + f'overall-values.pkl')
    rt_scatter(values.copy(), f'Sans Block')
    rt_scatter_facets(values.copy(), f'Sans Block', sub_list)
    rt_scatter_block_facet(values.copy(), f'Sans Block', 13)
