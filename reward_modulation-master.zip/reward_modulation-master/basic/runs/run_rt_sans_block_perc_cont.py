import argparse
from basic.process_rt.processor_rt_sans_block import execute_study
from models.final import OnlyRTWithHistoryPercContFinal
from utils_generic import send_message


if __name__ == '__main__':
    bs = 64
    num_epochs = 100
    prefix = 'sans_block_perc_cont'

    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', dest='seed', type=int)
    parser.add_argument('--btest', dest='btest', type=int, action='append')
    parser.add_argument('--gpu', dest='gpu', type=int, default=0)
    args = parser.parse_args()

    for btest in args.btest:
        execute_study(OnlyRTWithHistoryPercContFinal, args.seed, btest, bs, num_epochs, prefix, [args.gpu])

    send_message(f'RT SansBlock Perceived Contingency - {prefix} for {args} Finished')
