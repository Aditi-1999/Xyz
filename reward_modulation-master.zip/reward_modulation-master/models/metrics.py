from models.base import WithHistoryBase, WithHistoryAndAttentionBase, WithoutHistoryMLPBase, \
    WithHistoryInitPrNAttnPoNBase
from abc import ABC
from torch.nn import MSELoss, BCEWithLogitsLoss
import torch


def rt_loss(model, batch, btype):
    not_training = btype != 'train'
    lstm_inp, sub_emb, block_emb, rt_target = batch
    rt_pred = model(lstm_inp, sub_emb, block_emb)
    loss_rt = MSELoss()(rt_pred, rt_target)
    model.log(f'{btype}/loss', loss_rt, on_step=False, on_epoch=True, prog_bar=True, logger=True,
              reduce_fx=torch.mean, sync_dist=not_training)
    return loss_rt


def predict_rt(model, batch):
    lstm_inp, sub_emb, block_emb, rt_target = batch
    rt_pred = model(lstm_inp, sub_emb, block_emb)
    return rt_target.cpu().numpy(), rt_pred.cpu().numpy()


def acc_loss(model, batch, btype):
    not_training = btype != 'train'
    lstm_inp, sub_emb, block_emb, acc_target = batch
    acc_pred = model(lstm_inp, sub_emb, block_emb)
    loss_acc = BCEWithLogitsLoss()(acc_pred, acc_target)
    model.log(f'{btype}/loss', loss_acc, on_step=False, on_epoch=True, prog_bar=True, logger=True,
              reduce_fx=torch.mean, sync_dist=not_training)
    return loss_acc


def predict_acc(model, batch):
    lstm_inp, sub_emb, block_emb, acc_target = batch
    acc_pred = model(lstm_inp, sub_emb, block_emb)
    return acc_target.cpu().numpy(), acc_pred.cpu().numpy()


class OnlyRTWithHistory(WithHistoryBase, ABC):

    metric = 'rt'

    def __init__(self, **kwargs):
        super(OnlyRTWithHistory, self).__init__(output_size=1, output_activation_func=None, **kwargs)

    def _common_step(self, batch, btype):
        return rt_loss(self, batch, btype)

    def predict_step(self, batch, batch_idx):
        return predict_rt(self, batch)


class OnlyAccWithHistory(WithHistoryBase, ABC):

    metric = 'accuracy'

    def __init__(self, **kwargs):
        super(OnlyAccWithHistory, self).__init__(output_size=1, output_activation_func=None, **kwargs)

    def _common_step(self, batch, btype):
        return acc_loss(self, batch, btype)

    def predict_step(self, batch, batch_idx):
        return predict_acc(self, batch)


# LSTM with Attention

class OnlyRTWithHistoryAndAttention(WithHistoryAndAttentionBase, ABC):

    metric = 'rt'

    def __init__(self, **kwargs):
        super(OnlyRTWithHistoryAndAttention, self).__init__(output_size=1, output_activation_func=None, **kwargs)

    def _common_step(self, batch, btype):
        return rt_loss(self, batch, btype)

    def predict_step(self, batch, batch_idx):
        return predict_rt(self, batch)


class OnlyAccWithHistoryAndAttention(WithHistoryAndAttentionBase, ABC):

    metric = 'accuracy'

    def __init__(self, **kwargs):
        super(OnlyAccWithHistoryAndAttention, self).__init__(output_size=1, output_activation_func=None, **kwargs)

    def _common_step(self, batch, btype):
        return acc_loss(self, batch, btype)

    def predict_step(self, batch, batch_idx):
        return predict_acc(self, batch)


# MLP without history

class OnlyRTWithoutHistoryMLP(WithoutHistoryMLPBase, ABC):

    metric = 'rt'

    def __init__(self, **kwargs):
        super(OnlyRTWithoutHistoryMLP, self).__init__(output_size=1, output_activation_func=None, **kwargs)

    def _common_step(self, batch, btype):
        return rt_loss(self, batch, btype)

    def predict_step(self, batch, batch_idx):
        return predict_rt(self, batch)


class OnlyAccWithoutHistoryMLP(WithoutHistoryMLPBase, ABC):

    metric = 'accuracy'

    def __init__(self, **kwargs):
        super(OnlyAccWithoutHistoryMLP, self).__init__(output_size=1, output_activation_func=None, **kwargs)

    def _common_step(self, batch, btype):
        return acc_loss(self, batch, btype)

    def predict_step(self, batch, batch_idx):
        return predict_acc(self, batch)


# RNN with Pre-processor, Attention and Post-processor

class OnlyRTWithHistoryInitPrNAttnPoN(WithHistoryInitPrNAttnPoNBase, ABC):

    metric = 'rt'

    def __init__(self, **kwargs):
        super(OnlyRTWithHistoryInitPrNAttnPoN, self).__init__(**kwargs)

    def _common_step(self, batch, btype):
        return rt_loss(self, batch, btype)

    def predict_step(self, batch, batch_idx):
        return predict_rt(self, batch)


class OnlyAccWithHistoryInitPrNAttnPoN(WithHistoryInitPrNAttnPoNBase, ABC):

    metric = 'accuracy'

    def __init__(self, **kwargs):
        super(OnlyAccWithHistoryInitPrNAttnPoN, self).__init__(**kwargs)

    def _common_step(self, batch, btype):
        return acc_loss(self, batch, btype)

    def predict_step(self, batch, batch_idx):
        return predict_acc(self, batch)


# Models for thresholded RT

class OnlyRTWithHistoryThresholded(WithHistoryBase, ABC):

    metric = 'rt'

    def __init__(self, threshold, **kwargs):
        super(OnlyRTWithHistoryThresholded, self).__init__(output_size=1, output_activation_func=torch.tanh, **kwargs)
        self.threshold = threshold

    def _common_step(self, batch, btype):
        not_training = btype != 'train'
        lstm_inp, sub_emb, block_emb, rt_target = batch
        rt_pred = self(lstm_inp, sub_emb, block_emb) * self.threshold
        loss_rt = MSELoss()(rt_pred, rt_target)
        self.log(f'{btype}/loss', loss_rt, on_step=False, on_epoch=True, prog_bar=True, logger=True,
                 reduce_fx=torch.mean, sync_dist=not_training)
        return loss_rt

    def predict_step(self, batch, batch_idx):
        lstm_inp, sub_emb, block_emb, rt_target = batch
        rt_pred = self(lstm_inp, sub_emb, block_emb) * self.threshold
        return rt_target.cpu().numpy(), rt_pred.cpu().numpy()
