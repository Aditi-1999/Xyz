import pandas
import plotly.graph_objs as go
from config import project_dir
from utils_processing import mc_seeds
from utils_data import sd_types
from utils_data.helper import sigmoid, inverse_sigmoid, serial_dependence_measure
from utils_processing.metrics import compute_bce, compute_robust_corr, p_val_text

sd_type = 'difference'


def compare_bces(values_df):
    intact_bces = values_df.groupby(['sub_num', 'seed', 'block_emb']).apply(lambda df: compute_bce(df, 'acc_target', 'acc_pred'))
    intact_bces.name = 'metric'
    intact_bces = intact_bces.reset_index()
    intact_bces = intact_bces.groupby(['sub_num']).metric.mean()

    scrambled_bces = values_df.groupby(['sub_num', 'seed', 'block_emb']).apply(lambda df: compute_bce(df, 'acc_target_bs', 'acc_pred_bs'))
    scrambled_bces.name = 'metric'
    scrambled_bces = scrambled_bces.reset_index()
    scrambled_bces = scrambled_bces.groupby(['sub_num']).metric.mean()

    sd = serial_dependence_measure(sd_type, intact_bces, scrambled_bces)
    sd.name = 'sd'

    acc = values_df.groupby(['sub_num', 'seed', 'block_emb']).acc_target.mean().reset_index() \
        .groupby(['sub_num']).acc_target.mean()

    data_df = pandas.DataFrame([sd, acc]).transpose().reset_index()

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=data_df.acc_target, y=data_df.sd,
        mode='markers', marker=dict(size=15),
    ))

    rcorr = compute_robust_corr(data_df, 'acc_target', 'sd', 'less')
    title = f'R.Corr = {rcorr["corr"]:.3f}, {p_val_text(rcorr["pval"])} for R.Corr < 0'

    fig.update_layout(width=800, height=600, font_size=15, title=dict(text=title, xanchor='center', x=0.5))
    fig.update_xaxes(title_text='Participant Accuracy')
    fig.update_yaxes(title_text=f'{sd_types[sd_type]} - BCE')

    fig.show()


if __name__ == '__main__':
    result_folder = project_dir + f'basic_v2/results/reencode_bs=64_maxep=100_acc/'
    values = pandas.read_pickle(result_folder + f'mc-test_values.pkl')
    pred_cols = list(map(lambda x: f'acc_pred_{x}', range(len(mc_seeds))))
    values['acc_pred'] = values[pred_cols].applymap(sigmoid).mean(axis=1).apply(inverse_sigmoid)
    pred_cols = list(map(lambda x: f'acc_pred_bs_{x}', range(len(mc_seeds))))
    values['acc_pred_bs'] = values[pred_cols].applymap(sigmoid).mean(axis=1).apply(inverse_sigmoid)
    compare_bces(values)
