from basic_v2.final_analyses import rt_file, get_sub_actual_corrs, get_sub_actual_mses, get_ttest_wilcoxon_text, \
    acc_file, get_sub_actual_aurocs, get_sub_actual_bces
import plotly.express as px
import plotly.graph_objs as go
from config import project_dir


def compare_metrics_rt(common_path, subjwise_path):
    common_values_df = rt_file(common_path + f'mc-test_values.pkl')
    subjwise_values_df = rt_file(subjwise_path + f'mc-test_values.pkl')

    common_corr = get_sub_actual_corrs(common_values_df)
    common_mse = get_sub_actual_mses(common_values_df)
    subj_corr = get_sub_actual_corrs(subjwise_values_df)
    subj_mse = get_sub_actual_mses(subjwise_values_df)

    # Robust Correlation Scatter
    corr_range = [-0.1, 0.5]
    test_text = get_ttest_wilcoxon_text(x=common_corr, y=subj_corr, direction='greater')  # test if x > y
    title = f'SRM - Robust Correlation (Predicted RT, Observed RT)<br>WithSE > SansSE<br>{test_text}'
    fig = px.scatter(x=common_corr, y=subj_corr)
    fig.add_trace(go.Scatter(x=corr_range, y=corr_range, mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_xaxes(title_text='Common Model With SE')
    fig.update_yaxes(title_text='Common Model Sans SE')
    fig.update_layout(width=900, height=800, font_size=15, xaxis_range=corr_range, yaxis_range=corr_range,
                      title=dict(text=title, xanchor='center', x=0.5))
    fig.show()

    # MSE Scatter
    mse_range = [0.8, 2.1]
    test_text = get_ttest_wilcoxon_text(x=common_mse, y=subj_mse, direction='less')  # test if x < y
    title = f'SRM - MSE (Predicted RT, Observed RT)<br>WithSE < SansSE<br>{test_text}'
    fig = px.scatter(x=common_mse, y=subj_mse)
    fig.add_trace(go.Scatter(x=mse_range, y=mse_range, mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_xaxes(title_text='Common Model With SE')
    fig.update_yaxes(title_text='Common Model Sans SE')
    fig.update_layout(width=900, height=800, font_size=15, xaxis_range=mse_range, yaxis_range=mse_range,
                      title=dict(text=title, xanchor='center', x=0.5))
    fig.show()


def compare_metrics_acc(common_path, subjwise_path):
    common_values_df = acc_file(common_path + f'mc-test_values.pkl')
    subjwise_values_df = acc_file(subjwise_path + f'mc-test_values.pkl')

    common_auroc = get_sub_actual_aurocs(common_values_df)
    common_bce = get_sub_actual_bces(common_values_df)
    subj_auroc = get_sub_actual_aurocs(subjwise_values_df)
    subj_bce = get_sub_actual_bces(subjwise_values_df)

    # AUROC Scatter
    auroc_range = [0.45, 0.9]
    test_text = get_ttest_wilcoxon_text(x=common_auroc, y=subj_auroc, direction='greater')  # test if x > y
    title = f'SRM - AUROC (Predicted Acc, Observed Acc)<br>WithSE > SansSE<br>{test_text}'
    fig = px.scatter(x=common_auroc, y=subj_auroc)
    fig.add_trace(go.Scatter(x=auroc_range, y=auroc_range, mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_xaxes(title_text='Common Model With SE')
    fig.update_yaxes(title_text='Common Model Sans SE')
    fig.update_layout(width=900, height=800, font_size=15, xaxis_range=auroc_range, yaxis_range=auroc_range,
                      title=dict(text=title, xanchor='center', x=0.5))
    fig.show()

    # BCE Scatter
    bce_range = [0.4, 0.75]
    test_text = get_ttest_wilcoxon_text(x=common_bce, y=subj_bce, direction='less')  # test if x < y
    title = f'SRM - BCE (Predicted Acc, Observed Acc)<br>WithSE < SansSE<br>{test_text}'
    fig = px.scatter(x=common_bce, y=subj_bce)
    fig.add_trace(go.Scatter(x=bce_range, y=bce_range, mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_xaxes(title_text='Common Model With SE')
    fig.update_yaxes(title_text='Common Model Sans SE')
    fig.update_layout(width=900, height=800, font_size=15, xaxis_range=bce_range, yaxis_range=bce_range,
                      title=dict(text=title, xanchor='center', x=0.5))
    fig.show()


if __name__ == '__main__':
    compare_metrics_rt(common_path=project_dir + f'basic_v2/results/sans_block_v3_bs=64_maxep=100_rt/',
                       subjwise_path=project_dir + f'basic_v2/results/sans_se_bs=64_maxep=100_rt/')
    compare_metrics_acc(common_path=project_dir + f'basic_v2/results/sans_block_v3_bs=64_maxep=100_acc/',
                        subjwise_path=project_dir + f'basic_v2/results/sans_se_bs=64_maxep=100_acc/')
