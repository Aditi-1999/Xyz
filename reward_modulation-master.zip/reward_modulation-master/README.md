Ankita's Reward Modulation task data for studying serial dependence. 

Currently, we will be looking only at Spatial reward modulation.
