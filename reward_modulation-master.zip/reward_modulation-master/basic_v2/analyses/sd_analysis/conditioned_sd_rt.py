import pandas
import plotly.graph_objs as go
from config import project_dir
from utils_processing import mc_seeds
from scipy.stats import sem, wilcoxon, ttest_rel
from utils_processing.metrics import compute_robust_corr, compute_mse, p_val_text, compute_element_mse
from utils_data import sd_types
from utils_data.helper import serial_dependence_measure


def get_actual_trial_type(row):
    if row['reward_vr_fx'] == 0 and row['side_probed'] == 0:
        # Reward@VR<FX and FX probed
        return 'valid'
    if row['reward_vr_fx'] == 1 and row['side_probed'] == 1:
        # Reward@VR>FX and VR probed
        return 'valid'
    if row['reward_vr_fx'] == 0 and row['side_probed'] == 1:
        # Reward@VR<FX and VR probed
        return 'invalid'
    if row['reward_vr_fx'] == 1 and row['side_probed'] == 0:
        # Reward@VR>FX and FX probed
        return 'invalid'
    return pandas.NA


def get_perc_trial_type(row):
    if row['perc_vr_gt_fx'] == 0 and row['side_probed'] == 0:
        # Reward@VR<FX and FX probed
        return 'valid'
    if row['perc_vr_gt_fx'] == 1 and row['side_probed'] == 1:
        # Reward@VR>FX and VR probed
        return 'valid'
    if row['perc_vr_gt_fx'] == 0 and row['side_probed'] == 1:
        # Reward@VR<FX and VR probed
        return 'invalid'
    if row['perc_vr_gt_fx'] == 1 and row['side_probed'] == 0:
        # Reward@VR>FX and FX probed
        return 'invalid'
    return pandas.NA


def compare_mses(values_df, sd_type, variable, more_title):
    values_df = values_df[values_df[variable].isin(['valid', 'invalid'])]

    values_df = values_df.groupby(['sub_num', 'seed', 'btest', variable]) \
        .agg({'actual_mse': 'mean', 'shuffled_mse': 'mean'}) \
        .reset_index()
    values_df = values_df.groupby(['sub_num', variable]) \
        .agg({'actual_mse': 'mean', 'shuffled_mse': 'mean'}) \
        .reset_index()

    values_df['sd'] = serial_dependence_measure(sd_type, values_df.actual_mse, values_df.shuffled_mse)

    con0 = values_df[values_df[variable] == 'valid']
    con1 = values_df[values_df[variable] == 'invalid']

    fig = go.Figure()
    fig.add_trace(go.Bar(x=['valid', 'invalid'], y=[con0.sd.mean(), con1.sd.mean()], showlegend=False))

    pt_p_val = ttest_rel(a=con0.sd, b=con1.sd, alternative='two-sided')[1]  # test if a != b
    w_p_val = wilcoxon(x=con0.sd, y=con1.sd, alternative='two-sided')[1]  # test if x != y
    fig.add_annotation(x=0.5, y=0.1, showarrow=False,
                       text=f'valid != invalid<br>{p_val_text(pt_p_val)}; Paired-t<br>{p_val_text(w_p_val)}; Wilcoxon')

    for sub_num in values_df.sub_num.unique():
        sub0 = con0.query(f'sub_num == {sub_num}')
        sub1 = con1.query(f'sub_num == {sub_num}')
        fig.add_trace(go.Scatter(x=['valid', 'invalid'], y=[sub0.sd.iloc[0], sub1.sd.iloc[0]],
                                 mode='lines+markers', marker=dict(color='red'), opacity=0.3,
                                 name=f'{sub_num}',  # showlegend=False,
                                 ))

    fig.update_layout(width=400, height=800, font_size=15)
    fig.update_xaxes(title_text=variable + more_title)
    fig.update_yaxes(title_text=sd_types[sd_type] + '- MSE')
    fig.show()


if __name__ == '__main__':
    result_folder = project_dir + f'basic_v2/results/sans_block_v3_bs=64_maxep=100_rt/'
    values = pandas.read_pickle(result_folder + f'mc-test_values.pkl')
    pred_cols = list(map(lambda x: f'rt_pred_{x}', range(len(mc_seeds))))
    values['rt_pred'] = values[pred_cols].mean(axis=1)
    pred_cols = list(map(lambda x: f'rt_pred_bs_{x}', range(len(mc_seeds))))
    values['rt_pred_bs'] = values[pred_cols].mean(axis=1)

    values['actual_mse'] = compute_element_mse(values, 'rt_target', 'rt_pred')
    values['shuffled_mse'] = compute_element_mse(values, 'rt_target_bs', 'rt_pred_bs')

    values['att'] = values.apply(get_actual_trial_type, axis=1)
    values['ptt'] = values.apply(get_perc_trial_type, axis=1)

    values = values[values.side_probed == 1]
    more_title = ' - VR Probed'

    for variable in ['att', 'ptt']:
        for sd_type in sd_types.keys():
            compare_mses(values, sd_type, variable, more_title)
