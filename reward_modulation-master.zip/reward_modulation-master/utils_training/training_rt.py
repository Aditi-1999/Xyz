import os
import uuid
import torch
import numpy
import wandb
import pandas
import optuna
from typing import Optional
from scipy.stats import boxcox
from pytorch_lightning import Trainer
from config import use_gpu, num_cpus, wandb_project
from torch.utils.data import DataLoader, TensorDataset
from pytorch_lightning.loggers.wandb import WandbLogger
from pytorch_lightning.utilities.seed import seed_everything
from utils_processing.gpu_related import get_trainer_gpu_kwargs, get_device
from pytorch_lightning.callbacks import LearningRateMonitor, ModelCheckpoint
from utils_processing.common_proc import get_train_test_split_df, final_columns


def transform_rt(gdf, sub_config):
    sub_emb = gdf.sub_emb.iloc[0]
    rts = gdf['response_time']
    lmbda, mean, std = sub_config[(sub_emb, 'lambda')], sub_config[(sub_emb, 'mean')], sub_config[(sub_emb, 'std')]
    bxcx_rts = boxcox(rts, lmbda)
    zscored = (bxcx_rts - mean) / std
    op = pandas.Series(zscored, index=gdf.index, name='response_time')
    return op


def get_sub_config(response_times):
    transformed, lmbda = boxcox(response_times)
    return {
        'mean': transformed.mean().item(),
        'std': transformed.std().item(),
        'lambda': lmbda.item(),
    }


def learn_transform_rt(btest, bval, proc_df, train_test_split_df, threshold: Optional[float]):
    test_block = 'block{}'.format(btest)
    val_block = 'block{}'.format(bval)
    test_idxs = list(train_test_split_df[['sub_emb', test_block]].itertuples(index=False, name=None))
    val_idxs = list(train_test_split_df[['sub_emb', val_block]].itertuples(index=False, name=None))

    proc_df: pandas.DataFrame = proc_df.copy()
    proc_df.dropna(subset=['response_time'], inplace=True)  # Do not predict for NaN responses

    # Get the subject config params from training data
    train_data = proc_df.loc[~proc_df.index.isin(test_idxs) & ~proc_df.index.isin(val_idxs)].copy()
    sub_config = train_data.groupby('sub_emb').response_time.apply(get_sub_config).to_dict()

    # Transform the data
    df = proc_df.copy().reset_index()  # reset_index because transform_rt requires it
    ser = df.groupby('sub_emb').apply(lambda gdf: transform_rt(gdf, sub_config))
    if len(proc_df.sub_num.unique()) == 1:  # There is only one subject
        df['rt'] = ser.iloc[0].tolist()
    else:
        ser.index.names = ['sub_emb'] + ['actual_idx']
        ser = ser.reset_index()
        df['rt'] = ser.sort_values(by=['actual_idx']).response_time.tolist()
    df.set_index(['sub_emb', 'block_emb'], inplace=True)

    if threshold is not None:
        valid_trials = (-threshold <= df.rt) & (df.rt <= threshold)
        df = df[valid_trials].copy()

    # Split into train, val and test
    train_df = df.loc[~df.index.isin(test_idxs) & ~df.index.isin(val_idxs)].copy().reset_index()
    val_df = df.loc[df.index.isin(val_idxs)].copy().reset_index()
    test_df = df.loc[df.index.isin(test_idxs)].copy().reset_index()

    return train_df, val_df, test_df, sub_config


def split_results(prediction_results):
    targets, preds = [], []
    for t, p in prediction_results:
        targets.append(t[:, 0])
        preds.append(p[:, 0])
    target = numpy.concatenate(targets)
    pred = numpy.concatenate(preds)
    return target, pred


def get_tensors(section_df, lstm_variable, gpu_num: list[int]):
    """Get tensors that will be fed into a TensorDataset"""
    device = get_device(gpu_num)
    return [
        torch.tensor(section_df[lstm_variable].values.tolist(), dtype=torch.double, device=device),
        torch.tensor(section_df.sub_emb.tolist(), dtype=torch.long, device=device),
        torch.tensor(section_df.block_emb.tolist(), dtype=torch.long, device=device),
        torch.tensor(section_df.rt.tolist(), dtype=torch.double, device=device).view(-1, 1),
    ]


def get_train_dataloader(train_df, bs, lstm_variable, gpu_num):
    num_workers = 0 if use_gpu else num_cpus
    train_dataset = TensorDataset(*get_tensors(train_df, lstm_variable, gpu_num))
    train_dataloader = DataLoader(train_dataset, batch_size=bs, shuffle=True, num_workers=num_workers)
    return train_dataloader


def get_non_train_dataloader(non_train_df, bs, lstm_variable, gpu_num):
    num_workers = 0 if use_gpu else num_cpus
    non_train_dataset = TensorDataset(*get_tensors(non_train_df, lstm_variable, gpu_num))
    non_train_dataloader = DataLoader(non_train_dataset, batch_size=bs, shuffle=False, num_workers=num_workers)
    return non_train_dataloader


def get_data_for_trial(bs, model_class, train_df, val_df, gpu_num):
    train_dataloader = get_train_dataloader(train_df, bs, model_class.lstm_variable(), gpu_num)
    val_dataloader = get_non_train_dataloader(val_df, bs, model_class.lstm_variable(), gpu_num)
    return train_dataloader, val_dataloader


def attach_results(values, prediction_results, sub_config, suffix):
    rt_target, rt_pred = split_results(prediction_results)
    target_col, pred_col = f'rt_target{suffix}', f'rt_pred{suffix}'
    values[target_col] = rt_target.tolist()
    values[pred_col] = rt_pred.tolist()
    # todo: pending inverse transformation - may require sklearn's PowerTransformer

    return values


def execute_trial(model_class, model_kwargs, train_dataloader, val_dataloader,
                  seed: int, btest: int, bval: int, bs: int, num_epochs: int, watch_model: bool,
                  res_dir: str, study_name: str, extra_kwargs: dict, gpu_num: list[int]) -> optuna.trial.FrozenTrial:
    model = model_class(**model_kwargs)  # We mess with global seed in this fn call - better to keep it here

    seed_everything(0, workers=True)

    trial_id = f'{uuid.uuid4()}'
    result_dir = res_dir + f'{study_name}/{trial_id}/'
    os.makedirs(result_dir + 'wandb', exist_ok=True)

    config = {'model_class': model_class.__name__, 'metric': model_class.metric,
              'seed': seed, 'btest': btest, 'bval': bval, 'bs': bs, 'num_epochs': num_epochs,
              'result_dir': result_dir, 'trial_id': trial_id, 'log_code': False, 'watch_model': watch_model}
    config.update(extra_kwargs)

    run = wandb.init(dir=result_dir, config=config, project=wandb_project, group=study_name,
                     tags=[model_class.metric], settings=wandb.Settings(start_method="fork"))
    wandb_logger = WandbLogger(experiment=run)
    if watch_model:
        wandb.watch(model, log='all', log_freq=1)

    lr_monitor = LearningRateMonitor()
    checkpoint_cb = ModelCheckpoint(monitor='val/loss', mode='min', dirpath=result_dir, filename='best-{epoch}')

    trainer = Trainer(default_root_dir=result_dir, max_epochs=num_epochs,
                      logger=[wandb_logger], log_every_n_steps=1, num_sanity_val_steps=0, deterministic=True,
                      callbacks=[lr_monitor, checkpoint_cb],
                      # limit_train_batches=1, limit_val_batches=1, limit_test_batches=1, limit_predict_batches=1,
                      **get_trainer_gpu_kwargs(gpu_num))
    trainer.fit(model, train_dataloaders=train_dataloader, val_dataloaders=val_dataloader)

    # Get the best epoch number and its loss based on validation evaluation
    files = os.listdir(result_dir)
    files = filter(lambda x: x.endswith('.ckpt'), files)
    files = list(files)
    assert len(files) == 1
    ckpt = files[0]
    best_epoch = int(ckpt.split('.ckpt')[0].split('=')[1])
    os.rename(result_dir + ckpt, result_dir + 'best.ckpt')
    validation_loss = checkpoint_cb.best_model_score.item()

    wandb.config.update({'val_loss': validation_loss, 'best_epoch': best_epoch})
    if watch_model:
        wandb.unwatch(model)
    wandb.finish()

    # Create trial with all parameters as user_attrs
    trial_attrs = config.copy()
    trial_attrs.update(model.hparams)
    trial_attrs['best_epoch'] = best_epoch
    if trial_attrs.get('activation_func'):
        if not isinstance(trial_attrs['activation_func'], str):
            trial_attrs['activation_func'] = trial_attrs['activation_func'].__name__
    if trial_attrs.get('rnn_init_output_activation_func'):
        trial_attrs['rnn_init_output_activation_func'] = trial_attrs['rnn_init_output_activation_func'].__name__
    if trial_attrs.get('rnn_init_activation_func'):
        trial_attrs['rnn_init_activation_func'] = trial_attrs['rnn_init_activation_func'].__name__
    if trial_attrs.get('output_activation_func'):
        trial_attrs['output_activation_func'] = trial_attrs['output_activation_func'].__name__
    trial = optuna.create_trial(value=validation_loss, params={}, distributions={}, user_attrs={'config': trial_attrs})
    return trial


def execute_trial_p2(model, train_dataloader, val_dataloader,
                     seed: int, btest: int, bval: int, bs: int, num_epochs: int, watch_model: bool, trial_id: str,
                     res_dir: str, study_name: str, extra_kwargs: dict, gpu_num: list[int]) -> optuna.trial.FrozenTrial:
    seed_everything(0, workers=True)

    result_dir = res_dir + f'{study_name}/{trial_id}/'
    os.makedirs(result_dir + 'wandb', exist_ok=True)

    config = {'model_class': model.__class__.__name__, 'metric': model.metric,
              'seed': seed, 'btest': btest, 'bval': bval, 'bs': bs, 'num_epochs': num_epochs,
              'result_dir': result_dir, 'trial_id': trial_id, 'log_code': False, 'watch_model': watch_model}
    config.update(extra_kwargs)

    run = wandb.init(dir=result_dir, config=config, project=wandb_project, group=study_name,
                     tags=[model.metric], settings=wandb.Settings(start_method="fork"))
    wandb_logger = WandbLogger(experiment=run)
    if watch_model:
        wandb.watch(model, log='all', log_freq=1)

    lr_monitor = LearningRateMonitor()
    checkpoint_cb = ModelCheckpoint(monitor='val/loss', mode='min', dirpath=result_dir, filename='best-{epoch}')

    trainer = Trainer(default_root_dir=result_dir, max_epochs=num_epochs,
                      logger=[wandb_logger], log_every_n_steps=1, num_sanity_val_steps=0, deterministic=True,
                      callbacks=[lr_monitor, checkpoint_cb],
                      # limit_train_batches=1, limit_val_batches=1, limit_test_batches=1, limit_predict_batches=1,
                      **get_trainer_gpu_kwargs(gpu_num))
    trainer.fit(model, train_dataloaders=train_dataloader, val_dataloaders=val_dataloader)

    # Get the best epoch number and its loss based on validation evaluation
    files = os.listdir(result_dir)
    files = filter(lambda x: x.endswith('.ckpt'), files)
    files = list(files)
    assert len(files) == 1
    ckpt = files[0]
    best_epoch = int(ckpt.split('.ckpt')[0].split('=')[1])
    os.rename(result_dir + ckpt, result_dir + 'best.ckpt')
    validation_loss = checkpoint_cb.best_model_score.item()

    wandb.config.update({'val_loss': validation_loss, 'best_epoch': best_epoch})
    if watch_model:
        wandb.unwatch(model)
    wandb.finish()

    # Create trial with all parameters as user_attrs
    trial_attrs = config.copy()
    trial_attrs.update(model.hparams)
    trial_attrs['best_epoch'] = best_epoch
    trial = optuna.create_trial(value=validation_loss, params={}, distributions={}, user_attrs={'config': trial_attrs})
    return trial


def make_predictions(best_model, seed, btest, bval, bs, num_epochs, proc_df, gpu_num, threshold):
    trainer = Trainer(enable_checkpointing=False, logger=False, deterministic=True, **get_trainer_gpu_kwargs(gpu_num))

    train_test_split_df = get_train_test_split_df(seed)
    _, _, test_df, sub_config = learn_transform_rt(btest, bval, proc_df, train_test_split_df, threshold)
    value_df = test_df.reset_index()[final_columns].copy()

    test_dataloader = get_non_train_dataloader(test_df, bs, best_model.lstm_variable(), gpu_num)
    prediction_results = trainer.predict(best_model, dataloaders=test_dataloader)
    value_df = attach_results(value_df, prediction_results, sub_config, '')

    bs_test_dataloader = get_non_train_dataloader(test_df, bs, best_model.lstm_variable() + '_bs', gpu_num)
    prediction_results = trainer.predict(best_model, dataloaders=bs_test_dataloader)
    value_df = attach_results(value_df, prediction_results, sub_config, '_bs')

    value_df['btest'] = btest
    value_df['bval'] = bval
    value_df['bs'] = bs
    value_df['num_epochs'] = num_epochs
    value_df['seed'] = seed
    return value_df, sub_config


def inverse_transform_rt(subj_rts: numpy.ndarray, lmbda: float, mean: float, std: float) -> numpy.ndarray:
    """
    subj_rts: subject's rts in the transformed space
    lmbda, mean, std: boxcox parameters to perform inversion
    """
    nrts = subj_rts * std + mean
    if lmbda == 0:
        return numpy.exp(nrts)
    else:
        return (lmbda * nrts + 1) ** (1/lmbda)


def get_hist_results(best_model, data_df, values_df, gpu_num, mc_seeds, shuffled: bool):
    trainer = Trainer(enable_checkpointing=False, logger=False, deterministic=True, **get_trainer_gpu_kwargs(gpu_num))
    suffix = '_bs' if shuffled else ''
    dataloader = get_non_train_dataloader(data_df, len(data_df), best_model.lstm_variable() + suffix, gpu_num)
    for pred_num, mc_seed in enumerate(mc_seeds):
        seed_everything(mc_seed)
        prediction_results = trainer.predict(best_model, dataloaders=dataloader)
        rt_target, rt_pred = split_results(prediction_results)
        target_col, pred_col = f'rt_target{suffix}', f'rt_pred{suffix}_{pred_num}'

        if target_col in values_df:
            assert values_df[target_col].tolist() == rt_target.tolist()

        values_df[target_col] = rt_target.tolist()
        values_df[pred_col] = rt_pred.tolist()
    return values_df


def make_mc_predictions(best_model, seed, btest, bval, bs, num_epochs, proc_df, gpu_num, threshold, mc_seeds):
    train_test_split_df = get_train_test_split_df(seed)
    _, val_df, test_df, sub_config = learn_transform_rt(btest, bval, proc_df, train_test_split_df, threshold)

    val_values = val_df.reset_index()[final_columns].copy()
    test_values = test_df.reset_index()[final_columns].copy()

    val_values = get_hist_results(best_model, val_df, val_values, gpu_num, mc_seeds, False)
    test_values = get_hist_results(best_model, test_df, test_values, gpu_num, mc_seeds, False)
    test_values = get_hist_results(best_model, test_df, test_values, gpu_num, mc_seeds, True)

    aux_data = {
        'btest': btest,
        'bval': bval,
        'bs': bs,
        'num_epochs': num_epochs,
        'seed': seed,
    }
    for k, v in aux_data.items():
        val_values[k] = v
        test_values[k] = v

    return val_values, test_values, sub_config
