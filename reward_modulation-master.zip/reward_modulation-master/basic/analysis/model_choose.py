import optuna
from basic import optuna_storage
from utils_data import num_gain_blocks
import pandas
from scipy.stats import sem
from config import project_dir


pandas.set_option('display.max_colwidth', 1000)
pandas.set_option('display.max_rows', 1000)


def get_hyper_config(prefix, user_attrs_config, metric):
    if prefix in ['sans_block']:
        hyper_config = {
            'T': user_attrs_config['T'],
            'rnn_layers': user_attrs_config['rnn_layers'],
            'rnn_bidirectional': user_attrs_config['rnn_bidirectional'],
            'rnn_hidden_size': user_attrs_config['rnn_hidden_size'],
            'hidden_sizes': user_attrs_config['hidden_sizes'],
            'l2weight': user_attrs_config['l2weight'],
            'dropout': user_attrs_config['dropout'],
        }
        return str(hyper_config)  # to facilitate grouping
    if prefix in ['sans_block_perc_cont', 'sans_block_cc']:
        hyper_config = {
            'T': user_attrs_config['T'],
            'rnn_layers': user_attrs_config['rnn_layers'],
            'rnn_bidirectional': user_attrs_config['rnn_bidirectional'],
            'rnn_hidden_size': user_attrs_config['rnn_hidden_size'],
            'hidden_sizes': user_attrs_config['hidden_sizes'],
        }
        return str(hyper_config)  # to facilitate grouping
    raise Exception(f'Unknown prefix: {prefix}')


def get_all_results(seed_list, prefix, bs, num_epochs, trial_filter, metric):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_{metric}'
    storage = optuna.storages.get_storage(optuna_storage)
    all_dfs = []
    for seed in seed_list:
        for b in range(num_gain_blocks):
            study_name = f'{folder_name}_{seed}_{b}'
            study = optuna.load_study(study_name=study_name, storage=storage)
            df = study.trials_dataframe()
            df = df[df.user_attrs_config.apply(trial_filter)]
            df['folder_name'] = folder_name
            df['study_name'] = study_name
            df['seed'] = seed
            df['b'] = b
            all_dfs.append(df)
    results_df = pandas.concat(all_dfs, ignore_index=True)
    results_df['hyper_config'] = results_df.user_attrs_config.apply(lambda c: get_hyper_config(prefix, c, metric))
    counts: pandas.Series = results_df.groupby(['seed', 'hyper_config']).number.count()
    assert (counts == num_gain_blocks).all(), f"Some hyperparameters not run for some blocks! {counts}"
    return results_df


def get_full_folder_path(row):
    return project_dir + 'basic/results/' + row.folder_name + '/' + row.study_name + '/' + row.trial_id + '/'


def best_hyper_config(results_df):
    hyper_perf = results_df.groupby(['seed', 'hyper_config']).value.mean().reset_index()
    hyper_perf: pandas.DataFrame = hyper_perf.groupby('hyper_config').value.agg(val_loss='mean', sem=sem).reset_index()
    hyper_perf.sort_values(by=['val_loss'], inplace=True)
    best_config = hyper_perf.hyper_config.iloc[0]
    best_trials = results_df[results_df.hyper_config == best_config].copy()
    best_trials['trial_id'] = best_trials.user_attrs_config.apply(lambda d: d['trial_id'])
    best_trials['folder_path'] = best_trials.apply(get_full_folder_path, axis=1)
    best_trials['btest'] = best_trials.user_attrs_config.apply(lambda d: d['btest'])
    return best_trials


def best_block_hp(results_df):
    idx = results_df.groupby(['seed', 'b']).value.transform(min) == results_df.value
    best_trials = results_df[idx].copy()
    best_trials['trial_id'] = best_trials.user_attrs_config.apply(lambda d: d['trial_id'])
    best_trials['folder_path'] = best_trials.apply(get_full_folder_path, axis=1)
    best_trials['btest'] = best_trials.user_attrs_config.apply(lambda d: d['btest'])
    best_trials['T'] = best_trials.user_attrs_config.apply(lambda d: d['T'])
    return best_trials


def all_best_hps(results_df):
    idx = results_df.groupby(['seed', 'b']).value.transform(min) == results_df.value
    best_trials = results_df[idx].copy()
    best_hps = best_trials.hyper_config.unique()
    final_results = results_df[results_df.hyper_config.isin(best_hps)].copy()
    final_results['trial_id'] = final_results.user_attrs_config.apply(lambda d: d['trial_id'])
    final_results['folder_path'] = final_results.apply(get_full_folder_path, axis=1)
    final_results['btest'] = final_results.user_attrs_config.apply(lambda d: d['btest'])
    final_results['T'] = final_results.user_attrs_config.apply(lambda d: d['T'])
    return final_results


def get_best_trials_for_block(seed_list, prefix, bs, num_epochs, metric) -> pandas.DataFrame:
    all_results_df = get_all_results(seed_list=seed_list, prefix=prefix, bs=bs, num_epochs=num_epochs,
                                     trial_filter=lambda x: True, metric=metric)
    trials = best_block_hp(all_results_df)
    return trials


def get_trials_for_T(seed_list, prefix, bs, num_epochs, T, metric):
    def trial_filter(d):
        return d['T'] == T

    all_results_df = get_all_results(seed_list=seed_list, prefix=prefix, bs=bs, num_epochs=num_epochs,
                                     trial_filter=trial_filter, metric=metric)
    trials = best_hyper_config(all_results_df)
    return trials
