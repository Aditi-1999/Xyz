from utils_training.training_acc import execute_trial, learn_transform_acc, get_data_for_trial
from utils_processing.common_proc import read_data_and_preprocess, get_train_test_split_df, prespast_columns
from utils_data import num_gain_blocks, num_subjects
from basic_v2 import optuna_storage
from config import project_dir
import os
import optuna
import gc


def execute_study(model_class, seed: int, b: int, bs: int, num_epochs: int, prefix: str, gpu_num: list[int],
                  exp_type: str, dropout: float):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_acc'
    res_dir = project_dir + 'basic_v2/results/' + folder_name + '/'
    os.makedirs(res_dir, exist_ok=True)

    btest = b
    bval = (b + 1) % num_gain_blocks
    study_name = f'{folder_name}_{seed}_{b}'
    study = optuna.create_study(direction='minimize', study_name=study_name,
                                storage=optuna_storage, load_if_exists=True)

    # Hyperparameter configs to try
    sub_emb = 5

    # Get Data - depends on T
    proc_df = read_data_and_preprocess(T=0, return_raw=False, exp_type=exp_type)
    train_test_split_df = get_train_test_split_df(seed)
    train_df, val_df, _ = learn_transform_acc(btest, bval, proc_df, train_test_split_df)
    train_dataloader, val_dataloader = get_data_for_trial(bs, model_class, train_df, val_df, gpu_num)

    input_size = len(prespast_columns[model_class.lstm_variable()])
    first_layer = input_size + sub_emb
    hid_configs = [
        [first_layer, ],
        [first_layer, first_layer // 2],
        [first_layer, first_layer],
    ]
    for hidden_sizes in hid_configs:
        num_hidden_sizes = len(hidden_sizes)
        if num_hidden_sizes == 1:
            activation_func = None
        else:
            activation_func = 'gelu'

        model_kwargs = dict(
            hidden_sizes=hidden_sizes, activation_func=activation_func,
            num_subjects=num_subjects, num_blocks=0, sub_emb_dim=sub_emb, block_emb_dim=0,
            l2weight=1e-6, dropout=dropout,
            lr=0.01, exp_lr=True, mseed=0,
        )

        # Run one config
        trial = execute_trial(model_class, model_kwargs, train_dataloader, val_dataloader, seed, btest, bval, bs,
                              num_epochs, False, res_dir, study_name,
                              {'T': 0, 'prefix': prefix, 'num_hidden_sizes': num_hidden_sizes},
                              gpu_num)
        study.add_trial(trial)
        gc.collect()
