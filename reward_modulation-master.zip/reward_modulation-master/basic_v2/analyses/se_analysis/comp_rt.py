import pandas
import plotly.express as px
import plotly.graph_objs as go
from config import project_dir
from utils_processing import mc_seeds
from scipy.stats import wilcoxon, ttest_rel
from utils_processing.metrics import compute_robust_corr, compute_mse, p_val_text


def get_actual_metrics(values_df):
    actual_corrs = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_robust_corr(df, 'rt_target', 'rt_pred')['corr'])
    actual_corrs.name = 'metric'
    actual_corrs = actual_corrs.reset_index()
    actual_corrs = actual_corrs.groupby(['sub_emb']).metric.mean()

    actual_mses = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_mse(df, 'rt_target', 'rt_pred'))
    actual_mses.name = 'metric'
    actual_mses = actual_mses.reset_index()
    actual_mses = actual_mses.groupby(['sub_emb']).metric.mean()

    return actual_corrs, actual_mses


def compare_metrics(common_path, subjwise_path):
    common_values_df = pandas.read_pickle(common_path + f'mc-test_values.pkl')
    subjwise_values_df = pandas.read_pickle(subjwise_path + f'mc-test_values.pkl')

    pred_cols = list(map(lambda x: f'rt_pred_{x}', range(len(mc_seeds))))
    common_values_df['rt_pred'] = common_values_df[pred_cols].mean(axis=1)
    subjwise_values_df['rt_pred'] = subjwise_values_df[pred_cols].mean(axis=1)

    common_corr, common_mse = get_actual_metrics(common_values_df)
    subj_corr, subj_mse = get_actual_metrics(subjwise_values_df)

    # Robust Correlation Scatter
    corr_range = [-0.1, 0.5]
    corr_df = pandas.DataFrame({'common': common_corr, 'subj': subj_corr}).reset_index()
    pt_p_val = ttest_rel(a=corr_df['common'], b=corr_df['subj'], alternative='greater')[1]  # test if a > b
    w_p_val = wilcoxon(x=corr_df['common'], y=corr_df['subj'], alternative='greater')[1]  # test if x > y
    title = f'Robust Correlation (Predicted RT, Observed RT)<br>With > Without | ' \
            f'{p_val_text(pt_p_val)}; Paired-t | {p_val_text(w_p_val)}; Wilcoxon'
    fig = px.scatter(corr_df, x='common', y='subj',
                     labels={'common': 'Common Model With Subject Embeddings',
                             'subj': 'Common Model Without Subject Embeddings'})
    fig.add_trace(go.Scatter(x=corr_range, y=corr_range, mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_layout(width=900, height=800, font_size=15, xaxis_range=corr_range, yaxis_range=corr_range,
                      title=dict(text=title, xanchor='center', x=0.5))
    fig.show()

    # MSE Scatter
    mse_range = [0.8, 2.1]
    mse_df = pandas.DataFrame({'common': common_mse, 'subj': subj_mse}).reset_index()
    pt_p_val = ttest_rel(a=mse_df['common'], b=mse_df['subj'], alternative='less')[1]  # test if a < b
    w_p_val = wilcoxon(x=mse_df['common'], y=mse_df['subj'], alternative='less')[1]  # test if x < y
    title = f'MSE (Predicted RT, Observed RT)<br>With < Without | ' \
            f'{p_val_text(pt_p_val)}; Paired-t | {p_val_text(w_p_val)}; Wilcoxon'
    fig = px.scatter(mse_df, x='common', y='subj',
                     labels={'common': 'Common Model With Subject Embeddings',
                             'subj': 'Common Model Without Subject Embeddings'})
    fig.add_trace(go.Scatter(x=mse_range, y=mse_range, mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_layout(width=900, height=800, font_size=15, xaxis_range=mse_range, yaxis_range=mse_range,
                      title=dict(text=title, xanchor='center', x=0.5))
    fig.show()


if __name__ == '__main__':
    compare_metrics(common_path=project_dir + f'basic_v2/results/sans_block_v3_bs=64_maxep=100_rt/',
                    subjwise_path=project_dir + f'basic_v2/results/sans_se_bs=64_maxep=100_rt/')
