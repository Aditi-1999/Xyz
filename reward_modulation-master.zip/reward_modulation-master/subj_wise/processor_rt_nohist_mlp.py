from utils_training.training_rt import execute_trial, learn_transform_rt, get_data_for_trial
from utils_processing.common_proc import read_data_and_preprocess, get_train_test_split_df
from utils_data import num_gain_blocks
import torch.nn.functional as f
from subj_wise import optuna_storage
from config import project_dir
import os
import optuna
import gc


def execute_study(model_class, seed: int, b: int, bs: int, num_epochs: int, prefix: str, gpu_num: list[int],
                  sub_num: int):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_rt'
    res_dir = project_dir + 'subj_wise/results/' + folder_name + '/'
    os.makedirs(res_dir, exist_ok=True)

    btest = b
    bval = (b + 1) % num_gain_blocks
    train_test_split_df = get_train_test_split_df(seed)
    storage = optuna.storages.get_storage(optuna_storage)

    # Hyperparameter configs to try
    T = 0

    # Get Data - depends on T
    proc_df = read_data_and_preprocess(T, return_raw=False)

    study_name = f'{folder_name}_{sub_num}_{seed}_{b}'
    study = optuna.create_study(direction='minimize', study_name=study_name,
                                storage=storage, load_if_exists=True)

    sub_df = proc_df.query(f'sub_num == {sub_num}').copy()

    train_df, val_df, _, _ = learn_transform_rt(btest, bval, sub_df, train_test_split_df)
    train_dataloader, val_dataloader = get_data_for_trial(bs, model_class, train_df, val_df)

    first_layer = model_class.E
    hid_configs = [
        [first_layer, ],
        [first_layer, first_layer // 2],
        [first_layer, first_layer],
        [first_layer, first_layer * 2],
        [first_layer, first_layer * 2, first_layer // 2],
    ]
    for hidden_sizes in hid_configs:
        num_hidden_sizes = len(hidden_sizes)
        if num_hidden_sizes == 1:
            activation_func = None
            dropouts = [0]
        else:
            activation_func = f.gelu
            dropouts = [0, 0.2, 0.5]

        for dropout in dropouts:
            model_kwargs = dict(hidden_sizes=hidden_sizes, activation_func=activation_func,
                                num_subjects=0, num_blocks=0, sub_emb_dim=0, block_emb_dim=0,
                                lr=0.01, cycle_lr=False, cycle_config={}, exp_lr=True,
                                l2reg=False, l2weight=0,  # https://stats.stackexchange.com/a/275088/217039
                                dropout=dropout, mseed=0)

            # Run one config
            trial = execute_trial(model_class, model_kwargs, train_dataloader, val_dataloader, seed, btest, bval, bs,
                                  num_epochs, False, res_dir, study_name,
                                  {'T': T, 'prefix': prefix, 'num_hidden_sizes': num_hidden_sizes, 'sub_num': sub_num},
                                  gpu_num)
            study.add_trial(trial)
            gc.collect()
