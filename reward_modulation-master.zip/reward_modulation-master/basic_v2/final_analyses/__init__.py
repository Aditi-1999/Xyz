from utils_processing.metrics import compute_robust_corr, compute_mse, p_val_text, compute_auroc, compute_bce
import plotly.graph_objs as go
from scipy.stats import sem
from utils_data import num_subjects, num_gain_blocks
from scipy.stats import wilcoxon, ttest_rel
from utils_processing.common_proc import get_train_test_split_df
from utils_training.training_rt import learn_transform_rt
from utils_training.training_acc import learn_transform_acc
import pandas
import numpy
from utils_processing import mc_seeds
from utils_data.helper import sigmoid, inverse_sigmoid
from sklearn.linear_model import LinearRegression

dist_names = {
    'l2_median': 'L2 Distance from Median', 'l2_mean': 'L2 Distance from Mean',
    'l1_median': 'L1 Distance from Median', 'l1_mean': 'L1 Distance from Mean',
    'cos_median': 'Cosine Distance from Median', 'cos_mean': 'Cosine Distance from Mean',
}


def get_sub_actual_corrs(values_df):
    actual_corrs = values_df.groupby(['sub_num', 'seed', 'btest']).apply(
        lambda df: compute_robust_corr(df, 'rt_target', 'rt_pred')['corr'])
    actual_corrs.name = 'metric'
    actual_corrs = actual_corrs.reset_index()
    actual_corrs = actual_corrs.groupby(['sub_num']).metric.mean()
    return actual_corrs


def get_sub_shuffled_corrs(values_df):
    shuffled_corrs = values_df.groupby(['sub_num', 'seed', 'btest']).apply(
        lambda df: compute_robust_corr(df, 'rt_target_bs', 'rt_pred_bs')['corr'])
    shuffled_corrs.name = 'metric'
    shuffled_corrs = shuffled_corrs.reset_index()
    shuffled_corrs = shuffled_corrs.groupby(['sub_num']).metric.mean()
    return shuffled_corrs


def get_sub_actual_mses(values_df):
    actual_mses = values_df.groupby(['sub_num', 'seed', 'btest']).apply(
        lambda df: compute_mse(df, 'rt_target', 'rt_pred'))
    actual_mses.name = 'metric'
    actual_mses = actual_mses.reset_index()
    actual_mses = actual_mses.groupby(['sub_num']).metric.mean()
    return actual_mses


def get_sub_shuffled_mses(values_df):
    shuffled_mses = values_df.groupby(['sub_num', 'seed', 'btest']).apply(
        lambda df: compute_mse(df, 'rt_target_bs', 'rt_pred_bs'))
    shuffled_mses.name = 'metric'
    shuffled_mses = shuffled_mses.reset_index()
    shuffled_mses = shuffled_mses.groupby(['sub_num']).metric.mean()
    return shuffled_mses


def get_sub_actual_aurocs(values_df):
    actual_aurocs = values_df.groupby(['sub_num', 'seed', 'btest']).apply(
        lambda df: compute_auroc(df, 'acc_target', 'acc_pred'))
    actual_aurocs.name = 'metric'
    actual_aurocs = actual_aurocs.reset_index()
    actual_aurocs = actual_aurocs.groupby(['sub_num']).metric.mean()
    return actual_aurocs


def get_sub_shuffled_aurocs(values_df):
    shuffled_aurocs = values_df.groupby(['sub_num', 'seed', 'btest']).apply(
        lambda df: compute_auroc(df, 'acc_target_bs', 'acc_pred_bs'))
    shuffled_aurocs.name = 'metric'
    shuffled_aurocs = shuffled_aurocs.reset_index()
    shuffled_aurocs = shuffled_aurocs.groupby(['sub_num']).metric.mean()
    return shuffled_aurocs


def get_sub_actual_bces(values_df):
    actual_bces = values_df.groupby(['sub_num', 'seed', 'btest']).apply(
        lambda df: compute_bce(df, 'acc_target', 'acc_pred'))
    actual_bces.name = 'metric'
    actual_bces = actual_bces.reset_index()
    actual_bces = actual_bces.groupby(['sub_num']).metric.mean()
    return actual_bces


def get_sub_shuffled_bces(values_df):
    shuffled_bces = values_df.groupby(['sub_num', 'seed', 'btest']).apply(
        lambda df: compute_bce(df, 'acc_target_bs', 'acc_pred_bs'))
    shuffled_bces.name = 'metric'
    shuffled_bces = shuffled_bces.reset_index()
    shuffled_bces = shuffled_bces.groupby(['sub_num']).metric.mean()
    return shuffled_bces


def plot_subj_values(fig, subj_values, x):
    fig.add_trace(go.Bar(x=[x], y=[subj_values.mean()],
                         error_y=dict(array=[sem(subj_values)], symmetric=True), showlegend=False,
                         text=[subj_values.mean().round(3)], textposition='outside'))
    for sub_num in range(num_subjects):
        fig.add_trace(go.Scatter(x=[x], y=[subj_values.loc[sub_num]], mode='lines+markers',
                                 marker=dict(color='red'), opacity=0.3,
                                 name=f'{sub_num}', showlegend=False))


def get_ttest_wilcoxon_text(x, y, direction):
    pt_p_val = ttest_rel(a=x, b=y, alternative=direction)[1]
    w_p_val = wilcoxon(x=x, y=y, alternative=direction)[1]
    text = f'{p_val_text(pt_p_val)}; Paired-t<br>{p_val_text(w_p_val)}; Wilcoxon'
    return text


def rt_file(loc):
    values = pandas.read_pickle(loc)
    pred_cols = list(map(lambda x: f'rt_pred_{x}', range(len(mc_seeds))))
    values['rt_pred'] = values[pred_cols].mean(axis=1)
    pred_cols = list(map(lambda x: f'rt_pred_bs_{x}', range(len(mc_seeds))))
    values['rt_pred_bs'] = values[pred_cols].mean(axis=1)
    return values


def acc_file(loc):
    values = pandas.read_pickle(loc)
    pred_cols = list(map(lambda x: f'acc_pred_{x}', range(len(mc_seeds))))
    values['acc_pred'] = values[pred_cols].applymap(sigmoid).mean(axis=1).apply(inverse_sigmoid)
    pred_cols = list(map(lambda x: f'acc_pred_bs_{x}', range(len(mc_seeds))))
    values['acc_pred_bs'] = values[pred_cols].applymap(sigmoid).mean(axis=1).apply(inverse_sigmoid)
    return values


def make_se_predictions(df_subj):
    assert len(df_subj) == num_subjects
    cols = list(map(lambda x: f'x{x}', range(1, 6)))
    predictions = []
    for sub in range(num_subjects):
        train_data = df_subj[df_subj.subject != sub]
        test_data = df_subj[df_subj.subject == sub]
        lr = LinearRegression()
        lr.fit(X=train_data[cols], y=train_data['target'])
        pred = lr.predict(X=test_data[cols])[0].item()
        predictions.append(pred)
    df_subj['pred'] = predictions
    return df_subj


def get_subj_embed_df(model_class, folder_path):
    cols = list(map(lambda x: f'x{x}', range(1, 6)))
    actual_model = model_class.load_from_checkpoint(folder_path + 'best.ckpt')
    subj_embed = numpy.array(actual_model.embeddings['sub_embedding'].weight.tolist())
    df_subj = pandas.DataFrame(subj_embed, columns=cols)
    df_subj['subject'] = list(range(num_subjects))
    return df_subj


def get_test_df_rt(trial, proc_dfs):
    T, seed, btest = trial['T'], trial['seed'], trial['btest']
    bval = (btest + 1) % num_gain_blocks
    train_test_split_df = get_train_test_split_df(seed)
    _, _, test_df, _ = learn_transform_rt(btest, bval, proc_dfs[T], train_test_split_df, None)
    return test_df


def get_test_df_acc(trial, proc_dfs):
    T, seed, btest = trial['T'], trial['seed'], trial['btest']
    bval = (btest + 1) % num_gain_blocks
    train_test_split_df = get_train_test_split_df(seed)
    _, _, test_df = learn_transform_acc(btest, bval, proc_dfs[T], train_test_split_df)
    return test_df
