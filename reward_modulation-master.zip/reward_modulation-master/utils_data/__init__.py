num_subjects = 24
num_actual_blocks = 12
num_gain_blocks = 6
num_trials_per_block = 48

colours = ["red", "green", "blue", "goldenrod", "magenta",
           "cyan", "violet", "chartreuse", "darkorchid", "indigo",
           "khaki", "hotpink", "yellow", "deepskyblue", "brown",
           "fuchsia", "teal", "cadetblue", "darkmagenta", "tomato",
           "yellowgreen", "navy", "olive", "gold", "purple",
           "white", "lightgray", "darkgray"]

sd_types: dict[str, str] = {
    'difference': '(Actual - Shuffled)',
    'modulated_shuffled': '(Actual - Shuffled) / Shuffled',
    'modulated_actual': '(Actual - Shuffled) / Actual',
    'modulated_sum': '(Actual - Shuffled) / (Actual + Shuffled)',
}
