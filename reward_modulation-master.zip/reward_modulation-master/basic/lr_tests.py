from utils_training.training_acc import learn_transform_acc, get_data_for_trial as get_data_for_trial_acc
from utils_training.training_rt import learn_transform_rt, get_data_for_trial as get_data_for_trial_rt
from utils_processing.common_proc import read_data_and_preprocess, get_train_test_split_df
from utils_data import num_gain_blocks, num_subjects
from pytorch_lightning import Trainer
from utils_processing import seeds
import torch.nn.functional as f
import pandas


def run_lr_test_rt(model_class):
    import plotly.graph_objects as go
    bs = 64
    T = 10

    proc_df = read_data_and_preprocess(T, return_raw=False)
    model_kwargs = dict(rnn_hidden_size=10, rnn_layers=1, rnn_bidirectional=False,
                        rnn_initial='none', rnn_init_hidden_sizes=[], rnn_init_activation_func=None,
                        rnn_init_output_activation_func=None,
                        hidden_sizes=[18, 10, ], activation_func=f.gelu,
                        num_subjects=num_subjects, num_blocks=num_gain_blocks, sub_emb_dim=5, block_emb_dim=3,
                        lr=0.1, cycle_lr=False, cycle_config={}, exp_lr=False,
                        l2reg=False, l2weight=0, dropout=0, mseed=0)

    suggestions = []

    fig = go.Figure()

    for seed in seeds[:3]:
        for b in range(num_gain_blocks):
            btest = b
            bval = (b + 1) % num_gain_blocks

            model = model_class(**model_kwargs)

            train_test_split_df = get_train_test_split_df(seed)
            train_df, val_df, _, _ = learn_transform_rt(btest, bval, proc_df, train_test_split_df)
            train_dataloader, val_dataloader = get_data_for_trial_rt(bs, model_class, train_df, val_df)

            trainer = Trainer(deterministic=True)
            lr_finder = trainer.tuner.lr_find(model, train_dataloaders=train_dataloader, val_dataloaders=val_dataloader,
                                              num_training=len(train_dataloader))
            suggestion = lr_finder.suggestion()
            lrs, losses, idx = lr_finder.results['lr'], lr_finder.results['loss'], lr_finder._optimal_idx

            fig.add_trace(go.Scatter(x=lrs, y=losses, name=f'seed={seed}, b={b}'))
            fig.add_trace(go.Scatter(x=[suggestion], y=[losses[idx]], showlegend=False,
                                     marker=dict(size=15, symbol='cross', color='black')))
            suggestions.append(dict(seed=seed, b=b, lr=suggestion))

    suggestion_df = pandas.DataFrame(suggestions)
    print(suggestion_df)

    fig.update_layout(xaxis_title='Learning Rate', yaxis_title='Loss', title='Response LR Plot')
    fig.update_xaxes(type='log')
    fig.show()


def run_lr_test_acc(model_class):
    import plotly.graph_objects as go
    bs = 64
    T = 10

    proc_df = read_data_and_preprocess(T, return_raw=False)
    model_kwargs = dict(rnn_hidden_size=10, rnn_layers=1, rnn_bidirectional=False,
                        rnn_initial='none', rnn_init_hidden_sizes=[], rnn_init_activation_func=None,
                        rnn_init_output_activation_func=None,
                        hidden_sizes=[18, 10, ], activation_func=f.gelu,
                        num_subjects=num_subjects, num_blocks=num_gain_blocks, sub_emb_dim=5, block_emb_dim=3,
                        lr=0.1, cycle_lr=False, cycle_config={}, exp_lr=False,
                        l2reg=False, l2weight=0, dropout=0, mseed=0)

    suggestions = []

    fig = go.Figure()

    for seed in seeds[:3]:
        for b in range(num_gain_blocks):
            btest = b
            bval = (b + 1) % num_gain_blocks

            model = model_class(**model_kwargs)

            train_test_split_df = get_train_test_split_df(seed)
            train_df, val_df, _ = learn_transform_acc(btest, bval, proc_df, train_test_split_df)
            train_dataloader, val_dataloader = get_data_for_trial_acc(bs, model_class, train_df, val_df)

            trainer = Trainer(deterministic=True)
            lr_finder = trainer.tuner.lr_find(model, train_dataloaders=train_dataloader, val_dataloaders=val_dataloader,
                                              num_training=len(train_dataloader))
            suggestion = lr_finder.suggestion()
            lrs, losses, idx = lr_finder.results['lr'], lr_finder.results['loss'], lr_finder._optimal_idx

            fig.add_trace(go.Scatter(x=lrs, y=losses, name=f'seed={seed}, b={b}'))
            fig.add_trace(go.Scatter(x=[suggestion], y=[losses[idx]], showlegend=False,
                                     marker=dict(size=15, symbol='cross', color='black')))
            suggestions.append(dict(seed=seed, b=b, lr=suggestion))

    suggestion_df = pandas.DataFrame(suggestions)
    print(suggestion_df)

    fig.update_layout(xaxis_title='Learning Rate', yaxis_title='Loss', title='Response LR Plot')
    fig.update_xaxes(type='log')
    fig.show()
