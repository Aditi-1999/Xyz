from models.forwards import \
    OnlyRTWithHistoryBasic, OnlyAccWithHistoryBasic, \
    OnlyRTWithHistoryAndAttentionBasic, OnlyAccWithHistoryAndAttentionBasic, \
    OnlyRTWithoutHistoryMLPBasic, OnlyAccWithoutHistoryMLPBasic, \
    OnlyRTWithHistoryThresholdedBasic
from models.metrics import OnlyRTWithHistoryInitPrNAttnPoN, OnlyAccWithHistoryInitPrNAttnPoN
from utils_processing.common_proc import prespast_columns

__all__ = ['OnlyRTWithHistoryBasicFinal', 'OnlyAccWithHistoryBasicFinal',
           'OnlyRTWithHistoryBasicCCFinal', 'OnlyAccWithHistoryBasicCCFinal',
           'OnlyRTWithHistoryAndAttentionBasicFinal', 'OnlyAccWithHistoryAndAttentionBasicFinal',
           'OnlyRTWithoutHistoryMLPBasicFinal', 'OnlyAccWithoutHistoryMLPBasicFinal',
           'OnlyRTWithHistoryInitPrNAttnPoNFinal', 'OnlyAccWithHistoryInitPrNAttnPoNFinal',
           'OnlyRTWithHistoryPercContFinal', 'OnlyAccWithHistoryPercContFinal',
           'OnlyRTWithHistoryThresholdedFinal',
           'OnlyRTWithHistoryBothContFinal',
           'OnlyRTWithHistoryPercContSansAccruedFinal', 'OnlyAccWithHistoryPercContSansAccruedFinal',
           'OnlyRTWithHistoryPercContSansStimDuraFinal', 'OnlyAccWithHistoryPercContSansStimDuraFinal',
           'OnlyRTWithHistoryPercContSansIsWrongFinal',
           ]


class OnlyRTWithHistoryBasicFinal(OnlyRTWithHistoryBasic):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyRTWithHistoryBasicFinal, self).__init__(rnn_input_size=E, **kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'rt_prespast'


class OnlyRTWithHistoryBasicCCFinal(OnlyRTWithHistoryBasic):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyRTWithHistoryBasicCCFinal, self).__init__(rnn_input_size=E, **kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'rt_prespast_cc'


class OnlyAccWithHistoryBasicFinal(OnlyAccWithHistoryBasic):  # todo: fix this - might need to run sans_block again
    lstm_var = 'acc_prespast'
    vars = prespast_columns[lstm_var]
    E = len(vars)  # Dimension of vector to be input into each cell for LSTM

    def __init__(self, **kwargs):
        super(OnlyAccWithHistoryBasicFinal, self).__init__(rnn_input_size=self.E, **kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return cls.lstm_var if cls.lstm_var else 'trial_num'


class OnlyAccWithHistoryBasicCCFinal(OnlyAccWithHistoryBasic):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyAccWithHistoryBasicCCFinal, self).__init__(rnn_input_size=E, **kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'acc_prespast_cc'


# LSTM with Attention

class OnlyRTWithHistoryAndAttentionBasicFinal(OnlyRTWithHistoryAndAttentionBasic):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyRTWithHistoryAndAttentionBasicFinal, self).__init__(rnn_input_size=E, **kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'rt_prespast'


class OnlyAccWithHistoryAndAttentionBasicFinal(OnlyAccWithHistoryAndAttentionBasic):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyAccWithHistoryAndAttentionBasicFinal, self).__init__(rnn_input_size=E, **kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'acc_prespast'


# MLP without history

class OnlyRTWithoutHistoryMLPBasicFinal(OnlyRTWithoutHistoryMLPBasic):

    def __init__(self, **kwargs):
        super(OnlyRTWithoutHistoryMLPBasicFinal, self).__init__(**kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'rt_prespast'


class OnlyAccWithoutHistoryMLPBasicFinal(OnlyAccWithoutHistoryMLPBasic):

    def __init__(self, **kwargs):
        super(OnlyAccWithoutHistoryMLPBasicFinal, self).__init__(**kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'acc_prespast'


# RNN with Pre-processor, Attention and Post-processor

class OnlyRTWithHistoryInitPrNAttnPoNFinal(OnlyRTWithHistoryInitPrNAttnPoN):

    def __init__(self, **kwargs):
        super(OnlyRTWithHistoryInitPrNAttnPoNFinal, self).__init__(**kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'rt_prespast'


class OnlyAccWithHistoryInitPrNAttnPoNFinal(OnlyAccWithHistoryInitPrNAttnPoN):

    def __init__(self, **kwargs):
        super(OnlyAccWithHistoryInitPrNAttnPoNFinal, self).__init__(**kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'acc_prespast'


# Perceived contingency instead of true contingency

class OnlyRTWithHistoryPercContFinal(OnlyRTWithHistoryBasic):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyRTWithHistoryPercContFinal, self).__init__(rnn_input_size=E, **kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'rt_perccont_prespast'


class OnlyAccWithHistoryPercContFinal(OnlyAccWithHistoryBasic):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyAccWithHistoryPercContFinal, self).__init__(rnn_input_size=E, **kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'acc_perccont_prespast'


# Perceived contingency with true contingency

class OnlyRTWithHistoryBothContFinal(OnlyRTWithHistoryBasic):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyRTWithHistoryBothContFinal, self).__init__(rnn_input_size=E, **kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'rt_bothcont_prespast'


# Perceived contingency without accrued score

class OnlyRTWithHistoryPercContSansAccruedFinal(OnlyRTWithHistoryBasic):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyRTWithHistoryPercContSansAccruedFinal, self).__init__(rnn_input_size=E, **kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'rt_perccont_sansaccrued_prespast'


class OnlyAccWithHistoryPercContSansAccruedFinal(OnlyAccWithHistoryBasic):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyAccWithHistoryPercContSansAccruedFinal, self).__init__(rnn_input_size=E, **kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'acc_perccont_sansaccrued_prespast'


# Perceived contingency without stimulus duration

class OnlyRTWithHistoryPercContSansStimDuraFinal(OnlyRTWithHistoryBasic):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyRTWithHistoryPercContSansStimDuraFinal, self).__init__(rnn_input_size=E, **kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'rt_perccont_sansstimdura_prespast'


class OnlyAccWithHistoryPercContSansStimDuraFinal(OnlyAccWithHistoryBasic):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyAccWithHistoryPercContSansStimDuraFinal, self).__init__(rnn_input_size=E, **kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'acc_perccont_sansstimdura_prespast'


# Perceived contingency without is wrong

class OnlyRTWithHistoryPercContSansIsWrongFinal(OnlyRTWithHistoryBasic):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyRTWithHistoryPercContSansIsWrongFinal, self).__init__(rnn_input_size=E, **kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'rt_perccont_sansiswrong_prespast'


# Models for thresholded RT

class OnlyRTWithHistoryThresholdedFinal(OnlyRTWithHistoryThresholdedBasic):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyRTWithHistoryThresholdedFinal, self).__init__(rnn_input_size=E, **kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'rt_prespast'
