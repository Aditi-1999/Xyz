from models.metrics import \
    OnlyRTWithHistory, OnlyAccWithHistory, \
    OnlyRTWithHistoryAndAttention, OnlyAccWithHistoryAndAttention, \
    OnlyRTWithoutHistoryMLP, OnlyAccWithoutHistoryMLP, \
    OnlyRTWithHistoryThresholded
from models.base import WithHistoryBase, none, learnable, embeddings, unknown_rnn_init, WithoutHistoryMLPBase
from abc import ABC
import torch


def basic_forward(model: WithHistoryBase, lstm_inp, sub_emb, block_emb):
    if model.rnn_initial in [none, learnable]:
        N = lstm_inp.shape[0]
        h_0 = model.h_0.unsqueeze(1).repeat(1, N, 1)
        c_0 = model.c_0.unsqueeze(1).repeat(1, N, 1)
        concatenate_list = [
            model._get_lstm_output(model.subject_history, lstm_inp, (h_0, c_0)),  # (N, D*H)
        ]
        if 'sub_embedding' in model.embeddings:
            concatenate_list.append(model.embeddings['sub_embedding'](sub_emb))  # (N, Sb)
        if 'block_embedding' in model.embeddings:
            concatenate_list.append(model.embeddings['block_embedding'](block_emb))  # (N, B)
        op = torch.cat(concatenate_list, dim=1)  # (N, D*H+Sb+B)

    elif model.rnn_initial == embeddings:
        concatenate_list = []
        if 'sub_embedding' in model.embeddings:
            concatenate_list.append(model.embeddings['sub_embedding'](sub_emb))  # (N, Sb)
        if 'block_embedding' in model.embeddings:
            concatenate_list.append(model.embeddings['block_embedding'](block_emb))  # (N, B)
        op = torch.cat(concatenate_list, dim=1)
        op = model._forward_init_internal_layers(op)
        op = model._forward_init_output_layer(op)  # (N, H)  # will change for support
        op = torch.unsqueeze(op, 0)  # (1, N, H)  # will change for support

        op = model._get_lstm_output(model.subject_history, lstm_inp, (op, op))  # (N, D*H)

    else:
        raise unknown_rnn_init

    op = model._forward_internal_layers(op)
    op = model._forward_output_layer(op)
    return op


def embeddings_into_lstm_forward(model: WithHistoryBase, lstm_inp, sub_emb, block_emb):
    if model.rnn_initial not in [none, learnable]:
        raise Exception('Invalid rnn initial config')

    T = lstm_inp.shape[1]
    sub_emb = sub_emb.view((-1, 1)).repeat((1, T))  # (N, T)
    block_emb = block_emb.view((-1, 1)).repeat((1, T))  # (N, T)

    sub_embed = model.embeddings['sub_embedding'](sub_emb)  # (N, T, Sb)
    block_embed = model.embeddings['block_embedding'](block_emb)  # (N, T, B)

    lstm_final_inp = torch.concat([lstm_inp, sub_embed, block_embed], dim=2)  # (N, T, E+Sb+B)

    N = lstm_inp.shape[0]
    h_0 = model.h_0.unsqueeze(1).repeat(1, N, 1)
    c_0 = model.c_0.unsqueeze(1).repeat(1, N, 1)
    op = model._get_lstm_output(model.subject_history, lstm_final_inp, (h_0, c_0))  # (N, D*H)
    op = model._forward_internal_layers(op)
    op = model._forward_output_layer(op)
    return op


class OnlyRTWithHistoryBasic(OnlyRTWithHistory, ABC):

    def __init__(self, **kwargs):
        super(OnlyRTWithHistoryBasic, self).__init__(**kwargs)

    def forward(self, lstm_inp,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        return basic_forward(self, lstm_inp, sub_emb, block_emb)


class OnlyAccWithHistoryBasic(OnlyAccWithHistory, ABC):

    def __init__(self, **kwargs):
        super(OnlyAccWithHistoryBasic, self).__init__(**kwargs)

    def forward(self, lstm_inp,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        return basic_forward(self, lstm_inp, sub_emb, block_emb)


# LSTM with Attention

class OnlyRTWithHistoryAndAttentionBasic(OnlyRTWithHistoryAndAttention, ABC):

    def __init__(self, **kwargs):
        super(OnlyRTWithHistoryAndAttentionBasic, self).__init__(**kwargs)

    def forward(self, lstm_inp,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        return basic_forward(self, lstm_inp, sub_emb, block_emb)


class OnlyAccWithHistoryAndAttentionBasic(OnlyAccWithHistoryAndAttention, ABC):

    def __init__(self, **kwargs):
        super(OnlyAccWithHistoryAndAttentionBasic, self).__init__(**kwargs)

    def forward(self, lstm_inp,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        return basic_forward(self, lstm_inp, sub_emb, block_emb)


# MLP without history

def forward_without_hist_mlp(model: WithoutHistoryMLPBase, lstm_inp, sub_emb, block_emb):
    inp = lstm_inp[:, 0, :]
    concatenate_list = [inp]
    if 'sub_embedding' in model.embeddings:
        concatenate_list.append(model.embeddings['sub_embedding'](sub_emb))  # (N, Sb)
    if 'block_embedding' in model.embeddings:
        concatenate_list.append(model.embeddings['block_embedding'](block_emb))  # (N, B)

    op = torch.cat(concatenate_list, dim=1)  # (N, E+Sb+B)
    op = model._forward_internal_layers(op)
    op = model._forward_output_layer(op)
    return op


class OnlyRTWithoutHistoryMLPBasic(OnlyRTWithoutHistoryMLP, ABC):

    def __init__(self, **kwargs):
        super(OnlyRTWithoutHistoryMLPBasic, self).__init__(**kwargs)

    def forward(self, lstm_inp,  # (N, 1, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        return forward_without_hist_mlp(self, lstm_inp, sub_emb, block_emb)


class OnlyAccWithoutHistoryMLPBasic(OnlyAccWithoutHistoryMLP, ABC):

    def __init__(self, **kwargs):
        super(OnlyAccWithoutHistoryMLPBasic, self).__init__(**kwargs)

    def forward(self, lstm_inp,  # (N, 1, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        return forward_without_hist_mlp(self, lstm_inp, sub_emb, block_emb)


# Models for thresholded RT

class OnlyRTWithHistoryThresholdedBasic(OnlyRTWithHistoryThresholded, ABC):

    def __init__(self, **kwargs):
        super(OnlyRTWithHistoryThresholdedBasic, self).__init__(**kwargs)

    def forward(self, lstm_inp,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        return basic_forward(self, lstm_inp, sub_emb, block_emb)
