import pandas
from config import project_dir
from utils_processing import mc_seeds
from utils_data.helper import sigmoid
import plotly.express as px
from utils_processing.metrics import p_val_text, compute_element_bce
from utils_data import sd_types
from utils_data.helper import serial_dependence_measure, entropy, get_actual_trial_type, get_perc_trial_type
from utils_processing.metrics import compute_robust_corr, compute_auroc


def conditioned_entropy(result_dir):
    values_df = pandas.read_pickle(result_dir)
    values_df['att'] = values_df.apply(get_actual_trial_type, axis=1)
    values_df['ptt'] = values_df.apply(get_perc_trial_type, axis=1)

    values_df = values_df[values_df.ptt == 'invalid']

    # Trial Level Uncertainty
    pred_cols = list(map(lambda x: f'acc_pred_{x}', range(len(mc_seeds))))
    values_df['acc_pred'] = values_df[pred_cols].applymap(sigmoid).mean(axis=1)
    pred_cols = list(map(lambda x: f'acc_pred_bs_{x}', range(len(mc_seeds))))
    values_df['acc_pred_bs'] = values_df[pred_cols].applymap(sigmoid).mean(axis=1)
    values_df['acc_pred_bs_ent'] = values_df.acc_pred_bs.apply(entropy)
    ent_cols = []
    for pred_col in pred_cols:
        values_df[pred_col + '_ent'] = values_df[pred_col].apply(sigmoid).apply(entropy)
        ent_cols.append(pred_col + '_ent')
    values_df['aleatoric'] = values_df[ent_cols].mean(axis=1)
    values_df['epistemic'] = values_df['acc_pred_bs_ent'] - values_df['aleatoric']

    values_df['actual_bce'] = compute_element_bce(values_df, 'acc_target', 'acc_pred')
    values_df['shuffled_bce'] = compute_element_bce(values_df, 'acc_target_bs', 'acc_pred_bs')

    # Mean of Metrics Per Split, Per Block, Per Subject, Per Condition
    agg_df = values_df.groupby(['sub_num', 'seed', 'btest']) \
        .agg({'acc_pred_bs_ent': 'mean', 'aleatoric': 'mean', 'epistemic': 'mean', 'actual_bce': 'mean', 'shuffled_bce': 'mean'})
    agg_df['actual_auroc'] = values_df.groupby(['sub_num', 'seed', 'btest']).apply(
        lambda df: compute_auroc(df, 'acc_target', 'acc_pred'))
    agg_df['shuffled_auroc'] = values_df.groupby(['sub_num', 'seed', 'btest']).apply(
        lambda df: compute_auroc(df, 'acc_target_bs', 'acc_pred_bs'))
    values_df = agg_df.reset_index()

    # Median Per Subject
    values_df = values_df.groupby(['sub_num']) \
        .agg({'acc_pred_bs_ent': 'mean', 'aleatoric': 'mean', 'epistemic': 'mean',
              'actual_bce': 'mean', 'shuffled_bce': 'mean',
              'actual_auroc': 'mean', 'shuffled_auroc': 'mean'}) \
        .reset_index()

    for sdmetric, direction in [
        ('bce', 'less'),
        ('auroc', 'greater'),
    ]:
        for sd_type, name in sd_types.items():
            values_df[sd_type] = serial_dependence_measure(sd_type, values_df[f'actual_{sdmetric}'], values_df[f'shuffled_{sdmetric}'])
            for metric, mname in [
                ('acc_pred_bs_ent', 'Entr(Shuffled)'),
                ('aleatoric', 'Aleatoric(Shuffled)'),
                ('epistemic', 'Epistemic(Shuffled)'),
            ]:
                if metric == 'epistemic':
                    direc = direction
                else:
                    direc = 'less' if direction == 'greater' else 'greater'

                symbol = '>' if direc == 'greater' else '<'
                rcorr = compute_robust_corr(values_df, sd_type, metric, direc)
                fig = px.scatter(values_df, x=metric, y=sd_type,
                                 labels={metric: mname + ' Uncertainty in Acc', sd_type: name + f' {sdmetric}'})
                fig.update_layout(title_text=f'SRM Task - R.Corr = {rcorr["corr"]:.3f} | {p_val_text(rcorr["pval"])} for R.Corr {symbol} 0')
                fig.update_layout(width=800, height=800, font_size=15)
                fig.show()


if __name__ == '__main__':
    res_dir = project_dir + 'basic_v2/results/sans_block_v3_bs=64_maxep=100_acc/'
    conditioned_entropy(res_dir + f'mc-test_values.pkl')
