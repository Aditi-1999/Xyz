from utils_data.msc_eda import get_probed_side_mscs
import pandas
from scipy.stats import sem, permutation_test
from utils_processing.metrics import compute_element_mse, compute_element_bce, p_val_text
from config import project_dir
from utils_data import sd_types
from utils_data.helper import serial_dependence_measure, sigmoid, inverse_sigmoid, probed_side, true_reward, \
    perc_reward, population_difference
import plotly.graph_objects as go

bs = 64
num_epochs = 100


def common(values_df, deg_window, start, end):
    values_df['side_probed'] = values_df['side_probed'].apply(probed_side)
    values_df['reward_vr_fx'] = values_df['reward_vr_fx'].apply(true_reward)
    values_df['perc_vr_gt_fx'] = values_df['perc_vr_gt_fx'].apply(perc_reward)

    # MSc Information
    msc_df = get_probed_side_mscs(deg_window, start, end)
    msc_df['msc_in_probed'] = msc_df.probed_phis.apply(lambda x: '>0' if len(x) > 0 else '0')
    msc_df.set_index(['sub_num', 'gain_block_num', 'trial_num'], inplace=True)
    msc_in_probed = msc_df.msc_in_probed.to_dict()

    # Merge the two
    values_df['msc_in_probed'] = values_df.apply(
        lambda row: msc_in_probed.get((row.sub_num, row.gain_block_num, row.trial_num - 1)), axis=1)
    merged_df = values_df.dropna(subset=['msc_in_probed'], axis=0).copy()
    return merged_df


def make_figure(merged_df, split_col, y_p):
    fig = go.Figure()

    msc_level = merged_df.groupby([split_col, 'msc_in_probed']).sd_measure \
        .agg(mean='mean', sem=sem).reset_index()
    for msc_count in ['0', '>0']:
        trial_type_df = msc_level[msc_level.msc_in_probed == msc_count].copy()
        fig.add_trace(go.Bar(
            x=trial_type_df[split_col], y=trial_type_df['mean'], name=msc_count,
            error_y=dict(array=trial_type_df['sem'], symmetric=True),
            text=trial_type_df['mean'].round(3), textposition='outside'
        ))

    for loc, val in enumerate(merged_df[split_col].unique()):
        probed_df = merged_df[merged_df[split_col] == val].copy()
        result = permutation_test(
            [
                probed_df[probed_df.msc_in_probed == '0'].sd_measure,
                probed_df[probed_df.msc_in_probed == '>0'].sd_measure,
            ],
            statistic=population_difference,
            permutation_type='independent',
            n_resamples=9999,
            alternative='two-sided',
            random_state=0,
        )
        pval_text = p_val_text(result.pvalue)
        fig.add_annotation(x=loc, y=y_p, showarrow=False,
                           text=f'"0" != ">0"<br>{pval_text}; Permutation Test')
    return fig


def trial_msc_sd_rt(prefix, split_col, x_title, deg_window, start, end, sd_type):
    # Training Results
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_rt'
    result_folder = project_dir + f'basic/results/{folder_name}/'
    values_df: pandas.DataFrame = pandas.read_pickle(result_folder + f'overall-values.pkl')
    values_df = values_df.groupby(['sub_num', 'gain_block_num', 'trial_num']) \
        .agg({'rt_target': 'mean', 'rt_pred': 'mean',
              'rt_target_bs': 'mean', 'rt_pred_bs': 'mean',
              'side_probed': 'mean', 'reward_vr_fx': 'mean', 'perc_vr_gt_fx': 'mean'}) \
        .reset_index()  # Averaging values across seeds - as an estimate of the actual values
    values_df['actual_mse'] = compute_element_mse(values_df, 'rt_target', 'rt_pred')
    values_df['shuffled_mse'] = compute_element_mse(values_df, 'rt_target_bs', 'rt_pred_bs')
    merged_df = common(values_df, deg_window, start, end)

    # Trial-level SD measure
    merged_df['sd_measure'] = serial_dependence_measure(sd_type, merged_df['actual_mse'], merged_df['shuffled_mse'])

    # Make figure
    fig = make_figure(merged_df, split_col, -0.055)

    title = f'RT; Num(MScs) within {2 * deg_window}° window around<br>Probed Side [{start}, {end}] ms ' \
            f'after Probe Onset in the Past Trial'
    fig.update_layout(font_size=12, title=dict(text=title, xanchor='center', x=0.5),
                      legend=dict(yanchor='top', y=0.99, xanchor='left', x=0.01, title_text='Num(Mscs)'),
                      width=800, height=600)
    fig.update_xaxes(title_text=x_title)
    sd_text = sd_types[sd_type]
    fig.update_yaxes(title_text=f'{sd_text} - MSE in Current Trial')
    fig.show()


def trial_msc_sd_acc(prefix, split_col, x_title, deg_window, start, end, sd_type):
    # Training Results
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_acc'
    result_folder = project_dir + f'basic/results/{folder_name}/'
    values_df: pandas.DataFrame = pandas.read_pickle(result_folder + f'overall-values.pkl')
    values_df['acc_pred'] = sigmoid(values_df.acc_pred)  # Converting to probabilities for averaging
    values_df['acc_pred_bs'] = sigmoid(values_df.acc_pred_bs)
    values_df = values_df.groupby(['sub_num', 'gain_block_num', 'trial_num']) \
        .agg({'acc_target': 'mean', 'acc_pred': 'mean',
              'acc_target_bs': 'mean', 'acc_pred_bs': 'mean',
              'side_probed': 'mean', 'reward_vr_fx': 'mean', 'perc_vr_gt_fx': 'mean'}) \
        .reset_index()  # Averaging values across seeds - as an estimate of the actual values
    values_df['acc_pred'] = inverse_sigmoid(values_df.acc_pred)  # Converting to logits for loss calculations
    values_df['acc_pred_bs'] = inverse_sigmoid(values_df.acc_pred_bs)
    values_df['actual_bce'] = compute_element_bce(values_df, 'acc_target', 'acc_pred')
    values_df['shuffled_bce'] = compute_element_bce(values_df, 'acc_target_bs', 'acc_pred_bs')
    merged_df = common(values_df, deg_window, start, end)

    # Trial-level SD measure
    merged_df['sd_measure'] = serial_dependence_measure(sd_type, merged_df['actual_bce'], merged_df['shuffled_bce'])

    # Make figure
    fig = make_figure(merged_df, split_col, -0.023)

    title = f'Acc; Num(MScs) within {2 * deg_window}° window around<br>Probed Side [{start}, {end}] ms ' \
            f'after Probe Onset in the Past Trial'
    fig.update_layout(font_size=12, title=dict(text=title, xanchor='center', x=0.5),
                      legend=dict(yanchor='top', y=0.99, xanchor='left', x=0.01, title_text='Num(Mscs)'),
                      width=800, height=600)
    fig.update_xaxes(title_text=x_title)
    sd_text = sd_types[sd_type]
    fig.update_yaxes(title_text=f'{sd_text} - BCE in Current Trial')
    fig.show()


if __name__ == '__main__':
    en = 450
    for col, name in [
        ('side_probed', 'Probed Side'),
        ('reward_vr_fx', 'True Reward'),
        ('perc_vr_gt_fx', 'Perceived Reward'),
    ]:
        for degw in [30, 45, 60, 90]:
            for strt in [250, 100]:
                for sdtyp in [
                    'difference',
                    'modulated_shuffled',
                    'modulated_actual',
                    'modulated_sum'
                ]:
                    trial_msc_sd_rt('sans_block', col, name, degw, strt, en, sdtyp)
                    trial_msc_sd_acc('sans_block', col, name, degw, strt, en, sdtyp)
