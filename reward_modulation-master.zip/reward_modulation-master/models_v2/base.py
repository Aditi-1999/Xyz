from pytorch_lightning import LightningModule
from abc import ABC, abstractmethod
from torch.optim import Adam
from torch.optim.lr_scheduler import ExponentialLR
import torch
from typing import Optional
from models import choose_function, choose_init_function, choose_dropout_function
from models_custom.rnns.lstm import variational_lstm
from models_custom.rnns.gru import variational_gru
from torch.nn import ModuleList, ModuleDict, Linear, Embedding, init, MSELoss, BCEWithLogitsLoss
from pytorch_lightning.utilities.seed import seed_everything
from torch import Tensor


class RawModel(LightningModule, ABC):

    def __init__(self):
        super(RawModel, self).__init__()

    @abstractmethod
    def forward(self, recurrent_inp,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        ...

    @abstractmethod
    def _common_step(self, batch, btype):
        ...

    def training_step(self, batch):
        loss = self._common_step(batch, 'train')
        return loss

    def validation_step(self, batch, batch_idx):
        self._common_step(batch, 'val')

    @abstractmethod
    def predict_step(self, batch, batch_idx):
        ...


class BaseModel(RawModel, ABC):

    def __init__(self):
        super(BaseModel, self).__init__()

    def _forward_internal_layers(self, op: torch.Tensor) -> torch.Tensor:
        for layer in self.internal_layers:
            op = layer(op)
            if self.activation_func:
                op = self.activation_func(op)
            op = self.dropout(op)  # Apply dropout if internal layer
        return op

    def _forward_output_layer(self, op: torch.Tensor) -> torch.Tensor:
        op = self.output_layer(op)
        if self.output_activation_func:
            op = self.output_activation_func(op)
        return op

    def configure_optimizers(self):
        optimizer = Adam(self.parameters(), lr=self.lr, weight_decay=self.l2weight)
        if self.exp_lr:
            lr_scheduler = ExponentialLR(optimizer, gamma=0.98)
            return {
                'optimizer': optimizer,
                'lr_scheduler': {
                    'scheduler': lr_scheduler,
                    'interval': 'epoch',
                    'frequency': 1,
                    'name': 'exp_lr',
                },
            }
        else:
            return optimizer


class WithLSTMHistoryBase(BaseModel, ABC):

    def __init__(self,
                 rnn_input_size: int, rnn_hidden_size: int, rnn_layers: int, rnn_bidirectional: bool,
                 hidden_sizes: list[int], activation_func: Optional[str],
                 output_size: int, output_activation_func: Optional[str],
                 num_subjects: int, num_blocks: int,
                 sub_emb_dim: int, block_emb_dim: int,
                 l2weight: float, dropout: float,
                 lr: float, exp_lr: bool, mseed: int,
                 ):
        super(WithLSTMHistoryBase, self).__init__()

        assert activation_func in [None, 'relu', 'gelu']
        assert 0 <= dropout < 1
        self.activation_func = choose_function(activation_func)
        self.output_activation_func = choose_function(output_activation_func)

        self.lr = lr
        self.exp_lr = exp_lr
        self.l2weight = l2weight

        self.subject_history = variational_lstm(input_size=rnn_input_size, hidden_size=rnn_hidden_size,
                                                num_layers=rnn_layers, bidirectional=rnn_bidirectional, dropout=dropout)

        self.dropout = choose_dropout_function(self.activation_func)(dropout)

        self.internal_layers = ModuleList([])  # Last cell output of LSTM
        for i in range(1, len(hidden_sizes)):
            self.internal_layers.append(
                Linear(in_features=hidden_sizes[i - 1], out_features=hidden_sizes[i], dtype=torch.double))
        self.output_layer = Linear(in_features=hidden_sizes[-1], out_features=output_size, dtype=torch.double)

        self.embeddings = ModuleDict()
        if num_subjects > 2 and sub_emb_dim > 1:
            self.embeddings.update({'sub_embedding': Embedding(num_embeddings=num_subjects,
                                                               embedding_dim=sub_emb_dim)})
        if num_blocks > 2 and block_emb_dim > 1:
            self.embeddings.update({'block_embedding': Embedding(num_embeddings=num_blocks,
                                                                 embedding_dim=block_emb_dim)})

        self.initialise(mseed)

        self.double()

    def initialise(self, model_seed):
        # Initialisations
        seed_everything(model_seed)
        init_function = choose_init_function(self.activation_func)
        for layer in self.internal_layers:
            init_function(layer.weight)
            init.zeros_(layer.bias)
        output_init_function = choose_init_function(self.output_activation_func)
        output_init_function(self.output_layer.weight)
        init.zeros_(self.output_layer.bias)

        rnn_hidden_size = self.subject_history.hidden_size
        for name, param in self.subject_history.named_parameters():
            if 'weight_ih' in name:
                init.xavier_uniform_(param)
            elif 'weight_hh' in name:
                init.orthogonal_(param)
            elif 'bias_ih' in name:
                init.zeros_(param)
            elif 'bias_hh' in name:
                param.data = torch.tensor([0] * rnn_hidden_size + [1] * rnn_hidden_size + [0] * rnn_hidden_size * 2,
                                          dtype=torch.double)

        for embedding in self.embeddings.values():
            init.uniform_(embedding.weight, -0.05, 0.05)

    @staticmethod
    def _get_lstm_output(lstm, lstm_inp: Tensor):  # lstm_inp is of shape (N, T, E)
        """Take the last layer output"""
        _, (h, _) = lstm(lstm_inp)  # h is of shape (D*num_layers, N, H)
        if lstm.bidirectional:
            last_layer_outputs = h[-2:, :, :]
            batch_size = last_layer_outputs.shape[1]
            return last_layer_outputs.transpose(0, 1).reshape(batch_size, -1)  # (N, 2*H)
        else:
            return h[-1, :, :]  # (N, H)

    def forward(self, lstm_inp,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        concatenate_list = [
            self._get_lstm_output(self.subject_history, lstm_inp),  # (N, D*H)
        ]
        if 'sub_embedding' in self.embeddings:
            concatenate_list.append(self.embeddings['sub_embedding'](sub_emb))  # (N, Sb)
        if 'block_embedding' in self.embeddings:
            concatenate_list.append(self.embeddings['block_embedding'](block_emb))  # (N, B)
        op = torch.cat(concatenate_list, dim=1)  # (N, D*H+Sb+B)
        op = self._forward_internal_layers(op)
        op = self._forward_output_layer(op)
        return op


class WithGRUHistoryBase(BaseModel, ABC):

    def __init__(self,
                 rnn_input_size: int, rnn_hidden_size: int, rnn_layers: int, rnn_bidirectional: bool,
                 hidden_sizes: list[int], activation_func: Optional[str],
                 output_size: int, output_activation_func: Optional[str],
                 num_subjects: int, num_blocks: int,
                 sub_emb_dim: int, block_emb_dim: int,
                 l2weight: float, dropout: float,
                 lr: float, exp_lr: bool, mseed: int,
                 ):
        super(WithGRUHistoryBase, self).__init__()

        assert activation_func in [None, 'relu', 'gelu']
        assert 0 <= dropout < 1
        self.activation_func = choose_function(activation_func)
        self.output_activation_func = choose_function(output_activation_func)

        self.lr = lr
        self.exp_lr = exp_lr
        self.l2weight = l2weight

        self.subject_history = variational_gru(input_size=rnn_input_size, hidden_size=rnn_hidden_size,
                                               num_layers=rnn_layers, bidirectional=rnn_bidirectional, dropout=dropout)

        self.dropout = choose_dropout_function(self.activation_func)(dropout)

        self.internal_layers = ModuleList([])  # Last cell output of GRU
        for i in range(1, len(hidden_sizes)):
            self.internal_layers.append(
                Linear(in_features=hidden_sizes[i - 1], out_features=hidden_sizes[i], dtype=torch.double))
        self.output_layer = Linear(in_features=hidden_sizes[-1], out_features=output_size, dtype=torch.double)

        self.embeddings = ModuleDict()
        if num_subjects > 2 and sub_emb_dim > 1:
            self.embeddings.update({'sub_embedding': Embedding(num_embeddings=num_subjects,
                                                               embedding_dim=sub_emb_dim)})
        if num_blocks > 2 and block_emb_dim > 1:
            self.embeddings.update({'block_embedding': Embedding(num_embeddings=num_blocks,
                                                                 embedding_dim=block_emb_dim)})

        self.initialise(mseed)

        self.double()

    def initialise(self, model_seed):
        # Initialisations
        seed_everything(model_seed)
        init_function = choose_init_function(self.activation_func)
        for layer in self.internal_layers:
            init_function(layer.weight)
            init.zeros_(layer.bias)
        output_init_function = choose_init_function(self.output_activation_func)
        output_init_function(self.output_layer.weight)
        init.zeros_(self.output_layer.bias)

        for name, param in self.subject_history.named_parameters():
            if 'weight_ih' in name:
                init.xavier_uniform_(param)
            elif 'weight_hh' in name:
                init.orthogonal_(param)
            elif 'bias_ih' in name:
                init.zeros_(param)
            elif 'bias_hh' in name:
                init.zeros_(param)

        for embedding in self.embeddings.values():
            init.uniform_(embedding.weight, -0.05, 0.05)

    @staticmethod
    def _get_gru_output(gru, gru_inp: Tensor):  # gru_inp is of shape (N, T, E)
        """Take the last layer output"""
        _, h = gru(gru_inp)  # h is of shape (D*num_layers, N, H)
        if gru.bidirectional:
            last_layer_outputs = h[-2:, :, :]
            batch_size = last_layer_outputs.shape[1]
            return last_layer_outputs.transpose(0, 1).reshape(batch_size, -1)  # (N, 2*H)
        else:
            return h[-1, :, :]  # (N, H)

    def forward(self, gru_inp,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        concatenate_list = [
            self._get_gru_output(self.subject_history, gru_inp),  # (N, D*H)
        ]
        if 'sub_embedding' in self.embeddings:
            concatenate_list.append(self.embeddings['sub_embedding'](sub_emb))  # (N, Sb)
        if 'block_embedding' in self.embeddings:
            concatenate_list.append(self.embeddings['block_embedding'](block_emb))  # (N, B)
        op = torch.cat(concatenate_list, dim=1)  # (N, D*H+Sb+B)
        op = self._forward_internal_layers(op)
        op = self._forward_output_layer(op)
        return op


class WithoutHistoryBase(BaseModel, ABC):

    def __init__(self,
                 hidden_sizes: list[int], activation_func: Optional[str],
                 output_size: int, output_activation_func: Optional[str],
                 num_subjects: int, num_blocks: int,
                 sub_emb_dim: int, block_emb_dim: int,
                 l2weight: float, dropout: float,
                 lr: float, exp_lr: bool, mseed: int,
                 ):
        super(WithoutHistoryBase, self).__init__()

        assert activation_func in [None, 'relu', 'gelu']
        assert 0 <= dropout < 1
        self.activation_func = choose_function(activation_func)
        self.output_activation_func = choose_function(output_activation_func)

        self.lr = lr
        self.exp_lr = exp_lr
        self.l2weight = l2weight

        self.dropout = choose_dropout_function(self.activation_func)(dropout)

        self.internal_layers = ModuleList([])
        for i in range(1, len(hidden_sizes)):
            self.internal_layers.append(
                Linear(in_features=hidden_sizes[i - 1], out_features=hidden_sizes[i], dtype=torch.double))
        self.output_layer = Linear(in_features=hidden_sizes[-1], out_features=output_size, dtype=torch.double)

        self.embeddings = ModuleDict()
        if num_subjects > 2 and sub_emb_dim > 1:
            self.embeddings.update({'sub_embedding': Embedding(num_embeddings=num_subjects,
                                                               embedding_dim=sub_emb_dim)})
        if num_blocks > 2 and block_emb_dim > 1:
            self.embeddings.update({'block_embedding': Embedding(num_embeddings=num_blocks,
                                                                 embedding_dim=block_emb_dim)})

        self.initialise(mseed)

        self.double()

    def initialise(self, model_seed):
        # Initialisations
        seed_everything(model_seed)
        init_function = choose_init_function(self.activation_func)
        for layer in self.internal_layers:
            init_function(layer.weight)
            init.zeros_(layer.bias)
        output_init_function = choose_init_function(self.output_activation_func)
        output_init_function(self.output_layer.weight)
        init.zeros_(self.output_layer.bias)

        for embedding in self.embeddings.values():
            init.uniform_(embedding.weight, -0.05, 0.05)

    def forward(self, lstm_inp,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        assert lstm_inp.shape[1] == 1
        inp = lstm_inp[:, 0, :]
        concatenate_list = [
            inp + torch.normal(mean=0., std=0.1, size=inp.shape, device=self.device)  # (N, E)
        ]
        a = 0
        if 'sub_embedding' in self.embeddings:
            concatenate_list.append(self.embeddings['sub_embedding'](sub_emb))  # (N, Sb)
        if 'block_embedding' in self.embeddings:
            concatenate_list.append(self.embeddings['block_embedding'](block_emb))  # (N, B)
        op = torch.cat(concatenate_list, dim=1)  # (N, E+Sb+B)
        op = self._forward_internal_layers(op)
        op = self._forward_output_layer(op)
        return op


class BaseRTModel(RawModel, ABC):

    metric = 'rt'
    output_size = 1
    output_activation_func = None

    def _common_step(self, batch, btype):
        not_training = btype != 'train'
        recurrent_inp, sub_emb, block_emb, rt_target = batch
        rt_pred = self(recurrent_inp, sub_emb, block_emb)
        loss_rt = MSELoss()(rt_pred, rt_target)
        self.log(f'{btype}/loss', loss_rt, on_step=False, on_epoch=True, prog_bar=True, logger=True,
                 reduce_fx=torch.mean, sync_dist=not_training)
        return loss_rt

    def predict_step(self, batch, batch_idx):
        recurrent_inp, sub_emb, block_emb, rt_target = batch
        rt_pred = self(recurrent_inp, sub_emb, block_emb)
        return rt_target.cpu().numpy(), rt_pred.cpu().numpy()


class BaseAccModel(RawModel, ABC):

    metric = 'accuracy'
    output_size = 1
    output_activation_func = None

    def _common_step(self, batch, btype):
        not_training = btype != 'train'
        recurrent_inp, sub_emb, block_emb, acc_target = batch
        acc_pred = self(recurrent_inp, sub_emb, block_emb)
        loss_acc = BCEWithLogitsLoss()(acc_pred, acc_target)
        self.log(f'{btype}/loss', loss_acc, on_step=False, on_epoch=True, prog_bar=True, logger=True,
                 reduce_fx=torch.mean, sync_dist=not_training)
        return loss_acc

    def predict_step(self, batch, batch_idx):
        recurrent_inp, sub_emb, block_emb, acc_target = batch
        acc_pred = self(recurrent_inp, sub_emb, block_emb)
        return acc_target.cpu().numpy(), acc_pred.cpu().numpy()
