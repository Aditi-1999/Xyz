from uncertainty.models.base import BaseMVEHistoryModel, BaseMVERTModel
from utils_processing.common_proc import prespast_columns
import torch


class MVEHistoryRT(BaseMVEHistoryModel, BaseMVERTModel):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(MVEHistoryRT, self).__init__(rnn_input_size=E, **kwargs)
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'rt_prespast'


if __name__ == '__main__':
    from torchinfo import summary
    from uncertainty.models import MVETrainingPhase
    params = dict(rnn_hidden_size=2, rnn_layers=2, rnn_bidirectional=True,
                  mean_hidden_sizes=[9, 3, ], logvar_hidden_sizes=[9, 3, ],
                  activation_func='gelu',
                  mean_l2weight=0.01, logvar_l2weight=0.02,
                  num_subjects=24, num_blocks=0,
                  sub_emb_dim=5, block_emb_dim=0,
                  lr=0.01, exp_lr=True, mseed=0, phase=MVETrainingPhase.MeanAndVar)

    model1 = MVEHistoryRT(**params)
    model2 = MVEHistoryRT(**params)

    lstm_inp = torch.randn(10, 4, 8, dtype=torch.double)
    sub_emb = torch.randint(low=0, high=24, size=(10, ))
    block_emb = torch.randint(low=0, high=6, size=(10, ))

    m1, v1 = model1(lstm_inp, sub_emb, block_emb)
    m2, v2 = model2(lstm_inp, sub_emb, block_emb)

    assert torch.equal(m1, m2)
    assert torch.equal(v1, v2)

    summary_kwargs = dict(dtypes=[torch.double, torch.int, torch.int], depth=4, col_names=['input_size', 'output_size', 'num_params'],
                          row_settings=['depth', 'var_names'], verbose=0, device=torch.device('cpu'))
    print(summary(model=model1, input_data=[lstm_inp, sub_emb, block_emb], **summary_kwargs))

    a = 0
