import torch
from config import use_gpu
from typing import Optional


def get_trainer_gpu_kwargs(gpu_num: list[int]) -> dict:
    if use_gpu:
        assert len(gpu_num) == 1, 'Multi-GPU with DDP fails for WandbLogger'
        trainer_kwargs = dict(accelerator="gpu", devices=gpu_num)
    else:
        trainer_kwargs = dict()
    return trainer_kwargs


def get_device(gpu_num: list[int]) -> Optional[torch.device]:
    if use_gpu:
        assert len(gpu_num) == 1, 'Currently only support for one device'
        return torch.device('cuda', gpu_num[0])
    else:
        return None
