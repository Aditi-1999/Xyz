from utils_training.training_acc import execute_trial, learn_transform_acc, get_data_for_trial, make_predictions
from utils_processing.common_proc import read_data_and_preprocess, get_train_test_split_df
from utils_data import num_gain_blocks
from pytorch_lightning import Trainer
import torch.nn.functional as f
from utils_processing import seeds
from subj_wise import optuna_storage, acc_subjects
from config import project_dir
import os
import optuna
import pandas
import gc


def execute_study(model_class, seed: int, b: int, bs: int, num_epochs: int, prefix: str, gpu_num: list[int]):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_acc'
    res_dir = project_dir + 'subj_wise/results/' + folder_name + '/'
    os.makedirs(res_dir, exist_ok=True)

    btest = b
    bval = (b + 1) % num_gain_blocks
    train_test_split_df = get_train_test_split_df(seed)
    storage = optuna.storages.get_storage(optuna_storage)

    # Hyperparameter configs to try
    for T in [1, 3, 10, 15]:

        # Get Data - depends on T
        proc_df = read_data_and_preprocess(T, return_raw=False)

        for sub_num in acc_subjects:

            study_name = f'{folder_name}_{sub_num}_{seed}_{b}'
            study = optuna.create_study(direction='minimize', study_name=study_name,
                                        storage=storage, load_if_exists=True)

            sub_df = proc_df.query(f'sub_num == {sub_num}').copy()

            train_df, val_df, _ = learn_transform_acc(btest, bval, sub_df, train_test_split_df)
            train_dataloader, val_dataloader = get_data_for_trial(bs, model_class, train_df, val_df)

            for rnn_layers in [1, 2]:
                for rnn_bidirectional in [False, True]:
                    for rnn_hidden_size in [4, 8, 16]:
                        rnn_output_size = (2 if rnn_bidirectional else 1) * rnn_hidden_size
                        first_layer = rnn_output_size
                        hid_configs = [
                            [first_layer, ],
                            [first_layer, first_layer // 2],
                        ]
                        for hidden_sizes in hid_configs:
                            num_hidden_sizes = len(hidden_sizes)
                            if num_hidden_sizes == 1:
                                act_funcs = [None]
                            else:
                                act_funcs = [f.relu, f.gelu]

                            for activation_func in act_funcs:
                                model_kwargs = dict(rnn_hidden_size=rnn_hidden_size, rnn_layers=rnn_layers, rnn_bidirectional=rnn_bidirectional,
                                                    rnn_initial='none', rnn_init_hidden_sizes=[], rnn_init_activation_func=None, rnn_init_output_activation_func=None,
                                                    hidden_sizes=hidden_sizes, activation_func=activation_func,
                                                    num_subjects=0, num_blocks=0, sub_emb_dim=0, block_emb_dim=0,
                                                    lr=0.01, cycle_lr=False, cycle_config={}, exp_lr=True,
                                                    l2reg=False, l2weight=0,  # https://stats.stackexchange.com/a/275088/217039
                                                    dropout=0, mseed=0)

                                # Run one config
                                trial = execute_trial(model_class, model_kwargs, train_dataloader, val_dataloader, seed, btest, bval, bs,
                                                      num_epochs, False, res_dir, study_name,
                                                      {'T': T, 'prefix': prefix, 'num_hidden_sizes': num_hidden_sizes, 'sub_num': sub_num},
                                                      gpu_num)
                                study.add_trial(trial)
                                gc.collect()


def run_lr_test(model_class):
    import plotly.graph_objects as go
    bs = 32
    T = 10

    proc_df = read_data_and_preprocess(T, return_raw=False)
    model_kwargs = dict(rnn_hidden_size=10, rnn_layers=1, rnn_bidirectional=False,
                        rnn_initial='none', rnn_init_hidden_sizes=[], rnn_init_activation_func=None,
                        rnn_init_output_activation_func=None,
                        hidden_sizes=[13, 10, ], activation_func=f.relu,
                        num_subjects=0, num_blocks=0, sub_emb_dim=0, block_emb_dim=0,
                        lr=0.1, cycle_lr=False, cycle_config={}, exp_lr=False,
                        l2reg=False, l2weight=0, dropout=0, mseed=0)

    suggestions = []

    fig = go.Figure()

    for seed in seeds[:3]:
        for b in range(num_gain_blocks):
            btest = b
            bval = (b + 1) % num_gain_blocks

            for sub_num in acc_subjects:

                model = model_class(**model_kwargs)

                sub_df = proc_df.query(f'sub_num == {sub_num}').copy()

                train_test_split_df = get_train_test_split_df(seed)
                train_df, val_df, _ = learn_transform_acc(btest, bval, sub_df, train_test_split_df)
                train_dataloader, val_dataloader = get_data_for_trial(bs, model_class, train_df, val_df)

                trainer = Trainer(deterministic=True)
                lr_finder = trainer.tuner.lr_find(model, train_dataloaders=train_dataloader, val_dataloaders=val_dataloader,
                                                  num_training=100)
                suggestion = lr_finder.suggestion()
                lrs, losses, idx = lr_finder.results['lr'], lr_finder.results['loss'], lr_finder._optimal_idx

                fig.add_trace(go.Scatter(x=lrs, y=losses, name=f'sub_num={sub_num}, seed={seed}, b={b}'))
                fig.add_trace(go.Scatter(x=[suggestion], y=[losses[idx]], showlegend=False,
                                         marker=dict(size=15, symbol='cross', color='black')))
                suggestions.append(dict(sub_num=sub_num, seed=seed, b=b, lr=suggestion))

    suggestion_df = pandas.DataFrame(suggestions)
    print(suggestion_df)

    fig.update_layout(xaxis_title='Learning Rate', yaxis_title='Loss', title='Response LR Plot')
    fig.update_xaxes(type='log')
    fig.show()

    a = 0


if __name__ == '__main__':
    from models.final import OnlyAccWithHistoryBasicFinal
    run_lr_test(OnlyAccWithHistoryBasicFinal)


def summarise_acc_filtered(model_class, bs: int, num_epochs: int, prefix: str, gpu_num: list[int], trial_filter):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_acc'
    res_dir = project_dir + 'subj_wise/results/' + folder_name + '/'
    values_df = []
    proc_df_dict = {}

    storage = optuna.storages.get_storage(optuna_storage)

    for seed in seeds[:3]:
        for b in range(num_gain_blocks):
            btest = b
            bval = (b + 1) % num_gain_blocks

            for sub_num in acc_subjects:

                study_name = f'{folder_name}_{sub_num}_{seed}_{b}'
                study = optuna.load_study(study_name=study_name, storage=storage)
                df = study.trials_dataframe()
                fil_df = df[df.user_attrs_config.apply(trial_filter)]
                best_config = fil_df.sort_values('value').iloc[0].user_attrs_config
                trial_id = best_config['trial_id']

                best_model_path = res_dir + f'{study_name}/{trial_id}/best.ckpt'
                best_model = model_class.load_from_checkpoint(best_model_path)

                T = best_config['T']
                if T in proc_df_dict:
                    proc_df = proc_df_dict[T]
                else:
                    proc_df = read_data_and_preprocess(T, return_raw=False)
                    proc_df_dict[T] = proc_df

                sub_df = proc_df.query(f'sub_num == {sub_num}').copy()
                value_df = make_predictions(best_model, seed, btest, bval, bs, num_epochs, sub_df, gpu_num)
                values_df.append(value_df)

    all_values_df = pandas.concat(values_df, ignore_index=True)
    return all_values_df


def summarise_acc(model_class, bs: int, num_epochs: int, prefix: str, gpu_num: list[int]):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_acc'
    res_dir = project_dir + 'subj_wise/results/' + folder_name + '/'

    def trial_filter(d):
        return True

    all_values_df = summarise_acc_filtered(model_class, bs, num_epochs, prefix, gpu_num, trial_filter)
    all_values_df.to_pickle(res_dir + f'overall-values.pkl')


def summarise_acc_T(model_class, bs: int, num_epochs: int, prefix: str, gpu_num: list[int]):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_acc'
    res_dir = project_dir + 'subj_wise/results/' + folder_name + '/'

    for T in [1, 3, 10, 15]:

        def trial_filter(d):
            return d['T'] == T

        all_values_df = summarise_acc_filtered(model_class, bs, num_epochs, prefix, gpu_num, trial_filter)
        all_values_df.to_pickle(res_dir + f'T={T}-values.pkl')
