# Use SEs learnt on RT
from basic_v2.hp_checks import hp_checks
from config import project_dir
from basic_v2.analyses.se_analysis import best_block_hp
from tqdm import tqdm
from utils_processing import mc_seeds
import numpy
import pandas
from utils_data import num_subjects
from models_v2.final import OnlyRTWithLSTMHistoryFinalV2
import plotly.express as px
from utils_processing.metrics import compute_robust_corr, distances, cosine_dist, compute_mse, p_val_text
from utils_data import sd_types
from utils_data.helper import serial_dependence_measure

cols = list(map(lambda x: f'x{x}', range(1, 6)))
dist_names = {
    'l2_median': 'L2 Distance from Median', 'l2_mean': 'L2 Distance from Mean',
    'l1_median': 'L1 Distance from Median', 'l1_mean': 'L1 Distance from Mean',
    'cos_median': 'Cosine Distance from Median', 'cos_mean': 'Cosine Distance from Mean',
}
sub_nums = list(range(num_subjects))


def get_actual_shuffled_mse(folder, suffix=''):
    values_df = pandas.read_pickle(project_dir + folder + f'mc-test_values{suffix}.pkl')
    pred_cols = list(map(lambda x: f'rt_pred_{x}', range(len(mc_seeds))))
    values_df['rt_pred'] = values_df[pred_cols].mean(axis=1)
    pred_cols = list(map(lambda x: f'rt_pred_bs_{x}', range(len(mc_seeds))))
    values_df['rt_pred_bs'] = values_df[pred_cols].mean(axis=1)
    actual_mses = values_df.groupby(['sub_num', 'seed', 'btest']).apply(lambda df: compute_mse(df, 'rt_target', 'rt_pred'))
    actual_mses.name = 'metric'
    actual_mses = actual_mses.reset_index()
    actual_mses = actual_mses.groupby(['sub_num']).metric.mean()
    shuffled_mses = values_df.groupby(['sub_num', 'seed', 'btest']).apply(lambda df: compute_mse(df, 'rt_target_bs', 'rt_pred_bs'))
    shuffled_mses.name = 'metric'
    shuffled_mses = shuffled_mses.reset_index()
    shuffled_mses = shuffled_mses.groupby(['sub_num']).metric.mean()
    return actual_mses, shuffled_mses


def correlate_dist_delta(model_class, trials):
    subj_dfs = []
    for idx, row in tqdm(trials.iterrows()):
        trial = row.to_dict()
        actual_model = model_class.load_from_checkpoint(trial['folder_path'] + 'best.ckpt')
        subj_embed = numpy.array(actual_model.embeddings['sub_embedding'].weight.tolist())
        df_subj = pandas.DataFrame(subj_embed, columns=cols)
        df_subj['subject'] = sub_nums
        df_subj['seed'] = trial['seed']
        df_subj['btest'] = trial['btest']

        median = numpy.median(subj_embed, axis=0)
        mean = numpy.mean(subj_embed, axis=0)
        df_subj['l2_median'] = distances(subj_embed, median, 2)
        df_subj['cos_median'] = cosine_dist(subj_embed, median)
        df_subj['l2_mean'] = distances(subj_embed, mean, 2)
        df_subj['cos_mean'] = cosine_dist(subj_embed, mean)

        subj_dfs.append(df_subj)

    subj_df = pandas.concat(subj_dfs, ignore_index=True)
    subj_distances = subj_df.groupby(['subject']).mean()
    with_actual_mses, with_shuffled_mses = get_actual_shuffled_mse(f'basic_v2/results/sans_block_v3_bs=64_maxep=100_rt/')
    sans_actual_mses, sans_shuffled_mses = get_actual_shuffled_mse(f'basic_v2/results/sans_se_bs=64_maxep=100_rt/')

    for sd_type, sd_text in list(sd_types.items()):
        with_sd_measure = serial_dependence_measure(sd_type, with_actual_mses, with_shuffled_mses)
        sans_sd_measure = serial_dependence_measure(sd_type, sans_actual_mses, sans_shuffled_mses)

        for delta, dname in [
            (with_sd_measure - sans_sd_measure, 'WithSESD - SansSESD: MSE'),
            # ((with_sd_measure - sans_sd_measure) / with_sd_measure, '(WithSESD - SansSESD) / WithSESD: MSE'),
            # ((with_sd_measure - sans_sd_measure) / with_sd_measure, '(WithSESD - SansSESD) / SansSESD: MSE'),
            # ((with_sd_measure - sans_sd_measure) / (with_sd_measure + sans_sd_measure), '(WithSESD - SansSESD) / (WithSESD + SansSESD): MSE'),
        ]:
            for col in [
                'l2_median',
                # 'l2_mean',
                # 'cos_median',
                # 'cos_mean'
            ]:
                subj_distances[dname] = delta
                rcorr = compute_robust_corr(subj_distances, col, dname)
                fig = px.scatter(subj_distances, x=col, y=dname,
                                 title=f'SRM - RT Embeddings: R.Corr = {rcorr["corr"]:.3f}; {p_val_text(rcorr["pval"])}'
                                       f'<br>{sd_text}',
                                 height=600, width=600)
                fig.update_xaxes(title_text=dist_names[col])
                fig.update_yaxes(title_text=dname)
                fig.show()


def correlate_dist_deltaembed(model_class, trials):
    subj_dfs = []
    for idx, row in tqdm(trials.iterrows()):
        trial = row.to_dict()
        actual_model = model_class.load_from_checkpoint(trial['folder_path'] + 'best.ckpt')
        subj_embed = numpy.array(actual_model.embeddings['sub_embedding'].weight.tolist())
        df_subj = pandas.DataFrame(subj_embed, columns=cols)
        df_subj['subject'] = sub_nums
        df_subj['seed'] = trial['seed']
        df_subj['btest'] = trial['btest']

        median = numpy.median(subj_embed, axis=0)
        mean = numpy.mean(subj_embed, axis=0)
        df_subj['l2_median'] = distances(subj_embed, median, 2)
        df_subj['cos_median'] = cosine_dist(subj_embed, median)
        df_subj['l2_mean'] = distances(subj_embed, mean, 2)
        df_subj['cos_mean'] = cosine_dist(subj_embed, mean)

        subj_dfs.append(df_subj)

    subj_df = pandas.concat(subj_dfs, ignore_index=True)
    subj_distances = subj_df.groupby(['subject']).mean()
    with_actual_mses, with_shuffled_mses = get_actual_shuffled_mse(f'basic_v2/results/sans_block_v3_bs=64_maxep=100_rt/')
    embe_actual_mses, embe_shuffled_mses = get_actual_shuffled_mse(f'basic_v2/results/sans_block_v3_bs=64_maxep=100_rt/', suffix='-median')

    for sd_type, sd_text in list(sd_types.items()):
        with_sd_measure = serial_dependence_measure(sd_type, with_actual_mses, with_shuffled_mses)
        embe_sd_measure = serial_dependence_measure(sd_type, embe_actual_mses, embe_shuffled_mses)

        for delta, dname in [
            (with_sd_measure - embe_sd_measure, 'WithSESD - EmbeSESD: MSE'),
            # ((with_sd_measure - embe_sd_measure) / with_sd_measure, '(WithSESD - EmbeSESD) / WithSESD: MSE'),
            # ((with_sd_measure - embe_sd_measure) / with_sd_measure, '(WithSESD - EmbeSESD) / EmbeSESD: MSE'),
            # ((with_sd_measure - embe_sd_measure) / (with_sd_measure + embe_sd_measure), '(WithSESD - EmbeSESD) / (WithSESD + EmbeSESD): MSE'),
        ]:
            for col in [
                'l2_median',
                # 'l2_mean',
                # 'cos_median',
                # 'cos_mean'
            ]:
                subj_distances[dname] = delta
                rcorr = compute_robust_corr(subj_distances, col, dname)
                fig = px.scatter(subj_distances, x=col, y=dname,
                                 title=f'SRM - RT Embeddings: R.Corr = {rcorr["corr"]:.3f}; {p_val_text(rcorr["pval"])}'
                                       f'<br>{sd_text}',
                                 height=600, width=600)
                fig.update_xaxes(title_text=dist_names[col])
                fig.update_yaxes(title_text=dname)
                fig.show()


if __name__ == '__main__':
    hp_keys = ['T', 'rnn_layers', 'rnn_bidirectional', 'rnn_hidden_size', 'hidden_sizes', 'dropout']
    results = hp_checks([0, 10, 20], 'sans_block_v3', 64, 100, lambda d: True, 'rt', hp_keys)
    hp_results = best_block_hp(results)
    correlate_dist_delta(OnlyRTWithLSTMHistoryFinalV2, hp_results)
    # correlate_dist_deltaembed(OnlyRTWithHistoryFinalV2, hp_results)
