# Use SEs learnt on Acc
from utils_processing.common_proc import read_data_and_preprocess, get_train_test_split_df
from basic_v2.hp_checks import hp_checks
from config import project_dir
from basic_v2.analyses.se_analysis import best_block_hp
from utils_training.training_acc import learn_transform_acc
from tqdm import tqdm
from utils_processing import mc_seeds
import numpy
import pandas
from utils_data import num_subjects, num_gain_blocks
from models_v2.final import OnlyAccWithLSTMHistoryFinalV2
import plotly.express as px
from utils_processing.metrics import compute_robust_corr, distances, cosine_dist, compute_bce, p_val_text
from utils_data.helper import sigmoid, inverse_sigmoid
import plotly.graph_objs as go
from basic_v2.analyses.se_analysis.common import make_se_predictions

cols = list(map(lambda x: f'x{x}', range(1, 6)))
dist_names = {
    'l2_median': 'L2 Distance from Median', 'l1_median': 'L1 Distance from Median',
    'cos_median': 'Cosine Distance from Median', 'l2_mean': 'L2 Distance from Mean', 'l1_mean': 'L1 Distance from Mean',
    'cos_mean': 'Cosine Distance from Mean'
}


def predict_mean_acc(model_class, trials, proc_dfs):
    subj_dfs = []
    for idx, row in tqdm(trials.iterrows()):
        trial = row.to_dict()
        T = trial['T']
        seed = trial['seed']
        btest = trial['btest']
        bval = (btest + 1) % num_gain_blocks

        train_test_split_df = get_train_test_split_df(seed)
        _, _, test_df = learn_transform_acc(btest, bval, proc_dfs[T], train_test_split_df)
        acc = test_df.groupby('sub_num').accuracy.mean()

        actual_model = model_class.load_from_checkpoint(trial['folder_path'] + 'best.ckpt')
        subj_embed = numpy.array(actual_model.embeddings['sub_embedding'].weight.tolist())
        df_subj = pandas.DataFrame(subj_embed, columns=cols)

        df_subj['subject'] = list(range(num_subjects))
        df_subj['target'] = acc.loc[df_subj.subject].tolist()
        assert (df_subj['target'] < 1).all()
        df_subj['target'] = df_subj.target.apply(inverse_sigmoid)
        df_subj = make_se_predictions(df_subj)
        df_subj['target'] = df_subj.target.apply(sigmoid)
        df_subj['pred'] = df_subj.pred.apply(sigmoid)
        subj_dfs.append(df_subj)

    subj_df = pandas.concat(subj_dfs, ignore_index=True)
    avg_data = subj_df.groupby('subject').agg({'target': 'mean', 'pred': 'mean'}).reset_index()
    corr = compute_robust_corr(avg_data, 'target', 'pred', 'greater')
    fig = px.scatter(avg_data, x='target', y='pred',
                     labels={'target': 'Observed Mean Accuracy', 'pred': 'Predicted Mean Accuracy from Embeddings'},
                     trendline='ols', trendline_color_override='black',
                     title=f'SRM - R.Corr = {corr["corr"]:.3f}; {p_val_text(corr["pval"])} for R.Corr > 0',
                     height=600, width=600)
    minv = min(avg_data.target.min(), avg_data.pred.min())
    maxv = max(avg_data.target.max(), avg_data.pred.max())
    fig.add_trace(go.Scatter(x=[minv, maxv], y=[minv, maxv], mode='lines', line=dict(color='red'), showlegend=False))
    fig.show()


def correlate_mean_sd(model_class, trials):
    subj_dfs = []
    for idx, row in tqdm(trials.iterrows()):
        trial = row.to_dict()
        actual_model = model_class.load_from_checkpoint(trial['folder_path'] + 'best.ckpt')
        subj_embed = numpy.array(actual_model.embeddings['sub_embedding'].weight.tolist())
        df_subj = pandas.DataFrame(subj_embed, columns=cols)
        df_subj['subject'] = list(map(str, range(num_subjects)))
        df_subj['seed'] = trial['seed']
        df_subj['btest'] = trial['btest']

        median = numpy.median(subj_embed, axis=0)
        mean = numpy.mean(subj_embed, axis=0)
        df_subj['l2_median'] = distances(subj_embed, median, 2)
        df_subj['cos_median'] = cosine_dist(subj_embed, median)
        df_subj['l2_mean'] = distances(subj_embed, mean, 2)
        df_subj['cos_mean'] = cosine_dist(subj_embed, mean)

        subj_dfs.append(df_subj)

    subj_df = pandas.concat(subj_dfs, ignore_index=True)
    subj_distances = subj_df.groupby(['subject']).mean()

    result_folder = project_dir + f'basic_v2/results/sans_block_v3_bs=64_maxep=100_acc/'
    values_df = pandas.read_pickle(result_folder + f'mc-test_values.pkl')
    values_df['sub_emb'] = values_df.sub_emb.apply(int).apply(str)
    values_df['block_emb'] = values_df.block_emb.apply(int).apply(str)
    pred_cols = list(map(lambda x: f'acc_pred_{x}', range(len(mc_seeds))))
    values_df['acc_pred'] = values_df[pred_cols].applymap(sigmoid).mean(axis=1).apply(inverse_sigmoid)
    pred_cols = list(map(lambda x: f'acc_pred_bs_{x}', range(len(mc_seeds))))
    values_df['acc_pred_bs'] = values_df[pred_cols].applymap(sigmoid).mean(axis=1).apply(inverse_sigmoid)
    actual_bces = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(
        lambda df: compute_bce(df, 'acc_target', 'acc_pred'))
    actual_bces.name = 'metric'
    actual_bces = actual_bces.reset_index()
    actual_bces = actual_bces.groupby(['sub_emb']).metric.mean()
    shuffled_bces = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(
        lambda df: compute_bce(df, 'acc_target_bs', 'acc_pred_bs'))
    shuffled_bces.name = 'metric'
    shuffled_bces = shuffled_bces.reset_index()
    shuffled_bces = shuffled_bces.groupby(['sub_emb']).metric.mean()

    sd_measure, measure = (actual_bces - shuffled_bces) / shuffled_bces, '(Actual BCE - Shuffled BCE) / Shuffled BCE'
    subj_distances['sd'] = sd_measure
    subj_distances_final = subj_distances.reset_index()
    for col, name in [
        ('l2_median', 'L2 Distance from Median'),
        ('l2_mean', 'L2 Distance from Mean'),
        ('cos_median', 'Cosine Distance from Median'),
        ('cos_mean', 'Cosine Distance from Mean'),
    ]:
        rcorr = compute_robust_corr(subj_distances_final, col, 'sd')
        fig = px.scatter(subj_distances_final, x=col, y='sd',
                         # color='subject', color_discrete_sequence=colours,
                         title=f'Acc Embeddings: R.Corr = {rcorr["corr"]:.3f}; {p_val_text(rcorr["pval"])}',
                         height=600, width=600)
        fig.update_xaxes(title_text=name)
        fig.update_yaxes(title_text=measure)
        fig.show()


if __name__ == '__main__':
    hp_keys = ['T', 'rnn_layers', 'rnn_bidirectional', 'rnn_hidden_size', 'hidden_sizes', 'dropout']
    results = hp_checks([0, 10, 20], 'sans_block_v3', 64, 100, lambda d: True, 'acc', hp_keys)
    hp_results = best_block_hp(results)
    pdfs = {}
    for T in hp_results['T'].unique():
        pdfs[T] = read_data_and_preprocess(T, return_raw=False, exp_type='gain_d')
    predict_mean_acc(OnlyAccWithLSTMHistoryFinalV2, hp_results, pdfs)
    # correlate_mean_sd(OnlyAccWithHistoryFinalV2, hp_results)
