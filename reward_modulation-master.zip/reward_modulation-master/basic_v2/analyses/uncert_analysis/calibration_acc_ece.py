import pandas
from config import project_dir
from utils_processing import mc_seeds
import plotly.express as px
from utils_data.helper import sigmoid
from numpy import abs
import numpy
import plotly.graph_objs as go

pred_cols = list(map(lambda x: f'acc_pred_{x}', range(len(mc_seeds))))


def get_mc_values(result_dir):
    mc_values = pandas.read_pickle(result_dir)
    mc_values[pred_cols] = mc_values[pred_cols].applymap(sigmoid)
    mc_values['acc_pred'] = mc_values[pred_cols].mean(axis=1)
    return mc_values


def calibration_plot(mc_values, n_bins, stage):
    bin_boundaries = numpy.linspace(0, 1, n_bins + 1)
    bin_lowers, bin_uppers = bin_boundaries[:-1], bin_boundaries[1:]

    bins_data = []
    for bin_lower, bin_upper in zip(bin_lowers, bin_uppers):
        in_bin = (bin_lower <= mc_values.acc_pred) & (mc_values.acc_pred <= bin_upper)
        if in_bin.sum() == 0:  # if no elements in that bin
            continue

        bin_values = mc_values[in_bin]
        proportion = in_bin.mean()
        predicted_prob = bin_values.acc_pred.mean()
        empirical_prob = bin_values.acc_target.mean()
        ece = proportion * abs(predicted_prob - empirical_prob)
        bins_data.append({'emp': empirical_prob, 'pred': predicted_prob, 'ece': ece})

    bin_df = pandas.DataFrame(bins_data)
    ece = bin_df.ece.sum()
    fig = px.scatter(bin_df, x='pred', y='emp',
                     labels={'pred': 'Predicted Probability', 'emp': 'Empirical Probability'})
    fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1], mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_layout(title=dict(text=f'{stage} - ECE = {ece:.3f}', xanchor='center', x=0.5), height=600, width=600,
                      legend=dict(yanchor='top', y=0.1, xanchor='left', x=0.85))
    fig.show()


def calibrate(mc_val_values, mc_test_values, n_bins):
    calibration_plot(mc_val_values, n_bins, stage='Validation Set - Pre-Calibration')
    calibration_plot(mc_test_values, n_bins, stage='Test Set - Pre-Calibration')
    # Seems calibrated already


if __name__ == '__main__':
    res_dir = project_dir + 'basic_v2/results/reencode_bs=64_maxep=100_acc/'
    mc_test_values_df = get_mc_values(res_dir + f'mc-test_values.pkl')
    mc_val_values_df = get_mc_values(res_dir + f'mc-val_values.pkl')
    calibrate(mc_val_values_df, mc_test_values_df, 50)
