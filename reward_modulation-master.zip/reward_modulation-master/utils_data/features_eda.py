import pandas
import plotly.express as px
from config import data_dir
from subj_wise import rt_subjects
from scipy.stats import boxcox
from utils_data.eda import get_sub_config_box
from utils_data import colours
from scipy.stats import ks_2samp
import plotly.graph_objs as go
from scipy.stats import sem, wilcoxon


def rt_patterns(feature):
    data_df: pandas.DataFrame = pandas.read_json(data_dir + 'data.json', orient='columns')
    data_df['sub_num'] = data_df.sub_num.apply(int)
    data_df.dropna(subset=['response_time'], inplace=True)
    # data_df = data_df.query(f'sub_num in {rt_subjects}').copy()

    sub_config_box = data_df.groupby('sub_num').response_time.apply(get_sub_config_box).to_dict()
    data_df['rt'] = data_df.apply(
        lambda row: (boxcox(row['response_time'], sub_config_box[(row['sub_num'], 'lambda')]).item() - sub_config_box[
            (row['sub_num'], 'mean')]) / sub_config_box[(row['sub_num'], 'std')],
        axis=1).tolist()

    fig = px.scatter(data_df, x=feature, y='rt', trendline='ols', title='Observed RT Pattern - Gain Blocks',
                     # facet_col='sub_num', facet_col_wrap=3, category_orders={'sub_num': rt_subjects},
                     labels={'rt': 'Observed RT', 'sub_num': 'Subject ID'})
    fig.data = [t for t in fig.data if t.mode == "lines"]
    fig.update_layout(font_size=15, xaxis_range=[0, 0.8], yaxis_range=[-1, 1])
    fig.show()

    # data_df['sub_num'] = data_df.sub_num.apply(str)
    # fig = px.scatter(data_df, x=feature, y='rt', trendline='ols', title='Observed RT Pattern - Gain Blocks',
    #                  color='sub_num', color_discrete_sequence=colours,
    #                  labels={'rt': 'Observed RT', 'sub_num': 'Subject ID'})
    # fig.data = [t for t in fig.data if t.mode == "lines"]
    # fig.update_traces(showlegend=True)
    # fig.update_layout(font_size=15, xaxis_range=[0, 0.8], yaxis_range=[-1, 1])
    # fig.show()


def rt_patterns_loss(feature):
    data_df: pandas.DataFrame = pandas.read_json(data_dir + 'loss_data.json', orient='columns')
    data_df['sub_num'] = data_df.sub_num.apply(int)
    data_df.dropna(subset=['response_time'], inplace=True)
    # data_df = data_df.query(f'sub_num in {rt_subjects}').copy()

    sub_config_box = data_df.groupby('sub_num').response_time.apply(get_sub_config_box).to_dict()
    data_df['rt'] = data_df.apply(
        lambda row: (boxcox(row['response_time'], sub_config_box[(row['sub_num'], 'lambda')]).item() -
                     sub_config_box[
                         (row['sub_num'], 'mean')]) / sub_config_box[(row['sub_num'], 'std')],
        axis=1).tolist()

    fig = px.scatter(data_df, x=feature, y='rt', trendline='ols', title='Observed RT Pattern - Loss Blocks',
                     # facet_col='sub_num', facet_col_wrap=3, category_orders={'sub_num': rt_subjects},
                     labels={'rt': 'Observed RT', 'sub_num': 'Subject ID'})
    fig.data = [t for t in fig.data if t.mode == "lines"]
    fig.update_layout(font_size=15, xaxis_range=[0, 0.8], yaxis_range=[-1, 1])
    fig.show()

    # data_df['sub_num'] = data_df.sub_num.apply(str)
    # fig = px.scatter(data_df, x=feature, y='rt', trendline='ols', title='Observed RT Pattern - Loss Blocks',
    #                  color='sub_num', color_discrete_sequence=colours,
    #                  labels={'rt': 'Observed RT', 'sub_num': 'Subject ID'})
    # fig.data = [t for t in fig.data if t.mode == "lines"]
    # fig.update_traces(showlegend=True)
    # fig.update_layout(font_size=15, xaxis_range=[0, 0.8], yaxis_range=[-1, 1])
    # fig.show()


def run_ks_test(gdf, feature, col):
    result = ks_2samp(
        data1=gdf[gdf[feature] == 0][col].values,
        data2=gdf[gdf[feature] == 1][col].values,
    )
    # low p -> more evidence for distributions being different
    return result.pvalue


def rt_patterns_change_at_vr():
    data_df: pandas.DataFrame = pandas.read_json(data_dir + 'data.json', orient='columns')
    data_df['sub_num'] = data_df.sub_num.apply(int)
    data_df.dropna(subset=['response_time'], inplace=True)

    sub_config_box = data_df.groupby('sub_num').response_time.apply(get_sub_config_box).to_dict()
    data_df['rt'] = data_df.apply(
        lambda row: (boxcox(row['response_time'], sub_config_box[(row['sub_num'], 'lambda')]).item() - sub_config_box[
            (row['sub_num'], 'mean')]) / sub_config_box[(row['sub_num'], 'std')],
        axis=1).tolist()

    pvals = data_df.groupby('sub_num').apply(lambda gdf: run_ks_test(gdf, 'response', 'rt')).to_dict()
    data_df['response_text'] = data_df.response.apply(lambda c: 'Change' if c == 1 else 'NoChange')

    for rt_subs in [
        list(range(12)),
        list(range(12, 24)),
    ]:
        subs_df = data_df.query(f'sub_num in {rt_subs}').copy()
        fig = px.ecdf(subs_df, x='rt', color='response_text',
                      title='Observed Subject Normalised RT - ECDF',
                      facet_col='sub_num', facet_col_wrap=4,
                      labels={'rt': 'Observed RT', 'response_text': 'Response', 'sub_num': 'Subject ID'},
                      category_orders={'response_text': ['No', 'Yes']})

        for a in fig.layout.annotations:
            sub_id = int(a.text.split("=")[1])
            a.text = a.text + f' | p={pvals[sub_id]:.4f}'

        fig.update_layout(font_size=15)
        fig.update_xaxes(range=[-3, 3])
        fig.update_yaxes(range=[0, 1])
        fig.show()

    p_val = run_ks_test(data_df, 'response', 'rt')
    fig = px.ecdf(data_df, x='rt', color='response_text',
                  title=f'Observed Subject Normalised RT - ECDF | p={p_val:.4f}',
                  labels={'rt': 'Observed RT', 'response_text': 'Response'},
                  category_orders={'response_text': ['No', 'Yes']})
    fig.update_layout(font_size=15)
    fig.update_xaxes(range=[-3, 3])
    fig.update_yaxes(range=[0, 1])
    fig.show()


def rt_response_relation():
    data_df: pandas.DataFrame = pandas.read_json(data_dir + 'data.json', orient='columns')
    data_df['sub_num'] = data_df.sub_num.apply(int)
    data_df.dropna(subset=['response_time'], inplace=True)

    sub_config_box = data_df.groupby('sub_num').response_time.apply(get_sub_config_box).to_dict()
    data_df['rt'] = data_df.apply(
        lambda row: (boxcox(row['response_time'], sub_config_box[(row['sub_num'], 'lambda')]).item() - sub_config_box[
            (row['sub_num'], 'mean')]) / sub_config_box[(row['sub_num'], 'std')],
        axis=1).tolist()

    fig = go.Figure()

    # Responded Change
    respond_change = data_df[data_df.response == 1].copy()
    respond_change = respond_change.groupby('sub_num').rt.mean()

    # Responded NoChange
    respond_nc = data_df[data_df.response == 0].copy()
    respond_nc = respond_nc.groupby('sub_num').rt.mean()

    response_df = pandas.DataFrame({'Change': respond_change, 'NoChange': respond_nc}).reset_index()
    response_df = pandas.melt(response_df, id_vars=['sub_num'], value_vars=['Change', 'NoChange'],
                              var_name='Response', value_name='subj_mean_rt')

    stats = response_df.groupby('Response').subj_mean_rt.agg(mean='mean', sem=sem).reset_index()
    fig.add_trace(go.Bar(x=stats['Response'], y=stats['mean'],
                         error_y=dict(array=stats['sem'], symmetric=True), showlegend=False,
                         text=stats['mean'].round(3), textposition='outside'))

    change = response_df.query('Response == "Change"').sort_values('sub_num').subj_mean_rt.values
    nochange = response_df.query('Response == "NoChange"').sort_values('sub_num').subj_mean_rt.values
    p_val = wilcoxon(x=change, y=nochange, alternative='less')[1]  # test if x < y
    test = 'Wilcoxon'

    if p_val < 0.01:
        text = f'<b>**p = {p_val:.3f}</b>'
    elif p_val < 0.05:
        text = f'<b>*p = {p_val:.3f}</b>'
    else:
        text = f'p = {p_val:.3f}'
    fig.add_annotation(x=0.5, y=0.5, text=f'{text}<br>Change<NoChange<br>{test}', showarrow=False)

    for sub_num in response_df.sub_num.unique():
        sub_resp_df = response_df.query(f'sub_num == {sub_num}')
        fig.add_trace(go.Scatter(x=sub_resp_df['Response'], y=sub_resp_df['subj_mean_rt'], mode='lines+markers',
                                 marker=dict(color='red'), opacity=0.3,
                                 name=f'{sub_num}',
                                 # showlegend=False,
                                 ))

    fig.update_layout(width=400, height=800, font_size=15,
                      title=dict(text='RT in Responding<br>Change v. NoChange', xanchor='center', x=0.5))
    fig.update_xaxes(title_text='Response')
    fig.update_yaxes(title_text='Mean RT')
    fig.update_yaxes(range=[-0.55, 0.6])

    fig.show()


if __name__ == '__main__':
    rt_response_relation()
