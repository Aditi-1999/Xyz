import pandas
from config import project_dir
from utils_processing import mc_seeds, ent_names
from utils_data.helper import sigmoid, entropy, probed_side, get_actual_trial_type, get_perc_trial_type
from scipy.stats import wilcoxon, ttest_rel
from utils_processing.metrics import p_val_text
import plotly.graph_objs as go


def conditioned_entropy(values_df, var, var_name, ent_type,
                        left, right, left_name, right_name,
                        yrange, py):
    values_df.dropna(subset=[var], inplace=True)
    values_df['sub_emb'] = values_df.sub_emb.apply(int).apply(str)

    # Trial Level Uncertainty
    pred_cols = list(map(lambda x: f'acc_pred_{x}', range(len(mc_seeds))))
    values_df['acc_pred'] = values_df[pred_cols].applymap(sigmoid).mean(axis=1)
    values_df['intact_ent'] = values_df.acc_pred.apply(entropy)
    ent_cols = []
    for pred_col in pred_cols:
        values_df[pred_col + '_ent'] = values_df[pred_col].apply(sigmoid).apply(entropy)
        ent_cols.append(pred_col + '_ent')
    values_df['intact_alea'] = values_df[ent_cols].mean(axis=1)
    values_df['intact_epis'] = values_df['intact_ent'] - values_df['intact_alea']

    # Mean of Uncertainty Per Split, Per Block, Per Subject, Per Condition
    values_df = values_df.groupby(['sub_emb', 'seed', 'btest', var]) \
        .agg({f'intact_{ent_type}': 'mean'}) \
        .reset_index()

    # Median Per Subject, Per Condition
    values_df = values_df.groupby(['sub_emb', var]) \
        .agg({f'intact_{ent_type}': 'mean'}) \
        .reset_index()

    # Calculate Metric
    values_df['measure'] = values_df[f'intact_{ent_type}']

    cond = values_df.copy()
    con0 = cond[cond[var] == left]
    con1 = cond[cond[var] == right]

    fig = go.Figure()
    fig.add_trace(go.Bar(x=[left_name, right_name], y=[con0.measure.mean(), con1.measure.mean()], showlegend=False))

    pt_p_val = ttest_rel(a=con0.measure, b=con1.measure, alternative='two-sided')[1]  # test if a != b
    w_p_val = wilcoxon(x=con0.measure, y=con1.measure, alternative='two-sided')[1]  # test if x != y
    fig.add_annotation(x=0.5, y=py, showarrow=False,
                       text=f'{left_name} != {right_name}<br>{p_val_text(pt_p_val)}; Paired-t<br>{p_val_text(w_p_val)}; Wilcoxon')

    for sub_emb in cond.sub_emb.unique():
        sub0 = con0.query(f'sub_emb == "{sub_emb}"')
        sub1 = con1.query(f'sub_emb == "{sub_emb}"')
        fig.add_trace(go.Scatter(x=[left_name, right_name], y=[sub0.measure.iloc[0], sub1.measure.iloc[0]],
                                 mode='lines+markers', marker=dict(color='red'), opacity=0.3,
                                 name=f'{sub_emb}',  # showlegend=False,
                                 ))

    fig.update_layout(width=400, height=800, font_size=15)
    fig.update_xaxes(title_text=var_name)
    fig.update_yaxes(title_text=f'{ent_names[ent_type]} (Intact Predicted Acc)')
    fig.update_yaxes(range=yrange)

    fig.show()


if __name__ == '__main__':
    res_dir = project_dir + f'basic_v2/results/reencode_bs=64_maxep=100_acc/'
    values = pandas.read_pickle(res_dir + f'mc-test_values.pkl')
    values['att'] = values.apply(get_actual_trial_type, axis=1)
    values['ptt'] = values.apply(get_perc_trial_type, axis=1)
    values['side_probed'] = values['side_probed'].apply(probed_side)

    variable, variable_name = 'ptt', 'Perceived Attention'
    conditioned_entropy(values.copy(), var=variable, var_name=variable_name, ent_type='alea',
                        left='invalid', right='valid', left_name='Invalid', right_name='Valid',
                        yrange=[0.45, 0.75], py=0.7)
