import numpy
import pandas
from config import project_dir
from utils_processing import mc_seeds
import plotly.graph_objs as go
from basic_v2.final_analyses import plot_subj_values, get_ttest_wilcoxon_text
from utils_data import sd_types
from utils_data.helper import serial_dependence_measure


def conditioned_variance(result_dir, sd_type):
    values_df = pandas.read_pickle(result_dir)

    # Trial Level Uncertainty
    pred_cols = list(map(lambda x: f'rt_pred_{x}', range(len(mc_seeds))))
    values_df['rt_pred_var'] = values_df[pred_cols].var(axis=1, ddof=1)
    pred_cols = list(map(lambda x: f'rt_pred_bs_{x}', range(len(mc_seeds))))
    values_df['rt_pred_bs_var'] = values_df[pred_cols].var(axis=1, ddof=1)

    # Mean of Uncertainty Per Split, Per Block, Per Subject, Per Condition
    values_df = values_df.groupby(['sub_num', 'seed', 'btest']) \
        .agg({'rt_pred_var': 'mean', 'rt_pred_bs_var': 'mean'}) \
        .reset_index()

    # Median Per Subject, Per Condition
    values_df = values_df.groupby(['sub_num']) \
        .agg({'rt_pred_var': 'mean', 'rt_pred_bs_var': 'mean'})

    # Calculate Metric
    sd_measure = serial_dependence_measure(sd_type, values_df.rt_pred_var, values_df.rt_pred_bs_var)

    fig = go.Figure()
    plot_subj_values(fig, sd_measure, 'x')
    test_text = get_ttest_wilcoxon_text(sd_measure, numpy.zeros_like(sd_measure), 'greater')
    fig.add_annotation(x=0.5, y=0.2, showarrow=False, text=f'{sd_types[sd_type]} - Var > 0<br>{test_text}')
    fig.update_layout(width=400, height=800, font_size=15)
    fig.update_yaxes(title_text=f'{sd_types[sd_type]} - Var')
    fig.show()


if __name__ == '__main__':
    res_dir = project_dir + 'basic_v2/results/sans_block_v3_bs=64_maxep=100_rt/'
    for sd_type in sd_types.keys():
        conditioned_variance(res_dir + f'mc-test_values.pkl', sd_type)
