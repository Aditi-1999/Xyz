import pandas
import plotly.graph_objs as go
from config import project_dir
from utils_processing import mc_seeds, ent_names
from scipy.stats import sem, wilcoxon, ttest_rel
from utils_data.helper import sigmoid, inverse_sigmoid, entropy
from utils_data.helper import get_actual_trial_type, get_perc_trial_type
from utils_processing.metrics import compute_auroc, compute_bce, p_val_text


def compare_aurocs(values_df, title):
    values_df['sub_emb'] = values_df.sub_emb.apply(int).apply(str)
    values_df['block_emb'] = values_df.block_emb.apply(int).apply(str)

    fig = go.Figure()

    # Intact History Predictions
    intact_aurocs = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_auroc(df, 'acc_target', 'acc_pred'))
    intact_aurocs.name = 'metric'
    intact_aurocs = intact_aurocs.reset_index()
    intact_aurocs = intact_aurocs.groupby(['sub_emb']).metric.mean()

    # Scrambled History Predictions
    scrambled_aurocs = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_auroc(df, 'acc_target_bs', 'acc_pred_bs'))
    scrambled_aurocs.name = 'metric'
    scrambled_aurocs = scrambled_aurocs.reset_index()
    scrambled_aurocs = scrambled_aurocs.groupby(['sub_emb']).metric.mean()

    auroc_df = pandas.DataFrame({'Intact': intact_aurocs, 'Scrambled': scrambled_aurocs}).reset_index()
    auroc_df = pandas.melt(auroc_df, id_vars=['sub_emb'], value_vars=['Intact', 'Scrambled'],
                           var_name='hist_type', value_name='auroc')

    stats_auroc = auroc_df.groupby('hist_type').auroc.agg(mean='mean', sem=sem).reset_index()
    fig.add_trace(go.Bar(x=stats_auroc['hist_type'], y=stats_auroc['mean'],
                         error_y=dict(array=stats_auroc['sem'], symmetric=True), showlegend=False,
                         text=stats_auroc['mean'].round(3), textposition='outside'))

    intact = auroc_df.query('hist_type == "Intact"').sort_values('sub_emb').auroc.values
    scrambled = auroc_df.query('hist_type == "Scrambled"').sort_values('sub_emb').auroc.values
    pt_p_val = ttest_rel(a=intact, b=scrambled, alternative='greater')[1]  # test if a > b
    w_p_val = wilcoxon(x=intact, y=scrambled, alternative='greater')[1]  # test if x > y
    fig.add_annotation(x=0.5, y=0.95, showarrow=False,
                       text=f'Intact > Scrambled<br>{p_val_text(pt_p_val)}; Paired-t<br>{p_val_text(w_p_val)}; Wilcoxon')

    for sub_emb in auroc_df.sub_emb.unique():
        sub_auroc_df = auroc_df.query(f'sub_emb == "{sub_emb}"')
        fig.add_trace(go.Scatter(x=sub_auroc_df['hist_type'], y=sub_auroc_df['auroc'], mode='lines+markers',
                                 marker=dict(color='red'), opacity=0.3,
                                 name=f'{sub_emb}',
                                 # showlegend=False,
                                 ))

    fig.add_hline(y=1, line_color='red')
    fig.add_hline(y=0.5, line_color='red', line_dash='dash')

    fig.update_layout(width=400, height=800, font_size=15, title=dict(text=title, xanchor='center', x=0.5))
    fig.update_xaxes(title_text='History Type')
    fig.update_yaxes(title_text='AUROC (Predicted Acc, Observed Acc)')
    fig.update_yaxes(range=[0, 1.1])

    fig.show()


def compare_bces(values_df, title):
    values_df['sub_emb'] = values_df.sub_emb.apply(int).apply(str)
    values_df['block_emb'] = values_df.block_emb.apply(int).apply(str)

    fig = go.Figure()

    # Intact History Predictions
    intact_bces = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_bce(df, 'acc_target', 'acc_pred'))
    intact_bces.name = 'metric'
    intact_bces = intact_bces.reset_index()
    intact_bces = intact_bces.groupby(['sub_emb']).metric.mean()

    # Scrambled History Predictions
    scrambled_bces = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_bce(df, 'acc_target_bs', 'acc_pred_bs'))
    scrambled_bces.name = 'metric'
    scrambled_bces = scrambled_bces.reset_index()
    scrambled_bces = scrambled_bces.groupby(['sub_emb']).metric.mean()

    bce_df = pandas.DataFrame({'Intact': intact_bces, 'Scrambled': scrambled_bces}).reset_index()
    bce_df = pandas.melt(bce_df, id_vars=['sub_emb'], value_vars=['Intact', 'Scrambled'],
                         var_name='hist_type', value_name='bce')

    stats_bce = bce_df.groupby('hist_type').bce.agg(mean='mean', sem=sem).reset_index()
    fig.add_trace(go.Bar(x=stats_bce['hist_type'], y=stats_bce['mean'],
                         error_y=dict(array=stats_bce['sem'], symmetric=True), showlegend=False,
                         text=stats_bce['mean'].round(3), textposition='outside'))

    intact = bce_df.query('hist_type == "Intact"').sort_values('sub_emb').bce.values
    scrambled = bce_df.query('hist_type == "Scrambled"').sort_values('sub_emb').bce.values
    pt_p_val = ttest_rel(a=intact, b=scrambled, alternative='less')[1]  # test if a < b
    w_p_val = wilcoxon(x=intact, y=scrambled, alternative='less')[1]  # test if x < y
    fig.add_annotation(x=0.5, y=0.8, showarrow=False,
                       text=f'Intact < Scrambled<br>{p_val_text(pt_p_val)}; Paired-t<br>{p_val_text(w_p_val)}; Wilcoxon')

    for sub_emb in bce_df.sub_emb.unique():
        sub_bce_df = bce_df.query(f'sub_emb == "{sub_emb}"')
        fig.add_trace(go.Scatter(x=sub_bce_df['hist_type'], y=sub_bce_df['bce'], mode='lines+markers',
                                 marker=dict(color='red'), opacity=0.3,
                                 name=f'{sub_emb}',
                                 # showlegend=False,
                                 ))

    fig.update_layout(width=400, height=800, font_size=15, title=dict(text=title, xanchor='center', x=0.5))
    fig.update_xaxes(title_text='History Type')
    fig.update_yaxes(title_text='BCE (Predicted Acc, Observed Acc)')
    fig.update_yaxes(range=[0, 1])

    fig.show()


def compare_entropies(values_df, title, ent_type):
    values_df['intact_ent'] = values_df.acc_pred.apply(sigmoid).apply(entropy)
    pred_cols = list(map(lambda x: f'acc_pred_{x}', range(len(mc_seeds))))
    ent_cols = []
    for pred_col in pred_cols:
        values_df[pred_col + '_ent'] = values_df[pred_col].apply(sigmoid).apply(entropy)
        ent_cols.append(pred_col + '_ent')
    values_df['intact_alea'] = values_df[ent_cols].mean(axis=1)
    values_df['intact_epis'] = values_df['intact_ent'] - values_df['intact_alea']

    values_df['scrambled_ent'] = values_df.acc_pred_bs.apply(sigmoid).apply(entropy)
    pred_cols = list(map(lambda x: f'acc_pred_bs_{x}', range(len(mc_seeds))))
    ent_cols = []
    for pred_col in pred_cols:
        values_df[pred_col + '_ent'] = values_df[pred_col].apply(sigmoid).apply(entropy)
        ent_cols.append(pred_col + '_ent')
    values_df['scrambled_alea'] = values_df[ent_cols].mean(axis=1)
    values_df['scrambled_epis'] = values_df['scrambled_ent'] - values_df['scrambled_alea']

    values_df['sub_emb'] = values_df.sub_emb.apply(int).apply(str)
    values_df['block_emb'] = values_df.block_emb.apply(int).apply(str)

    fig = go.Figure()

    ent_df = values_df.groupby(['sub_emb', 'seed', 'block_emb']) \
        .agg({f'intact_{ent_type}': 'mean', f'scrambled_{ent_type}': 'mean'}) \
        .reset_index() \
        .groupby(['sub_emb']) \
        .agg({f'intact_{ent_type}': 'mean', f'scrambled_{ent_type}': 'mean'}) \
        .reset_index() \
        .rename(columns={f'intact_{ent_type}': 'Intact', f'scrambled_{ent_type}': 'Scrambled'})
    ent_df = pandas.melt(ent_df, id_vars=['sub_emb'], value_vars=['Intact', 'Scrambled'],
                         var_name='hist_type', value_name='ent')

    stats_ent = ent_df.groupby('hist_type').ent.agg(mean='mean', sem=sem).reset_index()
    fig.add_trace(go.Bar(x=stats_ent['hist_type'], y=stats_ent['mean'],
                         error_y=dict(array=stats_ent['sem'], symmetric=True), showlegend=False,
                         text=stats_ent['mean'].round(3), textposition='outside'))

    intact = ent_df.query('hist_type == "Intact"').sort_values('sub_emb').ent.values
    scrambled = ent_df.query('hist_type == "Scrambled"').sort_values('sub_emb').ent.values
    pt_p_val = ttest_rel(a=intact, b=scrambled, alternative='less')[1]  # test if a < b
    w_p_val = wilcoxon(x=intact, y=scrambled, alternative='less')[1]  # test if x < y
    fig.add_annotation(x=0.5, y=0.75, showarrow=False,
                       text=f'Intact < Scrambled<br>{p_val_text(pt_p_val)}; Paired-t<br>{p_val_text(w_p_val)}; Wilcoxon')

    for sub_emb in ent_df.sub_emb.unique():
        sub_ent_df = ent_df.query(f'sub_emb == "{sub_emb}"')
        fig.add_trace(go.Scatter(x=sub_ent_df['hist_type'], y=sub_ent_df['ent'], mode='lines+markers',
                                 marker=dict(color='red'), opacity=0.3,
                                 name=f'{sub_emb}',
                                 # showlegend=False,
                                 ))

    fig.update_layout(width=400, height=800, font_size=15, title=dict(text=title, xanchor='center', x=0.5))
    fig.update_xaxes(title_text='History Type')
    fig.update_yaxes(title_text=f'{ent_names[ent_type]} (Predicted Acc)')
    fig.update_yaxes(range=[0.4, 0.8])

    fig.show()


if __name__ == '__main__':
    for prefix, model_type in [
        # ('sans_block_v3', f'LSTM+MC<br>0to1Range'),
        # ('probed_invert', f'LSTM+MC<br>Seed = 0<br>Invert Probed'),
        # ('probed_minus_plus', f'LSTM+MC<br>Seed = 0<br>Minus Plus Probed'),
        # ('probed_plus_minus', f'LSTM+MC<br>Seed = 0<br>Plus Minus Probed'),
        ('reencode', f'LSTM+MC<br>-1to1Range'),
        # ('reencodev2', f'LSTM+MC<br>1to-1Range'),
    ]:
        result_folder = project_dir + f'basic_v2/results/{prefix}_bs=64_maxep=100_acc/'
        values = pandas.read_pickle(result_folder + f'mc-test_values.pkl')
        pred_cols = list(map(lambda x: f'acc_pred_{x}', range(len(mc_seeds))))
        values['acc_pred'] = values[pred_cols].applymap(sigmoid).mean(axis=1).apply(inverse_sigmoid)
        pred_cols = list(map(lambda x: f'acc_pred_bs_{x}', range(len(mc_seeds))))
        values['acc_pred_bs'] = values[pred_cols].applymap(sigmoid).mean(axis=1).apply(inverse_sigmoid)
        values['att'] = values.apply(get_actual_trial_type, axis=1)
        values['ptt'] = values.apply(get_perc_trial_type, axis=1)
        compare_aurocs(values, model_type)
        compare_bces(values, model_type)
        compare_entropies(values, model_type, ent_type='alea')
