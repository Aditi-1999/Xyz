from utils_processing.common_proc import prespast_columns
from models_v2.base import WithLSTMHistoryBase, WithGRUHistoryBase, \
    WithoutHistoryBase, \
    BaseRTModel, BaseAccModel

__all__ = [
    'OnlyRTWithLSTMHistoryFinalV2', 'OnlyAccWithLSTMHistoryFinalV2',
    'OnlyRTWithLSTMHistoryFinalV2ReEncode', 'OnlyAccWithLSTMHistoryFinalV2ReEncode',
    'OnlyRTWithLSTMHistoryFinalV2ReEncodeV2', 'OnlyAccWithLSTMHistoryFinalV2ReEncodeV2',
    'OnlyRTWithGRUHistoryFinalV2', 'OnlyAccWithGRUHistoryFinalV2',
    'OnlyRTWithLSTMHistoryFinalV2RemoveHistory', 'OnlyAccWithLSTMHistoryFinalV2RemoveHistory',
    'OnlyAccWithoutHistoryFinalV2',
]


class OnlyRTWithLSTMHistoryFinalV2(WithLSTMHistoryBase, BaseRTModel):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyRTWithLSTMHistoryFinalV2, self).__init__(
            rnn_input_size=E,
            output_size=BaseRTModel.output_size, output_activation_func=BaseRTModel.output_activation_func,
            **kwargs
        )
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'rt_prespast'


class OnlyAccWithLSTMHistoryFinalV2(WithLSTMHistoryBase, BaseAccModel):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyAccWithLSTMHistoryFinalV2, self).__init__(
            rnn_input_size=E,
            output_size=BaseAccModel.output_size, output_activation_func=BaseAccModel.output_activation_func,
            **kwargs
        )
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'acc_prespast'


class OnlyRTWithLSTMHistoryFinalV2ReEncode(WithLSTMHistoryBase, BaseRTModel):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyRTWithLSTMHistoryFinalV2ReEncode, self).__init__(
            rnn_input_size=E,
            output_size=BaseRTModel.output_size, output_activation_func=BaseRTModel.output_activation_func,
            **kwargs
        )
        self.save_hyperparameters()

    def forward(self, lstm_inp,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        lstm_inp = 2 * lstm_inp - 1
        return super().forward(lstm_inp, sub_emb, block_emb)

    @classmethod
    def lstm_variable(cls):
        return 'rt_prespast'


class OnlyAccWithLSTMHistoryFinalV2ReEncode(WithLSTMHistoryBase, BaseAccModel):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyAccWithLSTMHistoryFinalV2ReEncode, self).__init__(
            rnn_input_size=E,
            output_size=BaseAccModel.output_size, output_activation_func=BaseAccModel.output_activation_func,
            **kwargs
        )
        self.save_hyperparameters()

    def forward(self, lstm_inp,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        lstm_inp = 2 * lstm_inp - 1
        return super().forward(lstm_inp, sub_emb, block_emb)

    @classmethod
    def lstm_variable(cls):
        return 'acc_prespast'


class OnlyRTWithLSTMHistoryFinalV2ReEncodeV2(WithLSTMHistoryBase, BaseRTModel):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyRTWithLSTMHistoryFinalV2ReEncodeV2, self).__init__(
            rnn_input_size=E,
            output_size=BaseRTModel.output_size, output_activation_func=BaseRTModel.output_activation_func,
            **kwargs
        )
        self.save_hyperparameters()

    def forward(self, lstm_inp,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        lstm_inp = 1 - 2 * lstm_inp
        return super().forward(lstm_inp, sub_emb, block_emb)

    @classmethod
    def lstm_variable(cls):
        return 'rt_prespast'


class OnlyAccWithLSTMHistoryFinalV2ReEncodeV2(WithLSTMHistoryBase, BaseAccModel):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyAccWithLSTMHistoryFinalV2ReEncodeV2, self).__init__(
            rnn_input_size=E,
            output_size=BaseAccModel.output_size, output_activation_func=BaseAccModel.output_activation_func,
            **kwargs
        )
        self.save_hyperparameters()

    def forward(self, lstm_inp,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        lstm_inp = 1 - 2 * lstm_inp
        return super().forward(lstm_inp, sub_emb, block_emb)

    @classmethod
    def lstm_variable(cls):
        return 'acc_prespast'


class OnlyRTWithGRUHistoryFinalV2(WithGRUHistoryBase, BaseRTModel):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for GRU
        super(OnlyRTWithGRUHistoryFinalV2, self).__init__(
            rnn_input_size=E,
            output_size=BaseRTModel.output_size, output_activation_func=BaseRTModel.output_activation_func,
            **kwargs
        )
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'rt_prespast'


class OnlyAccWithGRUHistoryFinalV2(WithGRUHistoryBase, BaseAccModel):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for GRU
        super(OnlyAccWithGRUHistoryFinalV2, self).__init__(
            rnn_input_size=E,
            output_size=BaseAccModel.output_size, output_activation_func=BaseAccModel.output_activation_func,
            **kwargs
        )
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'acc_prespast'


class OnlyRTWithLSTMHistoryFinalV2RemoveHistory(WithLSTMHistoryBase, BaseRTModel):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyRTWithLSTMHistoryFinalV2RemoveHistory, self).__init__(
            rnn_input_size=E,
            output_size=BaseRTModel.output_size, output_activation_func=BaseRTModel.output_activation_func,
            **kwargs
        )
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'rt_prespast'

    def forward(self, lstm_inp,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        current_input = lstm_inp[:, -1:, :]
        return super(OnlyRTWithLSTMHistoryFinalV2RemoveHistory, self).forward(current_input, sub_emb, block_emb)


class OnlyAccWithLSTMHistoryFinalV2RemoveHistory(WithLSTMHistoryBase, BaseAccModel):

    def __init__(self, **kwargs):
        E = len(prespast_columns[self.lstm_variable()])  # Dimension of vector to be input into each cell for LSTM
        super(OnlyAccWithLSTMHistoryFinalV2RemoveHistory, self).__init__(
            rnn_input_size=E,
            output_size=BaseAccModel.output_size, output_activation_func=BaseAccModel.output_activation_func,
            **kwargs
        )
        self.save_hyperparameters()

    @classmethod
    def lstm_variable(cls):
        return 'acc_prespast'

    def forward(self, lstm_inp,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        current_input = lstm_inp[:, -1:, :]
        return super(OnlyAccWithLSTMHistoryFinalV2RemoveHistory, self).forward(current_input, sub_emb, block_emb)


class OnlyAccWithoutHistoryFinalV2(WithoutHistoryBase, BaseAccModel):

    def __init__(self, **kwargs):
        super(OnlyAccWithoutHistoryFinalV2, self).__init__(
            output_size=BaseAccModel.output_size, output_activation_func=BaseAccModel.output_activation_func,
            **kwargs
        )
        self.save_hyperparameters()

    def forward(self, lstm_inp,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        lstm_inp = 2 * lstm_inp - 1
        return super().forward(lstm_inp, sub_emb, block_emb)

    @classmethod
    def lstm_variable(cls):
        return 'acc_prespast'
