import pandas
from config import project_dir
from utils_processing import mc_seeds
import plotly.express as px
from utils_data.helper import sigmoid


def mean_prediction_equality(result_dir):
    """Is the mean of predictions obtained with dropout on = Prediction obtained with dropout off? Ans: Yes"""
    drop_values = pandas.read_pickle(result_dir + f'dropout-values.pkl')
    mc_values = pandas.read_pickle(result_dir + f'mc-values.pkl')
    assert drop_values['acc_target'].tolist() == mc_values['acc_target'].tolist()

    pred_cols = list(map(lambda x: f'acc_pred_{x}', range(len(mc_seeds))))
    mc_values['acc_pred_ex'] = sigmoid(drop_values['acc_pred'])
    for pred_col in pred_cols:
        mc_values[pred_col] = sigmoid(mc_values[pred_col])

    mc_values['acc_pred_mean'] = mc_values[pred_cols].mean(axis=1)
    fig = px.scatter(mc_values, x='acc_pred_mean', y='acc_pred_ex', trendline='ols',
                     labels={'acc_pred_mean': 'Mean of Predictions', 'acc_pred_ex': 'Prediction with Dropout off'})
    fig.show()


def variance_histogram(result_dir, dropout):
    mc_values: pandas.DataFrame = pandas.read_pickle(result_dir + f'mc-p={dropout}-test_values.pkl')
    pred_cols = list(map(lambda x: f'acc_pred_{x}', range(len(mc_seeds))))
    for pred_col in pred_cols:
        mc_values[pred_col] = sigmoid(mc_values[pred_col])

    mc_values['pred_var'] = mc_values[pred_cols].var(ddof=1, axis=1)
    print(f'Least Variance: {mc_values.pred_var.min()}')

    fig = px.histogram(mc_values, x='pred_var')
    fig.show()


if __name__ == '__main__':
    res_dir = project_dir + 'basic/results/sans_block_bs=64_maxep=100_acc/'
    mean_prediction_equality(res_dir)
    variance_histogram(res_dir, 0.2)
    variance_histogram(res_dir, 0.5)
