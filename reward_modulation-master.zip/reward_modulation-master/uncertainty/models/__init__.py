from enum import Enum


class MVETrainingPhase(Enum):
    OnlyMean = 1
    MeanAndVar = 2
