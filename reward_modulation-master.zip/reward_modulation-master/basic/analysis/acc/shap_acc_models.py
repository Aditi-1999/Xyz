from models.base import WithHistoryBase, WithHistoryAndAttentionBase
from torch.nn import Parameter
import torch


class SHAPForAcc(WithHistoryBase):

    def __init__(self, T, rnn_input_size, rnn_hidden_size, rnn_layers, rnn_bidirectional, rnn_initial, **kwargs):
        super(SHAPForAcc, self).__init__(rnn_input_size=rnn_input_size, rnn_hidden_size=rnn_hidden_size,
                                         rnn_layers=rnn_layers, rnn_bidirectional=rnn_bidirectional, rnn_initial=rnn_initial,
                                         num_subjects=0, num_blocks=0, sub_emb_dim=0, block_emb_dim=0,
                                         output_size=1, output_activation_func=None,
                                         **kwargs)

        if rnn_initial != 'none':
            raise NotImplemented

        self.rnn_input_size = rnn_input_size
        self.rnn_initial = rnn_initial
        self.T = T

        tot_rnn_layers = (2 if rnn_bidirectional else 1) * rnn_layers
        self.h_0 = Parameter(torch.zeros(tot_rnn_layers, rnn_hidden_size), requires_grad=False)
        self.c_0 = Parameter(torch.zeros(tot_rnn_layers, rnn_hidden_size), requires_grad=False)

        self.double()

    def form_lstm_inp(self, lstm_inp_flattened):
        N = lstm_inp_flattened.shape[0]
        return torch.reshape(lstm_inp_flattened, (N, self.rnn_input_size, self.T + 1)).transpose(1, 2)

    def forward(self, lstm_inp_flattened, sub_embedding, block_embedding):
        lstm_inp = self.form_lstm_inp(lstm_inp_flattened)

        N = lstm_inp.shape[0]
        h_0 = self.h_0.unsqueeze(1).repeat(1, N, 1)
        c_0 = self.c_0.unsqueeze(1).repeat(1, N, 1)

        concatenate_list = [
            self._get_lstm_output(self.subject_history, lstm_inp, (h_0, c_0)),
            sub_embedding,
            block_embedding,
        ]
        op = torch.cat(concatenate_list, dim=1)
        op = self._forward_internal_layers(op)
        op = self._forward_output_layer(op)
        return op

    def _common_step(self, batch, btype):
        pass

    def predict_step(self, batch, batch_idx):
        pass

    def load_model(self, actual_model: WithHistoryBase):
        self.double()
        self.subject_history.load_state_dict(actual_model.subject_history.state_dict())
        self.internal_layers.load_state_dict(actual_model.internal_layers.state_dict())
        self.output_layer.load_state_dict(actual_model.output_layer.state_dict())


class SHAPForAccAttn(WithHistoryAndAttentionBase):

    def __init__(self, T, rnn_input_size, rnn_hidden_size, rnn_layers, rnn_bidirectional, rnn_initial, **kwargs):
        super(SHAPForAccAttn, self).__init__(rnn_input_size=rnn_input_size, rnn_hidden_size=rnn_hidden_size,
                                             rnn_layers=rnn_layers, rnn_bidirectional=rnn_bidirectional, rnn_initial=rnn_initial,
                                             num_subjects=0, num_blocks=0, sub_emb_dim=0, block_emb_dim=0,
                                             output_size=1, output_activation_func=None,
                                             **kwargs)

        if rnn_initial != 'none':
            raise NotImplemented

        self.rnn_input_size = rnn_input_size
        self.rnn_initial = rnn_initial
        self.T = T

        tot_rnn_layers = (2 if rnn_bidirectional else 1) * rnn_layers
        self.h_0 = Parameter(torch.zeros(tot_rnn_layers, rnn_hidden_size), requires_grad=False)
        self.c_0 = Parameter(torch.zeros(tot_rnn_layers, rnn_hidden_size), requires_grad=False)

        self.double()

    def form_lstm_inp(self, lstm_inp_flattened):
        N = lstm_inp_flattened.shape[0]
        return torch.reshape(lstm_inp_flattened, (N, self.rnn_input_size, self.T + 1)).transpose(1, 2)

    def forward(self, lstm_inp_flattened, sub_embedding, block_embedding):
        lstm_inp = self.form_lstm_inp(lstm_inp_flattened)

        N = lstm_inp.shape[0]
        h_0 = self.h_0.unsqueeze(1).repeat(1, N, 1)
        c_0 = self.c_0.unsqueeze(1).repeat(1, N, 1)

        concatenate_list = [
            self._get_lstm_output(self.subject_history, lstm_inp, (h_0, c_0)),
            sub_embedding,
            block_embedding,
        ]
        op = torch.cat(concatenate_list, dim=1)
        op = self._forward_internal_layers(op)
        op = self._forward_output_layer(op)
        return op

    def _common_step(self, batch, btype):
        pass

    def predict_step(self, batch, batch_idx):
        pass

    def load_model(self, actual_model: WithHistoryAndAttentionBase):
        self.double()
        self.subject_history.load_state_dict(actual_model.subject_history.state_dict())
        self.internal_layers.load_state_dict(actual_model.internal_layers.state_dict())
        self.output_layer.load_state_dict(actual_model.output_layer.state_dict())
        self.attention_layer.load_state_dict(actual_model.attention_layer.state_dict())


class SHAPForAccSansBlock(WithHistoryBase):

    def __init__(self, T, rnn_input_size, rnn_hidden_size, rnn_layers, rnn_bidirectional, rnn_initial, **kwargs):
        super(SHAPForAccSansBlock, self).__init__(rnn_input_size=rnn_input_size, rnn_hidden_size=rnn_hidden_size,
                                                  rnn_layers=rnn_layers, rnn_bidirectional=rnn_bidirectional, rnn_initial=rnn_initial,
                                                  num_subjects=0, num_blocks=0, sub_emb_dim=0, block_emb_dim=0,
                                                  output_size=1, output_activation_func=None,
                                                  **kwargs)

        if rnn_initial != 'none':
            raise NotImplemented

        self.rnn_input_size = rnn_input_size
        self.rnn_initial = rnn_initial
        self.T = T

        tot_rnn_layers = (2 if rnn_bidirectional else 1) * rnn_layers
        self.h_0 = Parameter(torch.zeros(tot_rnn_layers, rnn_hidden_size), requires_grad=False)
        self.c_0 = Parameter(torch.zeros(tot_rnn_layers, rnn_hidden_size), requires_grad=False)

        self.double()

    def form_lstm_inp(self, lstm_inp_flattened):
        N = lstm_inp_flattened.shape[0]
        return torch.reshape(lstm_inp_flattened, (N, self.rnn_input_size, self.T + 1)).transpose(1, 2)

    def forward(self, lstm_inp_flattened, sub_embedding):
        lstm_inp = self.form_lstm_inp(lstm_inp_flattened)

        N = lstm_inp.shape[0]
        h_0 = self.h_0.unsqueeze(1).repeat(1, N, 1)
        c_0 = self.c_0.unsqueeze(1).repeat(1, N, 1)

        concatenate_list = [
            self._get_lstm_output(self.subject_history, lstm_inp, (h_0, c_0)),
            sub_embedding,
        ]
        op = torch.cat(concatenate_list, dim=1)
        op = self._forward_internal_layers(op)
        op = self._forward_output_layer(op)
        return op

    def _common_step(self, batch, btype):
        pass

    def predict_step(self, batch, batch_idx):
        pass

    def load_model(self, actual_model: WithHistoryBase):
        self.double()
        self.subject_history.load_state_dict(actual_model.subject_history.state_dict())
        self.internal_layers.load_state_dict(actual_model.internal_layers.state_dict())
        self.output_layer.load_state_dict(actual_model.output_layer.state_dict())
