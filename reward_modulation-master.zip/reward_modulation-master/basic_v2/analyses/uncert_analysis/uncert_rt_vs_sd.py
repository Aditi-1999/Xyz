import pandas
from config import project_dir
from utils_processing import mc_seeds
import plotly.express as px
from utils_processing.metrics import p_val_text, compute_element_mse
from utils_data import sd_types
from utils_data.helper import serial_dependence_measure
from utils_processing.metrics import compute_robust_corr


def get_trial_type(row):
    if row['reward_vr_fx'] == 0 and row['side_probed'] == 0:
        # Reward@VR<FX and FX probed
        return 'valid'
    if row['reward_vr_fx'] == 1 and row['side_probed'] == 1:
        # Reward@VR>FX and VR probed
        return 'valid'
    if row['reward_vr_fx'] == 0 and row['side_probed'] == 1:
        # Reward@VR<FX and VR probed
        return 'invalid'
    if row['reward_vr_fx'] == 1 and row['side_probed'] == 0:
        # Reward@VR>FX and FX probed
        return 'invalid'
    return pandas.NA


def conditioned_variance(result_dir):
    values_df = pandas.read_pickle(result_dir)
    values_df['sub_emb'] = values_df.sub_emb.apply(int).apply(str)
    values_df['tt'] = values_df.apply(get_trial_type, axis=1)

    # values_df = values_df[values_df.accuracy == 0]

    # Trial Level Metrics
    pred_cols = list(map(lambda x: f'rt_pred_{x}', range(len(mc_seeds))))
    values_df['rt_pred'] = values_df[pred_cols].mean(axis=1)
    values_df['rt_pred_var'] = values_df[pred_cols].var(axis=1, ddof=1)
    pred_cols = list(map(lambda x: f'rt_pred_bs_{x}', range(len(mc_seeds))))
    values_df['rt_pred_bs'] = values_df[pred_cols].mean(axis=1)
    values_df['actual_mse'] = compute_element_mse(values_df, 'rt_target', 'rt_pred')
    values_df['shuffled_mse'] = compute_element_mse(values_df, 'rt_target_bs', 'rt_pred_bs')

    # Mean of Metric Per Split, Per Block, Per Subject
    agg_df = values_df.groupby(['sub_emb', 'seed', 'btest']) \
        .agg({'rt_pred_var': 'mean', 'actual_mse': 'mean', 'shuffled_mse': 'mean'})
    agg_df['actual_corr'] = values_df.groupby(['sub_emb', 'seed', 'btest']).apply(lambda df: compute_robust_corr(df, 'rt_target', 'rt_pred')['corr'])
    agg_df['shuffled_corr'] = values_df.groupby(['sub_emb', 'seed', 'btest']).apply(lambda df: compute_robust_corr(df, 'rt_target_bs', 'rt_pred_bs')['corr'])
    values_df = agg_df.reset_index()

    # Median Per Subject
    values_df = values_df.groupby(['sub_emb']) \
        .agg({'rt_pred_var': 'median',
              'actual_mse': 'median', 'shuffled_mse': 'median',
              'actual_corr': 'median', 'shuffled_corr': 'median'}) \
        .reset_index()

    for sdmetric, direction in [
        ('mse', 'less'),
        # ('corr', 'greater'),
    ]:
        symbol = '>' if direction == 'greater' else '<'
        for sd_type, name in sd_types.items():
            values_df[sd_type] = serial_dependence_measure(sd_type, values_df[f'actual_{sdmetric}'], values_df[f'shuffled_{sdmetric}'])
            rcorr = compute_robust_corr(values_df, sd_type, 'rt_pred_var', direction)
            fig = px.scatter(values_df, x='rt_pred_var', y=sd_type,
                             labels={'rt_pred_var': 'Var(Actual)', sd_type: name + f' {sdmetric}'})
            fig.update_layout(title_text=f'SRM Task - R.Corr = {rcorr["corr"]:.3f} | {p_val_text(rcorr["pval"])} for R.Corr {symbol} 0')
            fig.update_layout(width=800, height=800, font_size=15)
            fig.show()


if __name__ == '__main__':
    res_dir = project_dir + 'basic_v2/results/sans_block_v3_bs=64_maxep=100_rt/'
    conditioned_variance(res_dir + f'mc-test_values.pkl')
