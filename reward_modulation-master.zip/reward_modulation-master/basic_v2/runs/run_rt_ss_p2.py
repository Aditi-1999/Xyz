import argparse
from basic_v2.process_rt.processor_rt_ss import execute_phase2
from models_v2.final import OnlyRTWithLSTMHistoryFinalV2
from utils_generic import send_message
from utils_data import num_gain_blocks


if __name__ == '__main__':
    bs = 64
    num_epochs = 100
    prefix = 'ss'
    seed = 0

    parser = argparse.ArgumentParser()
    parser.add_argument('--gpu', dest='gpu', type=int, default=0)
    args = parser.parse_args()

    for b in range(num_gain_blocks):
        for subset in range(6):
            execute_phase2(OnlyRTWithLSTMHistoryFinalV2, seed, b, bs, num_epochs, prefix, [args.gpu], 'gain_d', subset)

    send_message(f'RT SS P2 - {prefix} for {args} Finished')
