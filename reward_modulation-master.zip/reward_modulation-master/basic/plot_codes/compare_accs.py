import pandas
import plotly.graph_objs as go
import plotly.express as px
from config import project_dir
from utils_data import colours
from scipy.stats import ttest_rel
from utils_processing.metrics import compute_auroc, compute_bce


def get_actual_metrics(values_df):
    # Actual History Predictions
    actual_aurocs = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_auroc(df, 'acc_target', 'acc_pred'))
    actual_aurocs.name = 'metric'
    actual_aurocs = actual_aurocs.reset_index()
    actual_aurocs = actual_aurocs.groupby(['sub_emb']).metric.mean()

    actual_bces = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_bce(df, 'acc_target', 'acc_pred'))
    actual_bces.name = 'metric'
    actual_bces = actual_bces.reset_index()
    actual_bces = actual_bces.groupby(['sub_emb']).metric.mean()

    return actual_aurocs, actual_bces


def compare_metrics(x_values_df, y_values_df, x_title, y_title):
    x_auroc, x_bce = get_actual_metrics(x_values_df)
    y_auroc, y_bce = get_actual_metrics(y_values_df)

    # AUROC Scatter
    auroc_range = [0.45, 0.90]
    auroc_df = pandas.DataFrame({'x': x_auroc, 'y': y_auroc}).reset_index()
    p_val = ttest_rel(a=auroc_df['y'], b=auroc_df['x'], alternative='greater')[1]  # test if a > b
    auroc_df['sub_emb'] = auroc_df.sub_emb.apply(int).apply(str)
    fig = px.scatter(auroc_df, x='x', y='y', color='sub_emb', color_discrete_sequence=colours,
                     labels={'x': f'{x_title} AUROC', 'y': f'{y_title} AUROC',
                             'sub_emb': 'Subject ID'})
    fig.add_trace(go.Scatter(x=auroc_range, y=auroc_range, mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_layout(width=900, height=800, font_size=15, xaxis_range=auroc_range, yaxis_range=auroc_range,
                      title=dict(text=f'Comparing AUROC<br>y>x: p = {p_val:.3f}; Paired-t', xanchor='center', x=0.5))
    fig.show()

    # BCE Scatter
    bce_range = [0.40, 0.72]
    bce_df = pandas.DataFrame({'x': x_bce, 'y': y_bce}).reset_index()
    p_val = ttest_rel(a=bce_df['y'], b=bce_df['x'], alternative='less')[1]  # test if a < b
    bce_df['sub_emb'] = bce_df.sub_emb.apply(int).apply(str)
    fig = px.scatter(bce_df, x='x', y='y', color='sub_emb', color_discrete_sequence=colours,
                     labels={'x': f'{x_title} BCE', 'y': f'{y_title} BCE',
                             'sub_emb': 'Subject ID'})
    fig.add_trace(go.Scatter(x=bce_range, y=bce_range, mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_layout(width=900, height=800, font_size=15, xaxis_range=bce_range, yaxis_range=bce_range,
                      title=dict(text=f'Comparing BCE<br>y<x: p = {p_val:.3f}; Paired-t', xanchor='center', x=0.5))
    fig.show()


if __name__ == '__main__':
    from basic.plot_codes.compare_accs_finer import compare_metrics_finer
    x_folder = project_dir + f'basic/results/sans_block_bs=64_maxep=100_acc/'
    x_values = pandas.read_pickle(x_folder + f'overall-values.pkl')

    y_folder = project_dir + f'basic/results/sans_block_perc_cont_bs=64_maxep=100_acc/'
    y_values = pandas.read_pickle(y_folder + f'overall-values.pkl')

    compare_metrics(x_values, y_values, 'Sans Block', 'Perc Cont Sans Block')
    compare_metrics_finer(x_values, y_values, 'Sans Block', 'Perc Cont Sans Block')
