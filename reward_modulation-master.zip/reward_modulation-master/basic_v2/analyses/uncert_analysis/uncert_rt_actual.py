import pandas
from config import project_dir
from utils_processing import mc_seeds
from scipy.stats import wilcoxon, ttest_rel
from utils_processing.metrics import p_val_text
import plotly.graph_objs as go


def conditioned_variance(result_dir, yrange, py, title, probed_side_mapper, agg):
    variable = 'side_probed'
    values_df = pandas.read_pickle(result_dir)
    values_df[variable] = values_df[variable].apply(probed_side_mapper)
    values_df['sub_emb'] = values_df.sub_emb.apply(int).apply(str)

    # values_df = values_df[values_df.seed == 0]

    # Trial Level Uncertainty
    pred_cols = list(map(lambda x: f'rt_pred_{x}', range(len(mc_seeds))))
    values_df['rt_pred_var'] = values_df[pred_cols].var(axis=1, ddof=1)

    # Mean of Uncertainty Per Split, Per Block, Per Subject, Per Condition
    values_df = values_df.groupby(['sub_emb', 'seed', 'btest', variable]) \
        .agg({'rt_pred_var': 'mean'}) \
        .reset_index()

    # Median Per Subject, Per Condition
    values_df = values_df.groupby(['sub_emb', variable]) \
        .agg({'rt_pred_var': agg}) \
        .reset_index()

    # Calculate Metric
    values_df['measure'] = values_df['rt_pred_var']

    cond = values_df.copy()
    con0 = cond[cond[variable] == 'FX']
    con1 = cond[cond[variable] == 'VR']

    fig = go.Figure()
    fig.add_trace(go.Bar(x=['FX', 'VR'], y=[con0.measure.mean(), con1.measure.mean()], showlegend=False))

    pt_p_val = ttest_rel(a=con0.measure, b=con1.measure, alternative='two-sided')[1]  # test if a != b
    w_p_val = wilcoxon(x=con0.measure, y=con1.measure, alternative='two-sided')[1]  # test if x != y
    fig.add_annotation(x=0.5, y=py, showarrow=False,
                       text=f'FX != VR<br>{p_val_text(pt_p_val)}; Paired-t<br>{p_val_text(w_p_val)}; Wilcoxon')

    for sub_emb in cond.sub_emb.unique():
        sub0 = con0.query(f'sub_emb == "{sub_emb}"')
        sub1 = con1.query(f'sub_emb == "{sub_emb}"')
        fig.add_trace(go.Scatter(x=['FX', 'VR'], y=[sub0.measure.iloc[0], sub1.measure.iloc[0]],
                                 mode='lines+markers', marker=dict(color='red'), opacity=0.3,
                                 name=f'{sub_emb}',  # showlegend=False,
                                 ))

    fig.update_layout(width=400, height=800, font_size=15, title=title)
    fig.update_xaxes(title_text=variable)
    fig.update_yaxes(title_text='Var(Actual)')
    fig.update_yaxes(range=yrange)

    fig.show()


if __name__ == '__main__':
    for agg in ['median', 'mean']:
        for prefix in [
            'sans_block_v3',
            # 'probed_invert', 'probed_minus_plus', 'probed_plus_minus',
            'reencode',
            'reencodev2',
        ]:
            res_dir = project_dir + f'basic_v2/results/{prefix}_bs=64_maxep=100_rt/'
            if prefix == 'sans_block_v3':
                scheme = 'FX=0, VR=1'
                mapper = lambda x: 'VR' if x == 1 else 'FX'
            elif prefix == 'probed_invert':
                scheme = 'FX=1, VR=0'
                mapper = lambda x: 'VR' if x == 0 else 'FX'
            elif prefix == 'probed_minus_plus':
                scheme = 'FX=-1, VR=1'
                mapper = lambda x: 'VR' if x == 1 else 'FX'
            elif prefix == 'probed_plus_minus':
                scheme = 'FX=1, VR=-1'
                mapper = lambda x: 'VR' if x == -1 else 'FX'
            elif prefix == 'reencode':
                scheme = 'All -1 to 1'
                mapper = lambda x: 'VR' if x == 1 else 'FX'
            elif prefix == 'reencodev2':
                scheme = 'All 1 to -1'
                mapper = lambda x: 'VR' if x == 1 else 'FX'
            else:
                raise Exception()
            conditioned_variance(res_dir + f'mc-test_values.pkl', yrange=[0, 0.08], py=0.06,
                                 title=f'PRERNA with {scheme}<br>{agg}',
                                 probed_side_mapper=mapper,
                                 agg=agg)
