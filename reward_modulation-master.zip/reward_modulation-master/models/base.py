from torch.nn import init, Linear, Embedding, LSTM, ModuleList, ModuleDict, Parameter
from pytorch_lightning.utilities.seed import seed_everything
from abc import ABC
from torch.nn.functional import softmax
import torch
from models._base import BaseModel, choose_init_function, choose_dropout_function, MLP, RNN
import copy


none, learnable, embeddings = 'none', 'learnable', 'embeddings'
unknown_rnn_init = Exception('Unknown rnn initial config')

__all__ = ['WithHistoryBase', 'WithHistoryAndAttentionBase', 'WithoutHistoryMLPBase', 'WithHistoryInitPrNAttnPoNBase']


class WithHistoryBase(BaseModel, ABC):

    def __init__(self,
                 rnn_input_size: int, rnn_hidden_size: int, rnn_layers: int, rnn_bidirectional: bool,
                 rnn_initial: str, rnn_init_hidden_sizes: list[int], rnn_init_activation_func, rnn_init_output_activation_func,
                 hidden_sizes: list[int], activation_func, output_size: int, output_activation_func,
                 num_subjects: int, num_blocks: int,
                 sub_emb_dim: int, block_emb_dim: int,
                 lr: float, cycle_lr: bool, cycle_config: dict, exp_lr: bool,
                 l2reg: bool, l2weight: float, dropout: float, mseed: int,
                 ):
        super(WithHistoryBase, self).__init__()

        if rnn_initial not in [none, learnable, embeddings]:
            raise unknown_rnn_init

        self.rnn_initial = rnn_initial
        self.rnn_init_activation_func = rnn_init_activation_func
        self.rnn_init_output_activation_func = rnn_init_output_activation_func
        self.activation_func = activation_func
        self.output_activation_func = output_activation_func

        self.lr = lr
        self.cycle_lr = cycle_lr
        self.cycle_config = cycle_config
        self.exp_lr = exp_lr
        self.l2reg = l2reg
        self.l2weight = l2weight

        rnn_dropout = dropout if rnn_layers > 1 else 0.
        self.subject_history = LSTM(input_size=rnn_input_size, hidden_size=rnn_hidden_size, num_layers=rnn_layers,
                                    batch_first=True, bidirectional=rnn_bidirectional, dropout=rnn_dropout)

        self.dropout = choose_dropout_function(self.activation_func)(dropout)

        self.internal_layers = ModuleList([])  # Last cell output of LSTM
        for i in range(1, len(hidden_sizes)):
            self.internal_layers.append(
                Linear(in_features=hidden_sizes[i - 1], out_features=hidden_sizes[i], dtype=torch.double))
        self.output_layer = Linear(in_features=hidden_sizes[-1], out_features=output_size, dtype=torch.double)

        if self.rnn_initial in [none, learnable]:
            self.h_0 = self.c_0 = None
        elif self.rnn_initial == embeddings:
            if rnn_layers > 1 and rnn_bidirectional:
                raise Exception("Unimplemented error - Yet to implement code for rnn_layers > 1 and rnn_bidirectional ="
                                " True. Requires changes in the initial state NN and reshaping when using with LSTM")

            # Can be split into separate for cell state and hidden state for LSTM - shared and thus lesser parameters
            rnn_output_size = (2 if rnn_bidirectional else 1) * rnn_hidden_size
            self.init_state_internal_layers = ModuleList([])
            for i in range(1, len(rnn_init_hidden_sizes)):
                self.init_state_internal_layers.append(
                    Linear(in_features=rnn_init_hidden_sizes[i - 1], out_features=rnn_init_hidden_sizes[i], dtype=torch.double))
            self.init_state_output_layer = Linear(in_features=rnn_init_hidden_sizes[-1], out_features=rnn_output_size, dtype=torch.double)

        self.embeddings = ModuleDict()
        if num_subjects > 2 and sub_emb_dim > 1:
            self.embeddings.update({'sub_embedding': Embedding(num_embeddings=num_subjects,
                                                               embedding_dim=sub_emb_dim)})
        if num_blocks > 2 and block_emb_dim > 1:
            self.embeddings.update({'block_embedding': Embedding(num_embeddings=num_blocks,
                                                                 embedding_dim=block_emb_dim)})

        self.initialise(mseed, rnn_hidden_size, rnn_layers, rnn_bidirectional)

        self.double()

    def initialise(self, model_seed, rnn_hidden_size, rnn_layers, rnn_bidirectional):
        # Initialisations
        seed_everything(model_seed)
        init_function = choose_init_function(self.activation_func)
        for layer in self.internal_layers:
            init_function(layer.weight)
            init.zeros_(layer.bias)
        output_init_function = choose_init_function(self.output_activation_func)
        output_init_function(self.output_layer.weight)
        init.zeros_(self.output_layer.bias)
        for name, param in self.subject_history.named_parameters():
            if 'weight_ih' in name:
                init.xavier_uniform_(param)
            elif 'weight_hh' in name:
                init.orthogonal_(param)
            elif 'bias_ih' in name:
                init.zeros_(param)
            elif 'bias_hh' in name:
                param.data = torch.tensor([0] * rnn_hidden_size + [1] * rnn_hidden_size + [0] * rnn_hidden_size * 2,
                                          dtype=torch.double)
        for embedding in self.embeddings.values():
            init.uniform_(embedding.weight, -0.05, 0.05)

        tot_rnn_layers = (2 if rnn_bidirectional else 1) * rnn_layers
        if self.rnn_initial == none:
            self.h_0 = Parameter(torch.zeros(tot_rnn_layers, rnn_hidden_size), requires_grad=False)
            self.c_0 = Parameter(torch.zeros(tot_rnn_layers, rnn_hidden_size), requires_grad=False)
        elif self.rnn_initial == learnable:
            h_0_data = torch.empty((tot_rnn_layers, rnn_hidden_size))
            c_0_data = torch.empty((tot_rnn_layers, rnn_hidden_size))
            init.xavier_uniform_(h_0_data)
            init.xavier_uniform_(c_0_data)
            self.h_0 = Parameter(h_0_data, requires_grad=True)
            self.c_0 = Parameter(c_0_data, requires_grad=True)
        elif self.rnn_initial == embeddings:
            init_function = choose_init_function(self.rnn_init_activation_func)
            for layer in self.init_state_internal_layers:
                init_function(layer.weight)
                init.zeros_(layer.bias)
            output_init_function = choose_init_function(self.rnn_init_output_activation_func)
            output_init_function(self.init_state_output_layer.weight)
            init.zeros_(self.init_state_output_layer.bias)

    def _get_lstm_output(self, lstm: LSTM, lstm_inp, lstm_init_state):  # lstm_inp is of shape (N, T, E)
        """Take the last layer output"""
        _, (h, _) = lstm(lstm_inp, lstm_init_state)  # h is of shape (D*num_layers, N, H)
        if lstm.bidirectional:
            last_layer_outputs = h[-2:, :, :]
            batch_size = last_layer_outputs.shape[1]
            return last_layer_outputs.transpose(0, 1).reshape(batch_size, -1)  # (N, 2*H)
        else:
            return h[-1, :, :]  # (N, H)

    def _forward_init_internal_layers(self, op: torch.Tensor) -> torch.Tensor:
        for layer in self.init_state_internal_layers:
            op = layer(op)
            if self.rnn_init_activation_func:
                op = self.rnn_init_activation_func(op)
            op = self.dropout(op)
        return op

    def _forward_init_output_layer(self, op: torch.Tensor) -> torch.Tensor:
        op = self.init_state_output_layer(op)
        if self.rnn_init_output_activation_func:
            op = self.rnn_init_output_activation_func(op)
        return op


class WithHistoryAndAttentionBase(WithHistoryBase, ABC):

    def __init__(self, rnn_hidden_size: int, rnn_bidirectional: bool, **kwargs):
        rnn_output_size = (2 if rnn_bidirectional else 1) * rnn_hidden_size
        attention_layer = Linear(in_features=rnn_output_size, out_features=1)

        super(WithHistoryAndAttentionBase, self).__init__(rnn_hidden_size=rnn_hidden_size, rnn_bidirectional=rnn_bidirectional,
                                                          **kwargs)

        self.attention_layer = attention_layer  # cannot use self before super's __init__ completes

        # Initialise after the model seed gets set in the super() call
        attention_init_function = choose_init_function(torch.sigmoid)
        attention_init_function(self.attention_layer.weight)
        init.zeros_(self.attention_layer.bias)

        self.double()

    def _get_lstm_output(self, lstm: LSTM, lstm_inp, lstm_init_state):
        out, _ = lstm(lstm_inp, lstm_init_state)  # out is of shape (N, T, D*H) from the last *layer* of the LSTM
        attention = self.attention_layer(out)  # (N, T, 1)
        attention = softmax(attention, dim=1)  # (N, T, 1)
        modulated = out * attention  # (N, T, D*H)
        convex_combination = modulated.sum(dim=1)  # (N, D*H) - add across time
        return convex_combination  # (N, D*H)


class WithoutHistoryMLPBase(BaseModel, ABC):

    def __init__(self,
                 hidden_sizes: list[int], activation_func, output_size: int, output_activation_func,
                 num_subjects: int, num_blocks: int,
                 sub_emb_dim: int, block_emb_dim: int,
                 lr: float, cycle_lr: bool, cycle_config: dict, exp_lr: bool,
                 l2reg: bool, l2weight: float, dropout: float, mseed: int,
                 ):
        super(WithoutHistoryMLPBase, self).__init__()

        self.activation_func = activation_func
        self.output_activation_func = output_activation_func

        self.lr = lr
        self.cycle_lr = cycle_lr
        self.cycle_config = cycle_config
        self.exp_lr = exp_lr
        self.l2reg = l2reg
        self.l2weight = l2weight

        self.dropout = choose_dropout_function(self.activation_func)(dropout)

        self.internal_layers = ModuleList([])
        for i in range(1, len(hidden_sizes)):
            self.internal_layers.append(
                Linear(in_features=hidden_sizes[i - 1], out_features=hidden_sizes[i], dtype=torch.double))
        self.output_layer = Linear(in_features=hidden_sizes[-1], out_features=output_size, dtype=torch.double)

        self.embeddings = ModuleDict()
        if num_subjects > 2 and sub_emb_dim > 1:
            self.embeddings.update({'sub_embedding': Embedding(num_embeddings=num_subjects,
                                                               embedding_dim=sub_emb_dim)})
        if num_blocks > 2 and block_emb_dim > 1:
            self.embeddings.update({'block_embedding': Embedding(num_embeddings=num_blocks,
                                                                 embedding_dim=block_emb_dim)})

        self.initialise(mseed)

        self.double()

    def initialise(self, model_seed):
        # Initialisations
        seed_everything(model_seed)
        init_function = choose_init_function(self.activation_func)
        for layer in self.internal_layers:
            init_function(layer.weight)
            init.zeros_(layer.bias)
        output_init_function = choose_init_function(self.output_activation_func)
        output_init_function(self.output_layer.weight)
        init.zeros_(self.output_layer.bias)

        for embedding in self.embeddings.values():
            init.uniform_(embedding.weight, -0.05, 0.05)


class WithHistoryInitPrNAttnPoNBase(BaseModel, ABC):
    # todo: 1. Support for RNN Types, LSTM take cell output or cell state

    def __init__(self,
                 rnn_config: dict,
                 prn_config: dict, pon_config: dict,
                 num_subjects: int, num_blocks: int,
                 lr: float, cycle_lr: bool, cycle_config: dict, exp_lr: bool,
                 l2reg: bool, l2weight: float, mseed: int,
                 ):
        """
        :param num_subjects: 0 if not to have any embeddings
        :param num_blocks: 0 if not to have any embeddings
        """
        super(WithHistoryInitPrNAttnPoNBase, self).__init__()

        self.lr = lr
        self.cycle_lr = cycle_lr
        self.cycle_config = cycle_config
        self.exp_lr = exp_lr
        self.l2reg = l2reg
        self.l2weight = l2weight

        _prn_config = copy.deepcopy(prn_config)  # we need to pop, hence make a copy
        _pon_config = copy.deepcopy(pon_config)
        self.prn_embeddings = ModuleDict()
        self.pon_embeddings = ModuleDict()
        if num_subjects > 2:
            prn_sub_dim = _prn_config.pop('sub_dim', 0)
            pon_sub_dim = _pon_config.pop('sub_dim', 0)
            if prn_sub_dim > 0:
                self.prn_embeddings['sub_embedding'] = Embedding(num_subjects, prn_sub_dim)
            if pon_sub_dim > 0:
                self.pon_embeddings['sub_embedding'] = Embedding(num_subjects, pon_sub_dim)
        if num_blocks > 2:
            prn_block_dim = _prn_config.pop('block_dim', 0)
            pon_block_dim = _pon_config.pop('block_dim', 0)
            if prn_block_dim > 0:
                self.prn_embeddings['block_embedding'] = Embedding(num_blocks, prn_block_dim)
            if pon_block_dim > 0:
                self.pon_embeddings['block_embedding'] = Embedding(num_blocks, pon_block_dim)

        self.prn = MLP(**_prn_config)
        self.pon = MLP(**_pon_config)
        self.rnn = RNN(**rnn_config, num_subjects=num_subjects, num_blocks=num_blocks)

        self.initialise(mseed)

        self.double()

    def initialise(self, model_seed):
        # Initialisations
        seed_everything(model_seed)
        self.prn.initialise()
        self.rnn.initialise()
        self.pon.initialise()

        for embedding in self.prn_embeddings.values():
            init.uniform_(embedding.weight, -0.05, 0.05)
        for embedding in self.pon_embeddings.values():
            init.uniform_(embedding.weight, -0.05, 0.05)

    def forward(self, inpt,  # (N, T, I)
                sub_ids,  # (N,)
                block_ids,  # (N,)
                ):
        T = inpt.shape[1]

        # Prn processing
        prn_inputs = [inpt]
        sub_emb = sub_ids.view((-1, 1)).repeat((1, T))  # (N, T)
        block_emb = block_ids.view((-1, 1)).repeat((1, T))  # (N, T)
        if 'sub_embedding' in self.prn_embeddings:
            prn_inputs.append(self.prn_embeddings['sub_embedding'](sub_emb))  # (N, T, Sb)
        if 'block_embedding' in self.prn_embeddings:
            prn_inputs.append(self.prn_embeddings['block_embedding'](block_emb))  # (N, T, B)
        prn_input = torch.concat(prn_inputs, dim=2)  # (N, T, I+Sb+B)
        prn_output = self.prn(prn_input)  # (N, T, E)

        # RNN processing
        summary_vector = self.rnn(prn_output, sub_ids, block_ids)  # (N, R)

        # Pon processing
        pon_inputs = [summary_vector]
        if 'sub_embedding' in self.pon_embeddings:
            pon_inputs.append(self.pon_embeddings['sub_embedding'](sub_ids))  # (N, Sb)
        if 'block_embedding' in self.pon_embeddings:
            pon_inputs.append(self.pon_embeddings['block_embedding'](block_ids))  # (N, B)
        pon_input = torch.concat(pon_inputs, dim=1)  # (N, R+Sb+B)
        op = self.pon(pon_input)
        return op
