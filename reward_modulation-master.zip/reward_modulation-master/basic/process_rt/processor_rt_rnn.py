from utils_training.training_rt import execute_trial, learn_transform_rt, get_data_for_trial
from utils_processing.common_proc import read_data_and_preprocess, get_train_test_split_df
from utils_data import num_gain_blocks, num_subjects
from utils_processing.common_proc import prespast_columns
from basic import optuna_storage
from config import project_dir
from math import sqrt
from utils_generic import send_message
import argparse
import os
import optuna
import gc

# lr, l2, deeper PoNs, block embeddings, rnn types,
# projection, rnn types, lstm cell state/cell op/both


def execute_study(model_class, seed: int, b: int, bs: int, num_epochs: int, prefix: str, gpu_num: list[int]):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_rt'
    res_dir = project_dir + 'basic/results/' + folder_name + '/'
    os.makedirs(res_dir, exist_ok=True)

    btest = b
    bval = (b + 1) % num_gain_blocks
    study_name = f'{folder_name}_{seed}_{b}'
    study = optuna.create_study(direction='minimize', study_name=study_name,
                                storage=optuna_storage, load_if_exists=True)

    num_features = len(prespast_columns[model_class.lstm_variable()])

    # Hyperparameter configs to try
    kind = 'lstm'
    prn_dropout = 0
    T = 3

    # Get Data - depends on T
    proc_df = read_data_and_preprocess(T, return_raw=False)
    train_test_split_df = get_train_test_split_df(seed)
    train_df, val_df, _, _ = learn_transform_rt(btest, bval, proc_df, train_test_split_df)
    train_dataloader, val_dataloader = get_data_for_trial(bs, model_class, train_df, val_df)

    for rnn_layers in [1, 2]:

        rnn_dropout = 0.2 if rnn_layers > 1 else 0

        for rnn_bidirectional in [False, True]:

            for rnn_hidden_size in [5, 8]:

                rnn_output_size = (2 if rnn_bidirectional else 1) * rnn_hidden_size

                for sub_dim in [2, 3]:

                    first_size = num_features + sub_dim
                    prn_hidden_sizes = [first_size, ]
                    prn_output_size = first_size // 2

                    for prn_batch_norm in [True, False]:

                        for attn in [True, False]:

                            attn_config = dict(sub_dim=sub_dim) if attn else dict()

                            model_kwargs = dict(
                                num_subjects=num_subjects, num_blocks=0,
                                prn_config=dict(
                                    sub_dim=sub_dim,
                                    hidden_sizes=prn_hidden_sizes, activation_func=None,
                                    output_size=prn_output_size, output_activation_func='gelu',
                                    dropout=prn_dropout, batch_norm=prn_batch_norm, reg_op=prn_dropout > 0 or prn_batch_norm,
                                ),
                                rnn_config=dict(
                                    kind=kind, input_size=prn_output_size, hidden_size=rnn_hidden_size, num_layers=rnn_layers,
                                    bidirectional=rnn_bidirectional, dropout=rnn_dropout,
                                    init_config=dict(),
                                    attn=attn, attn_config=attn_config,
                                ),
                                pon_config=dict(
                                    sub_dim=sub_dim,
                                    hidden_sizes=[rnn_output_size + sub_dim, ], activation_func=None,
                                    output_size=1, output_activation_func=None,
                                    dropout=0, batch_norm=False, reg_op=False,
                                ),
                                lr=0.01, cycle_lr=False, cycle_config={}, exp_lr=True,
                                l2reg=False, l2weight=0,  # https://stats.stackexchange.com/a/275088/217039
                                mseed=0,
                            )

                            # Run one config
                            trial = execute_trial(model_class, model_kwargs, train_dataloader, val_dataloader,
                                                  seed, btest, bval, bs, num_epochs, False, res_dir, study_name,
                                                  {'T': T, 'prefix': prefix},
                                                  gpu_num)
                            study.add_trial(trial)
                            gc.collect()


if __name__ == '__main__':
    from models.final import OnlyRTWithHistoryInitPrNAttnPoNFinal
    bs = 64
    num_epochs = 100
    prefix = 'rnn_baw'

    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', dest='seed', type=int)
    parser.add_argument('--btest', dest='btest', type=int, action='append')
    args = parser.parse_args()

    for btest in args.btest:
        execute_study(OnlyRTWithHistoryInitPrNAttnPoNFinal, args.seed, btest, bs, num_epochs, prefix, [0])

    send_message(f'RNN_Bells_and_Whistles RT - {prefix} - seed = {args.seed}, btest = {args.btest} Finished')
