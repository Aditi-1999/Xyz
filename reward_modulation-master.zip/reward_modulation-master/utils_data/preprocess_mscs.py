import numpy
from config import data_dir
import scipy.io as sio
import pandas
from utils_data import num_subjects, num_actual_blocks, num_trials_per_block
from utils_generic import get_list_as_dict


def unify_array_format_phis(arr: numpy.ndarray):
    if arr is not None and numpy.size(arr):
        assert len(arr.shape) == 2
        assert arr.shape[1] == 1
        return arr[:, 0]
    else:
        return numpy.nan


def unify_array_format_starts(arr: numpy.ndarray):
    if arr is not None and numpy.size(arr):
        assert len(arr.shape) == 2
        assert arr.shape[0] == 1
        return arr[0, :]
    else:
        return numpy.nan


def msc_d_data():
    raw_msc_data = sio.loadmat(data_dir + f'raw_data/spatial_msc_vrfx.mat')

    msc_data = numpy.empty((num_subjects, num_actual_blocks * num_trials_per_block, 6), dtype=object)

    for sub_num in range(num_subjects):
        nans = numpy.isnan(raw_msc_data['GL'][sub_num, 0][:, 0])
        msc_data[sub_num, :, 0] = raw_msc_data['GL'][sub_num, 0][:, 0] == 1  # isGain
        msc_data[sub_num, :, 1] = raw_msc_data['hilo'][sub_num, 0][:, 0] == 1  # isVR>FX
        msc_data[sub_num, :, 2] = raw_msc_data['probed'][sub_num, 0][:, 0] == 2  # isVRProbed
        for dim in range(3):
            msc_data[sub_num, nans, dim] = numpy.nan

    phis = pandas.DataFrame(raw_msc_data['eyesacc'][0, 0]['Phi'].T)
    phis = phis.applymap(unify_array_format_phis).values
    msc_data[:, :, 3] = phis

    start_times = pandas.DataFrame(raw_msc_data['eyesacc'][0, 0]['isNoise'].T)
    start_times = start_times.applymap(unify_array_format_starts).values
    msc_data[:, :, 4] = start_times

    amps = pandas.DataFrame(raw_msc_data['eyesacc'][0, 0]['Amp'].T)
    amps = amps.applymap(unify_array_format_phis).values
    msc_data[:, :, 5] = amps

    numpy.savez_compressed(data_dir + 'all_d_msc.npz', msc_data=msc_data)


def format_msc_data():
    msc_data = numpy.load(data_dir + f'all_d_msc.npz', allow_pickle=True)['msc_data']
    actual_block_num, trial_nums = [], []
    for b in range(num_actual_blocks):
        actual_block_num.extend([b] * num_trials_per_block)
        trial_nums.extend(list(range(num_trials_per_block)))

    formatted_data = []
    for sub_num in range(num_subjects):
        sub_data = msc_data[sub_num, :, :]
        sub_data_df = pandas.DataFrame(sub_data,
                                       columns=['block_type', 'reward_vr_fx', 'side_probed', 'phis', 'starts', 'amps'])

        sub_data_df['sub_num'] = sub_num
        sub_data_df['actual_block_num'] = actual_block_num
        sub_data_df['trial_num'] = trial_nums
        for col in ['block_type', 'reward_vr_fx', 'side_probed']:
            sub_data_df[col] = sub_data_df[col].apply(lambda x: pandas.NA if pandas.isna(x) else int(x))
        formatted_data.append(sub_data_df)

    formatted_df = pandas.concat(formatted_data, ignore_index=True)
    formatted_df = formatted_df.query('block_type == 1').copy()
    gain_block_order = formatted_df.groupby('sub_num').actual_block_num.unique().apply(get_list_as_dict).to_dict()
    formatted_df['gain_block_num'] = formatted_df.apply(lambda row: gain_block_order[row.sub_num][row.actual_block_num],
                                                        axis=1)
    formatted_df.sort_values(['sub_num', 'gain_block_num', 'trial_num'], inplace=True)
    formatted_df.to_pickle(data_dir + 'gain_d_msc.pkl')


def formatting_checks():
    """Check matching with behavioural data"""
    data_df = pandas.read_json(data_dir + f'gain_d_data.json', orient='columns')
    # data_df = data_df[pandas.notna(data_df.response_time)].copy()
    msc_data = pandas.read_pickle(data_dir + f'gain_d_msc.pkl')

    data = data_df[['sub_num', 'gain_block_num', 'trial_num']].values.tolist()
    data = list(map(tuple, data))
    mscs = msc_data[['sub_num', 'gain_block_num', 'trial_num']].values.tolist()
    mscs = list(map(tuple, mscs))

    missing = set(mscs) - set(data)
    assert missing == set()


if __name__ == '__main__':
    msc_d_data()
    format_msc_data()
