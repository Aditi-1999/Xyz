import argparse
from subj_wise.processor_rt_nohist_lstm import execute_study
from models.final import OnlyRTWithHistoryBasicFinal
from utils_generic import send_message


if __name__ == '__main__':
    bs = 32
    num_epochs = 100
    prefix = 'subj_wise_nohist_lstm'

    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', dest='seed', type=int)
    parser.add_argument('--btest', dest='btest', type=int, action='append')
    args = parser.parse_args()

    for btest in args.btest:
        execute_study(OnlyRTWithHistoryBasicFinal, args.seed, btest, bs, num_epochs, prefix, [0])

    send_message(f'SubjectWise RT NoHist LSTM - {prefix} - seed = {args.seed}, btest = {args.btest} Finished')
