from config import server

if server in ['wellsfargo', 'magnus']:
    optuna_storage = "mysql://newraj:password@10.36.17.196/RewardModulationV2"  # Point to Nova's mysql
else:
    optuna_storage = "mysql://root:password@localhost/RewardModulationV2"
    # optuna_storage = "mysql://newraj:password@10.36.17.196/RewardModulationV2"

read_storage = "mysql://newraj:password@10.36.17.196/RewardModulationV2"
