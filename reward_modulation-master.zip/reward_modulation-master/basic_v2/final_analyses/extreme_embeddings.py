from tqdm import tqdm
from config import project_dir
import numpy
import plotly.express as px
from basic_v2.hp_checks import hp_checks
from basic_v2.analyses.se_analysis import best_block_hp
import pandas
from basic_v2.final_analyses import get_subj_embed_df, get_sub_actual_mses, rt_file, dist_names, get_sub_actual_bces, \
    acc_file
from models_v2.final import OnlyRTWithLSTMHistoryFinalV2, OnlyAccWithLSTMHistoryFinalV2
from utils_processing.metrics import compute_robust_corr, distances, cosine_dist, p_val_text

cols = list(map(lambda x: f'x{x}', range(1, 6)))
hp_keys = ['T', 'rnn_layers', 'rnn_bidirectional', 'rnn_hidden_size', 'hidden_sizes', 'dropout']


def correlate_dist_delta_rt():
    results = hp_checks([0, 10, 20], 'sans_block_v3', 64, 100, lambda d: True, 'rt', hp_keys)
    hp_results = best_block_hp(results)
    subj_dfs = []
    for idx, row in tqdm(hp_results.iterrows()):
        trial = row.to_dict()
        df_subj = get_subj_embed_df(OnlyRTWithLSTMHistoryFinalV2, trial['folder_path'])
        subj_embed = df_subj[cols].values
        median = numpy.median(subj_embed, axis=0)
        mean = numpy.mean(subj_embed, axis=0)
        df_subj['l2_median'] = distances(subj_embed, median, 2)
        df_subj['cos_median'] = cosine_dist(subj_embed, median)
        df_subj['l2_mean'] = distances(subj_embed, mean, 2)
        df_subj['cos_mean'] = cosine_dist(subj_embed, mean)
        subj_dfs.append(df_subj)

    subj_df = pandas.concat(subj_dfs, ignore_index=True)
    subj_distances = subj_df.groupby(['subject']).mean()
    subj_distances.to_pickle(project_dir + 'aistats_figures/data/srm/bisann_l2dist_rt.pkl')

    with_se = get_sub_actual_mses(rt_file(project_dir + f'basic_v2/results/sans_block_v3_bs=64_maxep=100_rt/mc-test_values.pkl'))
    sans_se = get_sub_actual_mses(rt_file(project_dir + f'basic_v2/results/sans_se_bs=64_maxep=100_rt/mc-test_values.pkl'))

    for dist in [
        'l2_median',
        # 'l2_mean',
        # 'cos_median',
        # 'cos_mean'
    ]:
        for delta, delta_name in [
            (with_se - sans_se, 'WithSE - SansSE: MSE'),
            # ((with_se - sans_se) / with_se, '(WithSE - SansSE) / WithSE: MSE'),
            # ((with_se - sans_se) / sans_se, '(WithSE - SansSE) / SansSE: MSE'),
            # ((with_se - sans_se) / (with_se + sans_se), '(WithSE - SansSE) / (WithSE + SansSE): MSE'),
        ]:
            subj_distances[delta_name] = delta
            rcorr = compute_robust_corr(subj_distances, dist, delta_name)
            fig = px.scatter(subj_distances, x=dist, y=delta_name,
                             trendline='ols', trendline_color_override='black',
                             title=f'SRM - RT Embeddings: R.Corr = {rcorr["corr"]:.3f}; {p_val_text(rcorr["pval"])}',
                             height=600, width=600)
            fig.update_layout(title=dict(xanchor='center', x=0.5))
            fig.update_xaxes(title_text=dist_names[dist])
            fig.update_yaxes(title_text=delta_name)
            fig.show()


def correlate_dist_delta_acc():
    results = hp_checks([0, 10, 20], 'sans_block_v3', 64, 100, lambda d: True, 'acc', hp_keys)
    hp_results = best_block_hp(results)
    subj_dfs = []
    for idx, row in tqdm(hp_results.iterrows()):
        trial = row.to_dict()
        df_subj = get_subj_embed_df(OnlyAccWithLSTMHistoryFinalV2, trial['folder_path'])
        subj_embed = df_subj[cols].values
        median = numpy.median(subj_embed, axis=0)
        mean = numpy.mean(subj_embed, axis=0)
        df_subj['l2_median'] = distances(subj_embed, median, 2)
        df_subj['cos_median'] = cosine_dist(subj_embed, median)
        df_subj['l2_mean'] = distances(subj_embed, mean, 2)
        df_subj['cos_mean'] = cosine_dist(subj_embed, mean)
        subj_dfs.append(df_subj)

    subj_df = pandas.concat(subj_dfs, ignore_index=True)
    subj_distances = subj_df.groupby(['subject']).mean()
    subj_distances.to_pickle(project_dir + 'aistats_figures/data/srm/bisann_l2dist_acc.pkl')

    with_se = get_sub_actual_bces(acc_file(project_dir + f'basic_v2/results/sans_block_v3_bs=64_maxep=100_acc/mc-test_values.pkl'))
    sans_se = get_sub_actual_bces(acc_file(project_dir + f'basic_v2/results/sans_se_bs=64_maxep=100_acc/mc-test_values.pkl'))

    for dist in [
        'l2_median',
        # 'l2_mean',
        # 'cos_median',
        # 'cos_mean'
    ]:
        for delta, delta_name in [
            (with_se - sans_se, 'WithSE - SansSE: BCE'),
            # ((with_se - sans_se) / with_se, '(WithSE - SansSE) / WithSE: BCE'),
            # ((with_se - sans_se) / sans_se, '(WithSE - SansSE) / SansSE: BCE'),
            # ((with_se - sans_se) / (with_se + sans_se), '(WithSE - SansSE) / (WithSE + SansSE): BCE'),
        ]:
            subj_distances[delta_name] = delta
            rcorr = compute_robust_corr(subj_distances, dist, delta_name)
            fig = px.scatter(subj_distances, x=dist, y=delta_name,
                             trendline='ols', trendline_color_override='black',
                             title=f'SRM - Acc Embeddings: R.Corr = {rcorr["corr"]:.3f}; {p_val_text(rcorr["pval"])}',
                             height=600, width=600)
            fig.update_layout(title=dict(xanchor='center', x=0.5))
            fig.update_xaxes(title_text=dist_names[dist])
            fig.update_yaxes(title_text=delta_name)
            fig.show()


if __name__ == '__main__':
    correlate_dist_delta_rt()
    correlate_dist_delta_acc()
