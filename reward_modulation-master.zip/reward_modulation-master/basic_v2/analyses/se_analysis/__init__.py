from config import project_dir


def get_full_folder_path(row):
    return project_dir + 'basic_v2/results/' + row.folder_name + '/' + row.study_name + '/' + row.trial_id + '/'


def best_block_hp(results_df):
    idx = results_df.groupby(['seed', 'b']).value.transform(min) == results_df.value
    best_trials = results_df[idx].copy()
    best_trials['trial_id'] = best_trials.user_attrs_config.apply(lambda d: d['trial_id'])
    best_trials['folder_path'] = best_trials.apply(get_full_folder_path, axis=1)
    best_trials['btest'] = best_trials.user_attrs_config.apply(lambda d: d['btest'])
    best_trials['T'] = best_trials.user_attrs_config.apply(lambda d: d['T'])
    return best_trials
