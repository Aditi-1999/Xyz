import pandas
import plotly.graph_objs as go
import plotly.express as px
from config import project_dir
from utils_data import colours
from utils_processing.metrics import compute_robust_corr, compute_mse


def get_actual_metrics(values_df):
    # Actual History Predictions
    actual_corrs = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_robust_corr(df, 'rt_target', 'rt_pred')['corr'])
    actual_corrs.name = 'metric'
    actual_corrs = actual_corrs.reset_index()
    actual_corrs = actual_corrs.groupby(['sub_emb']).metric.mean()

    actual_mses = values_df.groupby(['sub_emb', 'seed', 'block_emb']).apply(lambda df: compute_mse(df, 'rt_target', 'rt_pred'))
    actual_mses.name = 'metric'
    actual_mses = actual_mses.reset_index()
    actual_mses = actual_mses.groupby(['sub_emb']).metric.mean()

    return actual_corrs, actual_mses


def compare_metrics(x_values_df, y_values_df, x_title, y_title):
    x_corr, x_mse = get_actual_metrics(x_values_df)
    y_corr, y_mse = get_actual_metrics(y_values_df)

    # todo: add p-values here also. y>x for corr. y<x for mse.

    # Robust Correlation Scatter
    corr_range = [-0.2, 0.6]
    corr_df = pandas.DataFrame({'x': x_corr, 'y': y_corr}).reset_index()
    corr_df['sub_emb'] = corr_df.sub_emb.apply(int).apply(str)
    fig = px.scatter(corr_df, x='x', y='y', color='sub_emb', color_discrete_sequence=colours,
                     # trendline='ols', trendline_scope='overall', trendline_color_override='black',
                     labels={'x': f'{x_title} Robust Corr', 'y': f'{y_title} Robust Corr',
                             'sub_emb': 'Subject ID'})
    fig.add_trace(go.Scatter(x=corr_range, y=corr_range, mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_layout(width=900, height=800, font_size=15, xaxis_range=corr_range, yaxis_range=corr_range,
                      title=dict(text='Comparing Robust Corr', xanchor='center', x=0.5))
    fig.show()

    # MSE Scatter
    mse_range = [0.9, 1.8]
    mse_df = pandas.DataFrame({'x': x_mse, 'y': y_mse}).reset_index()
    mse_df['sub_emb'] = mse_df.sub_emb.apply(int).apply(str)
    fig = px.scatter(mse_df, x='x', y='y', color='sub_emb', color_discrete_sequence=colours,
                     # trendline='ols', trendline_scope='overall', trendline_color_override='black',
                     labels={'x': f'{x_title} MSE', 'y': f'{y_title} MSE',
                             'sub_emb': 'Subject ID'})
    fig.add_trace(go.Scatter(x=mse_range, y=mse_range, mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_layout(width=900, height=800, font_size=15,
                      title=dict(text='Comparing MSE', xanchor='center', x=0.5))
    fig.show()


if __name__ == '__main__':
    x_folder = project_dir + f'basic/results/basic_sans_block_bs=64_maxep=100_rt/'
    x_values = pandas.read_pickle(x_folder + f'overall-values.pkl')

    y_folder = project_dir + f'basic/results/basic_attn_bs=64_maxep=100_rt/'
    y_values = pandas.read_pickle(y_folder + f'overall-values.pkl')

    compare_metrics(x_values, y_values, 'Sans Block Model', 'Common+Attn Model')
