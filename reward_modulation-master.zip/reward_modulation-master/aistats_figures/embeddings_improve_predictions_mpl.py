from aistats_figures import rt_file, acc_file, get_sub_metrics, color, data_dir, p_text
from scipy.stats import ttest_rel
from matplotlib.axes import Axes
from numpy.typing import NDArray
import matplotlib.pyplot as plt
from config import project_dir
import pandas
import numpy

point_size = 100
ipoint_size = 75
font_size = 13
ifont_size = 10
lfont_size = 15


def get_rt_metrics(rt_fname, experiment):
    values = rt_file(rt_fname)
    corr = get_sub_metrics(values, experiment=experiment, metric='rt', measure='corr', shuffled=False)
    corr.name = 'corr'
    mse = get_sub_metrics(values, experiment=experiment, metric='rt', measure='mse', shuffled=False)
    mse.name = 'mse'
    return pandas.DataFrame([corr, mse]).transpose()


def get_all_rt_metrics(experiment):
    bisann = get_rt_metrics(data_dir + experiment + '/bisann_rt.pkl', experiment=experiment)
    sanspe = get_rt_metrics(data_dir + experiment + '/sanspe_rt.pkl', experiment=experiment)
    indiv = get_rt_metrics(data_dir + experiment + '/indiv_rt.pkl', experiment=experiment)
    return bisann, sanspe, indiv


def get_acc_metrics(acc_fname, experiment):
    values = acc_file(acc_fname)
    auroc = get_sub_metrics(values, experiment=experiment, metric='acc', measure='auroc', shuffled=False)
    auroc.name = 'auroc'
    bce = get_sub_metrics(values, experiment=experiment, metric='acc', measure='bce', shuffled=False)
    bce.name = 'bce'
    return pandas.DataFrame([auroc, bce]).transpose()


def get_all_acc_metrics(experiment):
    bisann = get_acc_metrics(data_dir + experiment + '/bisann_acc.pkl', experiment=experiment)
    sanspe = get_acc_metrics(data_dir + experiment + '/sanspe_acc.pkl', experiment=experiment)
    indiv = get_acc_metrics(data_dir + experiment + '/indiv_acc.pkl', experiment=experiment)
    return bisann, sanspe, indiv


def plot_metrics(ax: Axes, vrange, measure, bisann, sanspe, indiv, experiment, showlegend,
                 xlabel, ylabel, iylabel, ticks, iticks, main_p_pos, inset_p_pos, override_inset=None):
    if measure in ['corr', 'auroc']:
        inset_loc = [0.19, 0.7, 0.3, 0.3]
        direction = 'greater'
    elif measure in ['mse', 'bce']:
        inset_loc = [0.7, 0.2, 0.3, 0.3]
        direction = 'less'
    else:
        raise Exception()
    if override_inset:
        inset_loc = override_inset

    if measure in ['corr', 'auroc']:
        kws = dict(edgecolor='white')
    else:
        kws = dict(facecolor='white')

    ax.scatter(x=bisann[measure], y=sanspe[measure],
               color=color[experiment], marker='o', s=point_size, **kws,
               label=f'{experiment.upper()}' if showlegend else None)
    ax.plot(vrange, vrange, color='black', linestyle='--')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.set_xlim(*vrange)
    ax.set_ylim(*vrange)
    ax.set_xlabel(xlabel, fontsize=font_size)
    ax.set_ylabel(ylabel, fontsize=font_size)
    ax.set_xticks(ticks)
    ax.set_yticks(ticks)
    for tick in ax.get_xticklabels() + ax.get_yticklabels():
        tick.set_fontsize(font_size)
    main_p = ttest_rel(a=bisann[measure], b=sanspe[measure], alternative=direction)[1]
    main_p = p_text(main_p)
    ax.text(*main_p_pos, s=main_p, ha='center', va='center', fontsize=font_size)

    inset_ax = ax.inset_axes(inset_loc)  # [left, bottom, width, height]
    inset_ax.scatter(x=bisann[measure], y=indiv[measure],
                     color=color[experiment], marker='o', s=ipoint_size, **kws,
                     label=f'{experiment.upper()}' if showlegend else None)
    inset_ax.plot(vrange, vrange, color='black', linestyle='--')
    inset_ax.spines['top'].set_visible(False)
    inset_ax.spines['right'].set_visible(False)
    inset_ax.set_xlim(*vrange)
    inset_ax.set_ylim(*vrange)
    inset_ax.set_xlabel(xlabel, fontsize=ifont_size)
    inset_ax.set_ylabel(iylabel, fontsize=ifont_size)
    inset_ax.set_xticks(iticks)
    inset_ax.set_yticks(iticks)
    for tick in inset_ax.get_xticklabels() + inset_ax.get_yticklabels():
        tick.set_fontsize(ifont_size)
    inset_p = ttest_rel(a=bisann[measure], b=indiv[measure], alternative=direction)[1]
    inset_p = p_text(inset_p)
    inset_ax.text(*inset_p_pos, s=inset_p, ha='center', va='center', fontsize=ifont_size)


def make_rt_subplots(axs: NDArray[Axes]):  # four column axes for first row
    srm_bisann, srm_sanspe, srm_indiv = get_all_rt_metrics(experiment='srm')
    plot_metrics(axs[0], [-0.15, 0.5], 'corr', srm_bisann, srm_sanspe, srm_indiv, 'srm', True,
                 'R.Corr(PRERNA)', 'R.Corr(SansPE)', 'R.Corr(Indiv)',
                 numpy.arange(-0.1, 0.5, 0.2), numpy.arange(-0.1, 0.5, 0.4),
                 (0.4, 0), (0.1, 0.49))
    plot_metrics(axs[1], [0.8, 2.1], 'mse', srm_bisann, srm_sanspe, srm_indiv, 'srm', False,
                 'MSE(PRERNA)', 'MSE(SansPE)', 'MSE(Indiv)',
                 numpy.arange(0.8, 2.1, 0.4), numpy.arange(0.8, 2.1, 0.8),
                 (1.2, 1.8), (2.0, 1.2))

    tms_bisann, tms_sanspe, tms_indiv = get_all_rt_metrics(experiment='tms')
    plot_metrics(axs[2], [0, 0.75], 'corr', tms_bisann, tms_sanspe, tms_indiv, 'tms', True,
                 'R.Corr(PRERNA)', 'R.Corr(SansPE)', 'R.Corr(Indiv)',
                 numpy.arange(0, 0.75, 0.2), numpy.arange(0, 0.75, 0.4),
                 (0.6, 0.1), (0.25, 0.7))
    plot_metrics(axs[3], [0.5, 1.2], 'mse', tms_bisann, tms_sanspe, tms_indiv, 'tms', False,
                 'MSE(PRERNA)', 'MSE(SansPE)', 'MSE(Indiv)',
                 numpy.arange(0.5, 1.2, 0.2), numpy.arange(0.5, 1.2, 0.4),
                 (0.7, 1.1), (1.0, 0.6))


def make_acc_subplots(axs: NDArray[Axes]):  # four column axes for second row
    srm_bisann, srm_sanspe, srm_indiv = get_all_acc_metrics(experiment='srm')
    plot_metrics(axs[0], [0.4, 0.9], 'auroc', srm_bisann, srm_sanspe, srm_indiv, 'srm', False,
                 'AUROC(PRERNA)', 'AUROC(SansPE)', 'AUROC(Indiv)',
                 numpy.arange(0.4, 0.9, 0.1), numpy.arange(0.4, 0.9, 0.4),
                 (0.8, 0.5), (0.6, 0.9))
    plot_metrics(axs[1], [0.4, 0.75], 'bce', srm_bisann, srm_sanspe, srm_indiv, 'srm', False,
                 'BCE(PRERNA)', 'BCE(SansPE)', 'BCE(Indiv)',
                 numpy.arange(0.4, 0.75, 0.1), numpy.arange(0.4, 0.75, 0.3),
                 (0.5, 0.7), (0.7, 0.45))

    tms_bisann, tms_sanspe, tms_indiv = get_all_acc_metrics(experiment='tms')
    plot_metrics(axs[2], [0.45, 0.9], 'auroc', tms_bisann, tms_sanspe, tms_indiv, 'tms', False,
                 'AUROC(PRERNA)', 'AUROC(SansPE)', 'AUROC(Indiv)',
                 numpy.arange(0.45, 0.9, 0.1), numpy.arange(0.45, 0.9, 0.4),
                 (0.8, 0.55), (0.65, 0.9), override_inset=[0.195, 0.7, 0.3, 0.3])
    plot_metrics(axs[3], [0.2, 0.7], 'bce', tms_bisann, tms_sanspe, tms_indiv, 'tms', False,
                 'BCE(PRERNA)', 'BCE(SansPE)', 'BCE(Indiv)',
                 numpy.arange(0.2, 0.7, 0.1), numpy.arange(0.2, 0.7, 0.4),
                 (0.35, 0.6), (0.6, 0.28))


def plot():
    plt.rcParams['axes.unicode_minus'] = False
    plt.rcParams['font.sans-serif'] = "Arial"
    plt.rcParams['font.family'] = "sans-serif"
    fig, axs = plt.subplots(2, 4, figsize=(16, 8))
    for ax in numpy.ravel(axs):
        ax.set_aspect('equal', 'box')

    make_rt_subplots(axs[0])
    make_acc_subplots(axs[1])

    fig.text(0.26, 0.98, "SRC", fontweight='bold', ha='center', va='center', fontsize=lfont_size)
    fig.text(0.76, 0.98, "SPC", fontweight='bold', ha='center', va='center', fontsize=lfont_size)

    fig.text(0.01, 0.94, "A", fontweight='bold', ha='left', va='center', fontsize=lfont_size)
    fig.text(0.25, 0.94, "B", fontweight='bold', ha='left', va='center', fontsize=lfont_size)
    fig.text(0.52, 0.94, "C", fontweight='bold', ha='left', va='center', fontsize=lfont_size)
    fig.text(0.75, 0.94, "D", fontweight='bold', ha='left', va='center', fontsize=lfont_size)

    fig.text(0.01, 0.475, "E", fontweight='bold', ha='left', va='center', fontsize=lfont_size)
    fig.text(0.25, 0.475, "F", fontweight='bold', ha='left', va='center', fontsize=lfont_size)
    fig.text(0.52, 0.475, "G", fontweight='bold', ha='left', va='center', fontsize=lfont_size)
    fig.text(0.75, 0.475, "H", fontweight='bold', ha='left', va='center', fontsize=lfont_size)

    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.savefig(project_dir + 'aistats_figures/plots/embeddings_improve_predictions2.png', dpi=400)
    # plt.show()


if __name__ == '__main__':
    plot()
