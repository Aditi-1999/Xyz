from aistats_figures import acc_file, get_sub_metrics, color, data_dir, p_text
from utils_processing.metrics import compute_robust_corr
from matplotlib.axes import Axes
import matplotlib.pyplot as plt
from config import project_dir
import pandas
import numpy

point_size = 250
font_size = 15


def get_acc_metrics(acc_fname, experiment):
    values = acc_file(acc_fname)
    auroc = get_sub_metrics(values, experiment=experiment, metric='acc', measure='auroc', shuffled=False)
    auroc.name = 'auroc'
    bce = get_sub_metrics(values, experiment=experiment, metric='acc', measure='bce', shuffled=False)
    bce.name = 'bce'
    return pandas.DataFrame([auroc, bce]).transpose()


def get_all_acc_metrics(experiment):
    bisann = get_acc_metrics(data_dir + experiment + '/bisann_acc.pkl', experiment=experiment)
    sanspe = get_acc_metrics(data_dir + experiment + '/sanspe_acc.pkl', experiment=experiment)
    median = get_acc_metrics(data_dir + experiment + '/median_acc.pkl', experiment=experiment)
    dist = pandas.read_pickle(data_dir + experiment + '/bisann_l2dist_acc.pkl')
    dist['sp_delta'] = bisann['bce'] - sanspe['bce']
    dist['me_delta'] = bisann['bce'] - median['bce']
    return dist


def plot():
    plt.rcParams['axes.unicode_minus'] = False
    plt.rcParams['font.sans-serif'] = "Arial"
    plt.rcParams['font.family'] = "sans-serif"
    fig, ax = plt.subplots(1, 1, figsize=(6.5, 6.5))

    dist = get_all_acc_metrics(experiment='srm')

    text_pos = (0.35, -0.2)
    xrange = [0.3, 1.7]
    yrange = [-0.25, 0.05]
    ylabel = r'BCE($\bf{With}$ Embeddings) - BCE($\bf{Control}$)'
    xticks = numpy.arange(0.3, 1.7, 0.4)
    yticks = numpy.arange(-0.25, 0.05, 0.1)

    ax.scatter(x=dist['l2_median'], y=dist['sp_delta'], alpha=0.7,
               color=color['srm'], marker='o', s=point_size,
               label=r'$\bf{Without}$ Embeddings')
    ax.scatter(x=dist['l2_median'], y=dist['me_delta'],
               color=color['srm'], marker='o', s=point_size, facecolor='white',
               label=r'$\bf{Median}$' + ' ' + r'$\bf{Replace}$')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.set_xlim(*xrange)
    ax.set_ylim(*yrange)
    ax.set_xlabel('L2 Distance from Median Embedding', fontsize=font_size)
    ax.set_ylabel(ylabel, fontsize=font_size)
    ax.set_xticks(xticks)
    ax.set_yticks(yticks)
    for tick in ax.get_xticklabels() + ax.get_yticklabels():
        tick.set_fontsize(font_size)

    corr = compute_robust_corr(dist, 'l2_median', 'sp_delta')
    sp_corr = corr['corr']
    sp_val = p_text(corr['pval'])
    corr = compute_robust_corr(dist, 'l2_median', 'me_delta')
    me_corr = corr['corr']
    me_pval = p_text(corr['pval'])

    text = f'R.Corr(' + r'$\bf{Without}$ Embeddings' + f') = {sp_corr:.3f}***\n' \
           f'R.Corr(' + r'$\bf{Median}$' + ' ' + r'$\bf{Replace}$' + f') = {me_corr:.3f}***'
    ax.text(*text_pos, s=text, ha='left', va='center', fontsize=16)

    legend = fig.legend(loc='upper right', bbox_to_anchor=(1, 1), ncol=1, title_fontsize=font_size,
                        borderaxespad=0, bbox_transform=fig.transFigure)
    for legend_text in legend.get_texts():
        legend_text.set_fontsize(font_size)

    plt.tight_layout(rect=[0, 0, 1, 1])
    plt.savefig(project_dir + 'generic/atypical_embeddings_pmrf.png', dpi=400)


if __name__ == '__main__':
    plot()
