import pandas
import numpy
import plotly.express as px
from basic.analysis.model_choose import get_best_trials_for_block
from tqdm import tqdm
from utils_data import num_subjects, colours
from utils_data.msc_eda import get_probed_side_mscs
from utils_processing.metrics import compute_robust_corr, p_val_text, distances, cosine_dist

seed_list = [0, 10, 20]
bs = 64
num_epochs = 100

cols = list(map(lambda x: f'x{x}', range(1, 6)))
distance_cols = {
    'l2_median': 'L2 Distance from Median',
    # 'cos_median': 'Cosine Distance from Median',  # Worse correlations than cos_mean always
    # 'l2_mean': 'L2 Distance from Mean',  # Worse correlations than l2_median always
    # 'cos_mean': 'Cosine Distance from Mean',  # Worse than l2_median (in terms of p)
}


def get_prop_mscs(deg_window, start, end) -> pandas.DataFrame:
    """Prop(MScs) made towards the probed side across all conditions"""
    msc_df = get_probed_side_mscs(deg_window, start, end)
    msc_df['valid_count'] = msc_df.valid_phis.apply(len)
    msc_df['probed_count'] = msc_df.probed_phis.apply(len)
    msc_df = msc_df.groupby(['sub_num', 'gain_block_num']) \
        .agg({'valid_count': 'sum', 'probed_count': 'sum'}) \
        .reset_index()
    msc_df['prop_mscs'] = msc_df['probed_count'] / msc_df['valid_count']
    msc_df = msc_df.groupby('sub_num').prop_mscs.mean().reset_index()
    return msc_df


def get_se_distances(model_class, trials) -> pandas.DataFrame:
    subj_dfs = []
    for idx, row in tqdm(trials.iterrows()):
        trial = row.to_dict()
        actual_model = model_class.load_from_checkpoint(trial['folder_path'] + 'best.ckpt')
        subj_embed = numpy.array(actual_model.embeddings['sub_embedding'].weight.tolist())
        df_subj = pandas.DataFrame(subj_embed, columns=cols)
        df_subj['sub_num'] = list(range(num_subjects))
        df_subj['seed'] = trial['seed']
        df_subj['btest'] = trial['btest']

        median = numpy.median(subj_embed, axis=0)
        mean = numpy.mean(subj_embed, axis=0)

        df_subj['l2_median'] = distances(subj_embed, median, 2)
        df_subj['cos_median'] = cosine_dist(subj_embed, median)
        df_subj['l2_mean'] = distances(subj_embed, mean, 2)
        df_subj['cos_mean'] = cosine_dist(subj_embed, mean)

        subj_dfs.append(df_subj)

    subj_df = pandas.concat(subj_dfs, ignore_index=True)
    subj_distances = subj_df.groupby(['sub_num']).mean()[list(distance_cols.keys())].reset_index()
    return subj_distances


def se_msc(model_class, prefix):
    trials = get_best_trials_for_block(seed_list, prefix, bs, num_epochs, metric='acc')
    subj_distances = get_se_distances(model_class, trials)

    end = 450
    for deg_window in [30, 45, 60, 90]:
        for start in [250, 100]:
            msc_df = get_prop_mscs(deg_window, start, end)

            # Merge information
            prop_mscs = msc_df.set_index('sub_num').prop_mscs.to_dict()
            subj_distances['prop_mscs'] = subj_distances.apply(lambda row: prop_mscs.get(row.sub_num), axis=1)

            # Plot figures
            for dist_col, dist_name in distance_cols.items():
                rcorr = compute_robust_corr(subj_distances, 'prop_mscs', dist_col, 'greater')

                fig = px.scatter(subj_distances, x='prop_mscs', y=dist_col,
                                 title=f'Acc Embeddings: R.Corr = {rcorr["corr"]:.3f}; {p_val_text(rcorr["pval"])} for R.Corr > 0')
                fig.update_layout(font_size=12, title=dict(xanchor='center', x=0.5), width=800, height=600)
                fig.update_xaxes(title_text=f'Prop(MScs) within {2 * deg_window}° window around Probed Side [{start}, {end}] '
                                            f'ms after Probe Onset',
                                 range=[-0.1, 1.1])
                fig.update_yaxes(title_text=dist_name)
                fig.show()


if __name__ == '__main__':
    from models.final import OnlyAccWithHistoryBasicFinal
    se_msc(OnlyAccWithHistoryBasicFinal, 'sans_block')
