import numpy
import pandas
from numpy import pi
from config import data_dir
from utils_data import num_subjects
import plotly.graph_objects as go
import plotly.express as px
from typing import Union
from utils_data.helper import probed_side, true_reward, get_actual_trial_type, get_perc_trial_type, custom_t_test, \
    get_stimulus_category
from utils_processing.metrics import get_ttest_wilcoxon_text, p_val_text
from plotly.subplots import make_subplots


def extract_valid_phis(trial: Union[pandas.Series, dict], tmin: int, tmax: int):
    trial_phis = trial['phis']
    trial_starts = trial['starts']
    trial_amps = trial['amps']

    if type(trial_phis) is float and numpy.isnan(trial_phis):
        return []

    assert trial_phis.shape == trial_starts.shape
    assert trial_phis.shape == trial_amps.shape
    in_range_starts = list(map(lambda x: tmin <= x <= tmax, trial_starts))
    non_nan_phis = list(map(lambda x: ~numpy.isnan(x), trial_phis))
    less_amps = list(map(lambda x: x <= 1, trial_amps))
    validity_filter = list(map(lambda s, p, a: s and p and a, in_range_starts, non_nan_phis, less_amps))
    valid_phis = numpy.array(trial_phis)[numpy.array(validity_filter)]
    return list(valid_phis)


def phi_side_filter(side, window):
    def app_side_filter(x):
        if side == 'VR':
            return (-pi < x < (-pi + window)) or ((pi - window) < x < pi)
        elif side == 'FX':
            return -window < x < window
        else:
            raise Exception('Unknown Side')
    return app_side_filter


def filter_phis_window(trial, window):
    valid_phis = trial['valid_phis']
    if not valid_phis:
        return []

    if trial['side_probed'] == 1:
        side_filter = phi_side_filter('VR', window)
    elif trial['side_probed'] == 0:
        side_filter = phi_side_filter('FX', window)
    else:
        raise Exception()

    in_range_phis = list(map(side_filter, valid_phis))
    final_phis = numpy.array(valid_phis)[numpy.array(in_range_phis)]
    return list(final_phis)


def reproduce_ankita_plot():
    tmin, tmax = 450, 650
    bin_fraction = 12
    bins = numpy.linspace(-pi, pi, num=2 * bin_fraction + 1)  # make bins of size pi/bin_fraction
    widths = numpy.diff(bins)

    msc_data = numpy.load(data_dir + 'all_d_msc.npz', allow_pickle=True)['msc_data']

    for isVRProbed in [True, False]:
        for isVRgtFX in [True, False]:

            areas, radii = [], []
            for sub_num in range(num_subjects):
                sub_data = msc_data[sub_num, :, :]
                trial_cond = (sub_data[:, 2] == isVRProbed) & (sub_data[:, 1] == isVRgtFX)

                cond_phis = sub_data[trial_cond, 3]
                cond_starts = sub_data[trial_cond, 4]
                cond_amps = sub_data[trial_cond, 5]

                final_phis = []
                for phis, starts, amps in zip(cond_phis, cond_starts, cond_amps):
                    trial = {
                        'phis': phis,
                        'starts': starts,
                        'amps': amps,
                    }
                    final_trial_phis = extract_valid_phis(trial, tmin, tmax)
                    final_phis.extend(final_trial_phis)

                n, _ = numpy.histogram(final_phis, bins=bins)
                radius = n / (n.sum() * numpy.pi / bin_fraction)  # pdf defined by Matlab
                radii.append(radius)

            avg_radius = numpy.array(radii).mean(axis=0)

            fig = go.Figure(go.Barpolar(
                r=avg_radius,
                theta0=-pi + pi / (2 * bin_fraction),
                dtheta=pi / bin_fraction,
                thetaunit='radians',
                width=widths,
            ))
            fig.update_layout(
                title_text=f'{"VR" if isVRProbed else "FX"} probed & VR {">" if isVRgtFX else "<"} FX',
                template=None,
                height=400, width=400,
                margin=dict(l=40, r=20, t=50, b=20),
                polar=dict(
                    radialaxis=dict(range=[0, 1.1]),
                    angularaxis=dict(tickmode='auto', nticks=bin_fraction + 1)
                )
            )
            fig.show(config={
                'toImageButtonOptions': {
                    'format': 'png',
                    'scale': 2,
                }
            })


def get_probed_side_mscs(deg_window, start, end) -> pandas.DataFrame:
    """Valid MScs and MScs made towards probed side for each trial"""
    msc_df = pandas.read_pickle(data_dir + f'gain_d_msc.pkl')
    tmin, tmax = 200 + start, 200 + end
    window = deg_window * pi / 180
    msc_df['valid_phis'] = msc_df.apply(lambda trial: extract_valid_phis(trial, tmin, tmax), axis=1)
    msc_df['probed_phis'] = msc_df.apply(lambda trial: filter_phis_window(trial, window), axis=1)
    return msc_df


def get_msc_trial_histogram(deg_window=30, start=250, end=450):
    """
    Histogram of number of trials in which either zero or more than zero MScs have happened towards the probed side.
    Pooled across probed sides = VR & FX
    """
    msc_df = get_probed_side_mscs(deg_window, start, end)
    msc_df['probed_count'] = msc_df.probed_phis.apply(len)
    msc_df['xs'] = msc_df.probed_count.apply(lambda x: '0' if x == 0 else '>0')
    counts = msc_df.groupby(['sub_num', 'xs']).probed_count.count()

    for sub_num in range(num_subjects):
        if (sub_num, '>0') not in counts:
            counts.loc[sub_num, '>0'] = 0
        if (sub_num, '0') not in counts:
            counts.loc[sub_num, '0'] = 0
        total_trials = counts.loc[sub_num, :].sum()
        counts.loc[sub_num, '0'] /= total_trials
        counts.loc[sub_num, '>0'] /= total_trials

    counts = counts.reset_index()
    avged = counts.groupby('xs').probed_count.mean().reset_index()
    fig = px.bar(avged, x='xs', y='probed_count', text_auto='.3f',
                 labels={'xs': f'Num(MScs) within {2 * deg_window}° window around<br>Probed Side [{start}, {end}] ms '
                               f'after<br>Probe Onset in a Trial',
                         'probed_count': 'Prop(Trials) (Avged across Subjects)'})
    fig.update_traces(textposition="outside")
    fig.update_layout(width=400, height=600)
    fig.show()


def get_merged_data_mscs(deg_window, start, end):
    data_df = pandas.read_json(data_dir + f'gain_d_data.json', orient='columns')
    data_df = data_df[pandas.notna(data_df.accuracy)].copy()

    msc_df = get_probed_side_mscs(deg_window, start, end)
    msc_df['msc_in_probed'] = msc_df.probed_phis.apply(lambda x: '>0' if len(x) > 0 else '0')
    msc_df.set_index(['sub_num', 'gain_block_num', 'trial_num'], inplace=True)
    msc_in_probed = msc_df.msc_in_probed.to_dict()

    data_df['msc_in_probed'] = data_df.apply(
        lambda row: msc_in_probed.get((row.sub_num, row.gain_block_num, row.trial_num)), axis=1)
    data_df.dropna(subset=['msc_in_probed'], axis=0, inplace=True)
    return data_df


def participant_trial_histogram(deg_window=30, start=250, end=450):
    data_df = get_merged_data_mscs(deg_window, start, end)
    trial_counts = data_df.query(f'msc_in_probed == ">0"').groupby('sub_num').trial_num.count()
    for sub_num in range(num_subjects):
        if sub_num not in trial_counts.index:
            trial_counts.loc[sub_num] = 0
    trial_counts.sort_index(inplace=True)
    trial_counts = trial_counts.reset_index()

    fig = go.Figure()
    fig.add_trace(go.Bar(x=trial_counts.sub_num, y=trial_counts.trial_num,
                         text=trial_counts.trial_num, textposition='outside'))
    fig.add_hline(y=10, line_width=3, line_dash="dash", line_color="red")
    fig.update_xaxes(dtick=1, title='Participant ID')
    fig.update_yaxes(title='Number of trials with at least one MSc')
    fig.update_layout(font_size=15, width=1000, height=600)
    fig.show()


def msc_metric_overall(metric, metric_name, direction,
                       bar_py, metric_range, scatter_px, scatter_py,
                       deg_window, start, end, cutoff,
                       ):
    assert direction in ['greater', 'less']
    data_df = get_merged_data_mscs(deg_window, start, end)

    # if metric == 'response_time':
    #     data_df = data_df[data_df.accuracy == 0].copy()

    # Exclude a participant from analysis if they have less than cutoff trials with at least one MSc
    trial_counts = data_df.query(f'msc_in_probed == ">0"').groupby('sub_num').trial_num.count().to_dict()
    exclude_subjects = [sub_num for sub_num in range(num_subjects) if trial_counts.get(sub_num, 0) < cutoff]
    data_df = data_df[~data_df.sub_num.isin(exclude_subjects)].copy()

    sub_metric_df = data_df.groupby(['sub_num', 'msc_in_probed'])[metric].mean().reset_index()
    metric_df = sub_metric_df.groupby('msc_in_probed')[metric].mean().reset_index()

    # Statistical Tests
    text = get_ttest_wilcoxon_text(
        x=sub_metric_df.query(f'msc_in_probed == "0"')[metric],
        y=sub_metric_df.query(f'msc_in_probed == ">0"')[metric],
        direction=direction,
    )
    custom_p = custom_t_test(
        x=data_df.query(f'msc_in_probed == "0"'),
        y=data_df.query(f'msc_in_probed == ">0"'),
        direction=direction,
        metric=metric,
    )
    text = text + f'<br>{p_val_text(custom_p)}; Custom t-test'
    symbol = '>' if direction == 'greater' else '<'
    annotation = f'"0" {symbol} ">0"<br>{text}'

    # Plot as Bar Graph
    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=metric_df['msc_in_probed'], y=metric_df[metric], showlegend=False,
        text=metric_df[metric].round(3), textposition='outside',
    ))
    fig.add_annotation(x=0.5, y=bar_py, showarrow=False, text=annotation)
    for sub_num in range(num_subjects):
        sub_df = sub_metric_df.query(f'sub_num == {sub_num}')
        fig.add_trace(go.Scatter(x=sub_df['msc_in_probed'], y=sub_df[metric], mode='lines+markers',
                                 marker=dict(color='red'), opacity=0.3,
                                 name=f'{sub_num}',
                                 # showlegend=False,
                                 ))
    fig.update_layout(font_size=12, width=400, height=600,
                      title_text=f'Num Trials With MSc >= {cutoff} ; Excluded {exclude_subjects}')
    fig.update_xaxes(title_text=f'Num(MScs) within {2 * deg_window}° window around<br>Probed Side [{start}, {end}] ms '
                                f'after Probe Onset<br>In Current Trial')
    fig.update_yaxes(title_text=f'Participant {metric_name} In Current Trial', range=metric_range)
    fig.show()

    # Plot as Scatter
    sub_metric_pivot = sub_metric_df.pivot(index='sub_num', columns='msc_in_probed', values=metric).reset_index()
    fig = px.scatter(sub_metric_pivot, x='0', y='>0', text='sub_num',
                     labels={
                         '0': f'{metric_name} when Num(MScs) = 0',
                         '>0': f'{metric_name} when Num(MScs) > 0'
                     },
                     title=f'Num(MScs) within {2 * deg_window}° window around Probed Side [{start}, {end}] ms '
                           f'after<br>Probe Onset In Current Trial')
    fig.add_annotation(x=scatter_px, y=scatter_py, showarrow=False, text=annotation)
    fig.update_traces(textposition='top center')
    fig.add_trace(go.Scatter(
        x=metric_range, y=metric_range, mode='lines', line=dict(color='red'), showlegend=False))
    fig.update_layout(xaxis_range=metric_range, yaxis_range=metric_range,
                      title=dict(xanchor='center', x=0.5),
                      width=900, height=800, font_size=15)
    fig.show()


def exclude_less_trial_subjects(data_df, variable, cutoff):
    exclude_subjects = []
    check_subjects: dict = data_df.groupby(['sub_num', variable, 'msc_in_probed']).trial_num.count().to_dict()
    for sub_num in range(num_subjects):
        for var in data_df[variable].unique():
            num_trials_with_atleast_one_msc = check_subjects.get((sub_num, var, '>0'), 0)
            if num_trials_with_atleast_one_msc < cutoff:
                exclude_subjects.append(sub_num)
    exclude_subjects = list(set(exclude_subjects))
    data_df = data_df.query(f'sub_num not in {exclude_subjects}').copy()
    return data_df, exclude_subjects


def condition_subplots(data_df, variable, left, right, deg_window, start, end, exclude_subjects, column_titles, cutoff, title_suff=''):
    sub_accuracies = data_df.groupby(['sub_num', variable, 'msc_in_probed']).accuracy.mean().reset_index()
    sub_accuracies['msc_in_probed'] = sub_accuracies.msc_in_probed.apply(lambda t: 'Num(MScs) = 0' if t == '0' else 'Num(MScs) > 0')
    sub_left = sub_accuracies[sub_accuracies[variable] == left]
    sub_right = sub_accuracies[sub_accuracies[variable] == right]
    condition_means = sub_accuracies.groupby([variable, 'msc_in_probed']).accuracy.mean().reset_index()
    left_means = condition_means[condition_means[variable] == left]
    right_means = condition_means[condition_means[variable] == right]

    x_title = f'Num(MScs) within {2 * deg_window}° window around<br>Probed Side [{start}, {end}] ms ' \
              f'after Probe Onset In Current Trial'
    fig = make_subplots(
        1, 2, shared_yaxes=True,
        x_title=x_title, y_title='Participant Accuracy In Current Trial',
        column_titles=column_titles,
    )

    fig.add_trace(go.Bar(
        x=left_means.msc_in_probed, y=left_means.accuracy,
        marker=dict(color=['green', 'blue'], opacity=0.6), showlegend=False,
        text=left_means.accuracy.round(3), textposition='outside',
    ), row=1, col=1)

    fig.add_trace(go.Bar(
        x=right_means.msc_in_probed, y=right_means.accuracy,
        marker=dict(color=['green', 'blue'], opacity=0.6), showlegend=False,
        text=right_means.accuracy.round(3), textposition='outside',
    ), row=1, col=2)

    for c, subs in enumerate([sub_left, sub_right]):
        text = get_ttest_wilcoxon_text(
            x=subs.query(f'msc_in_probed == "Num(MScs) = 0"').accuracy,
            y=subs.query(f'msc_in_probed == "Num(MScs) > 0"').accuracy,
            direction='greater',
        )
        fig.add_annotation(x=0.5, y=1, showarrow=False, text=f'"0" > ">0"<br>{text}', row=1, col=c + 1)
        for sub_num in sub_accuracies.sub_num.unique():
            single = subs.query(f'sub_num == {sub_num}')
            fig.add_trace(go.Scatter(
                x=single.msc_in_probed, y=single.accuracy, mode='lines+markers',
                marker=dict(color='red'), opacity=0.3,
                showlegend=False,
                # showlegend=False if c == 0 else True,
                # name=f'{sub_num}', legendgroup=f'{sub_num}',
            ), row=1, col=c + 1)

    fig.update_layout(font_size=14, width=800, height=600,
                      title_text=f'Excluded {exclude_subjects}')
    fig.update_yaxes(range=[0.2, 1.1])

    fig.show()


def msc_acc_probed_side(deg_window=30, start=250, end=450):
    data_df = get_merged_data_mscs(deg_window, start, end)
    data_df['side_probed'] = data_df['side_probed'].apply(probed_side)
    data_df, exclude_subjects = exclude_less_trial_subjects(data_df, 'side_probed')
    condition_subplots(data_df, 'side_probed', 'FX', 'VR', deg_window, start, end, exclude_subjects,
                       column_titles=['Current Probed Side = FX', 'Current Probed Side = VR'])


def msc_acc_reward_contingency(deg_window=30, start=250, end=450):
    data_df = get_merged_data_mscs(deg_window, start, end)
    data_df['reward_vr_fx'] = data_df['reward_vr_fx'].apply(true_reward)
    data_df, exclude_subjects = exclude_less_trial_subjects(data_df, 'reward_vr_fx')
    condition_subplots(data_df, 'reward_vr_fx', 'VR<FX', 'VR>FX', deg_window, start, end, exclude_subjects,
                       column_titles=['Reward @ VR < FX', 'Reward @ VR > FX'])


def msc_acc_attended(deg_window=30, start=250, end=450):
    data_df = get_merged_data_mscs(deg_window, start, end)
    data_df['att'] = data_df.apply(get_actual_trial_type, axis=1)
    data_df, exclude_subjects = exclude_less_trial_subjects(data_df, 'att')
    condition_subplots(data_df, 'att', 'invalid', 'valid', deg_window, start, end, exclude_subjects,
                       column_titles=['True Invalid', 'True Valid'])


def msc_acc_perc_attended(deg_window=30, start=250, end=450, cutoff=1):
    data_df = get_merged_data_mscs(deg_window, start, end)
    data_df['ptt'] = data_df.apply(get_perc_trial_type, axis=1)
    data_df.dropna(subset=['ptt'], inplace=True)
    data_df, exclude_subjects = exclude_less_trial_subjects(data_df, 'ptt', cutoff)
    condition_subplots(data_df, 'ptt', 'invalid', 'valid', deg_window, start, end, exclude_subjects,
                       column_titles=['Perceived Invalid', 'Perceived Valid'])


def msc_acc_prev_probed_side(deg_window=30, start=250, end=450, cutoff=1):
    """Assess if the probed side is same as previous trial's probed side, are the participants less accurate."""
    data_df = get_merged_data_mscs(deg_window, start, end)
    data_df['side_probed'] = data_df['side_probed'].apply(probed_side)
    probed_sides = data_df.set_index(['sub_num', 'gain_block_num', 'trial_num']).side_probed.to_dict()
    data_df['prev_side_probed'] = data_df.apply(
        lambda row: probed_sides.get((row.sub_num, row.gain_block_num, row.trial_num - 1)), axis=1)
    data_df.dropna(subset=['prev_side_probed'], axis=0, inplace=True)
    data_df['same_side'] = data_df['side_probed'] == data_df['prev_side_probed']
    data_df['same_side'] = data_df['same_side'].apply(lambda s: 'Yes' if s else 'No')
    data_df, exclude_subjects = exclude_less_trial_subjects(data_df, 'same_side', cutoff)
    condition_subplots(data_df, 'same_side', 'No', 'Yes', deg_window, start, end, exclude_subjects,
                       column_titles=[
                           'Current Probed Side is<br><b>Not Same</b> as Previous Probed Side',
                           'Current Probed Side is<br><b>Same</b> as Previous Probed Side',
                       ], cutoff=cutoff)


if __name__ == '__main__':
    for degw, strt in product([30, 45, 60, 90], [250, 100]):
        msc_acc_perc_attended(degw, strt)
