from torch.nn import init, Linear, Embedding, LSTM, ModuleList, ModuleDict, MSELoss
from pytorch_lightning.utilities.seed import seed_everything
from models import choose_function, choose_init_function
from torch.optim.lr_scheduler import ExponentialLR
from pytorch_lightning import LightningModule
from abc import ABC, abstractmethod
from torch.optim import Adam
from typing import Optional
import torch
from itertools import chain
from uncertainty.models import MVETrainingPhase


class BaseModel(LightningModule, ABC):

    def __init__(self):
        super(BaseModel, self).__init__()

    @abstractmethod
    def forward(self, lstm_inp,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        ...

    @abstractmethod
    def _common_step(self, batch, btype):
        ...

    def training_step(self, batch):
        loss = self._common_step(batch, 'train')
        return loss

    def validation_step(self, batch, batch_idx):
        self._common_step(batch, 'val')

    @abstractmethod
    def predict_step(self, batch, batch_idx):
        ...


class BaseMVEModel(BaseModel, ABC):

    def __init__(self, phase: MVETrainingPhase):
        super(BaseMVEModel, self).__init__()
        self.phase = phase


class BaseMVEHistoryModel(BaseMVEModel, ABC):
    """
    Currently support only one-dim output (thus, mean and variance are one-dim)
    Any activation functions required to be added on the output to be done elsewhere
    """

    def __init__(self, phase: MVETrainingPhase,
                 rnn_input_size: int, rnn_hidden_size: int, rnn_layers: int, rnn_bidirectional: bool,
                 mean_hidden_sizes: list[int], logvar_hidden_sizes: list[int],
                 activation_func: Optional[str],  # common activation function for all hidden layers
                 mean_l2weight: float, logvar_l2weight: float,
                 num_subjects: int, num_blocks: int,
                 sub_emb_dim: int, block_emb_dim: int,
                 lr: float, exp_lr: bool, mseed: int,
                 ):
        super(BaseMVEHistoryModel, self).__init__(phase=phase)

        self.activation_func = choose_function(activation_func)

        self.lr = lr
        self.exp_lr = exp_lr
        self.mean_l2weight = mean_l2weight
        self.logvar_l2weight = logvar_l2weight

        # LSTM
        self.subject_history = LSTM(input_size=rnn_input_size, hidden_size=rnn_hidden_size, num_layers=rnn_layers,
                                    batch_first=True, bidirectional=rnn_bidirectional)

        # Embeddings
        self.embeddings = ModuleDict()
        if num_subjects > 2 and sub_emb_dim > 1:
            self.embeddings.update({'sub_embedding': Embedding(num_embeddings=num_subjects,
                                                               embedding_dim=sub_emb_dim)})
        if num_blocks > 2 and block_emb_dim > 1:
            self.embeddings.update({'block_embedding': Embedding(num_embeddings=num_blocks,
                                                                 embedding_dim=block_emb_dim)})

        # Layers to output mean and variance (one-dim)
        self.mean_internal_layers = ModuleList([])
        for i in range(1, len(mean_hidden_sizes)):
            self.mean_internal_layers.append(
                Linear(in_features=mean_hidden_sizes[i - 1], out_features=mean_hidden_sizes[i], dtype=torch.double))
        self.mean_output = Linear(in_features=mean_hidden_sizes[-1], out_features=1, dtype=torch.double)

        self.logvar_internal_layers = ModuleList([])
        for i in range(1, len(logvar_hidden_sizes)):
            self.logvar_internal_layers.append(
                Linear(in_features=logvar_hidden_sizes[i - 1], out_features=logvar_hidden_sizes[i], dtype=torch.double))
        self.logvar_output = Linear(in_features=logvar_hidden_sizes[-1], out_features=1, dtype=torch.double)
        if self.phase == MVETrainingPhase.OnlyMean:
            self.logvar_internal_layers.requires_grad_(False)
            self.logvar_output.requires_grad_(False)

        self.initialise(mseed, rnn_hidden_size)

        self.double()

    def initialise(self, model_seed, rnn_hidden_size):
        # Initialisations
        seed_everything(model_seed)

        # Initialise LSTM
        for name, param in self.subject_history.named_parameters():
            if 'weight_ih' in name:
                init.xavier_uniform_(param)
            elif 'weight_hh' in name:
                init.orthogonal_(param)
            elif 'bias_ih' in name:
                init.zeros_(param)
            elif 'bias_hh' in name:
                param.data = torch.tensor([0] * rnn_hidden_size + [1] * rnn_hidden_size + [0] * rnn_hidden_size * 2,
                                          dtype=torch.double, device=self.device)

        # Initialise Embeddings
        for embedding in self.embeddings.values():
            init.uniform_(embedding.weight, -0.05, 0.05)

        # Initialise Hidden and Output Layers
        init_function = choose_init_function(self.activation_func)
        for layer in self.mean_internal_layers + self.logvar_internal_layers:
            init_function(layer.weight)
            init.zeros_(layer.bias)
        init.xavier_uniform_(self.mean_output.weight)
        init.zeros_(self.mean_output.bias)
        init.xavier_uniform_(self.logvar_output.weight)
        init.zeros_(self.logvar_output.bias)

    def set_logvar_bias(self, logvar_bias):
        self.logvar_output.bias.data = torch.tensor(logvar_bias, dtype=torch.double, device=self.device)

    @staticmethod
    def _get_lstm_output(lstm: LSTM, lstm_inp):  # lstm_inp is of shape (N, T, E)
        """Take the last layer output"""
        _, (h, _) = lstm(lstm_inp)  # h is of shape (D*num_layers, N, H)
        if lstm.bidirectional:
            last_layer_outputs = h[-2:, :, :]
            batch_size = last_layer_outputs.shape[1]
            return last_layer_outputs.transpose(0, 1).reshape(batch_size, -1)  # (N, 2*H)
        else:
            return h[-1, :, :]  # (N, H)

    @staticmethod
    def _forward_internal_layers(op, layers, activation_func):
        for layer in layers:
            op = layer(op)
            if activation_func:
                op = activation_func(op)
        return op

    def forward(self, lstm_inp,  # (N, T, E)
                sub_emb,  # (N,)
                block_emb,  # (N,)
                ):
        concatenate_list = [
            self._get_lstm_output(self.subject_history, lstm_inp),  # (N, D*H)
        ]
        if 'sub_embedding' in self.embeddings:
            concatenate_list.append(self.embeddings['sub_embedding'](sub_emb))  # (N, Sb)
        if 'block_embedding' in self.embeddings:
            concatenate_list.append(self.embeddings['block_embedding'](block_emb))  # (N, B)
        op = torch.cat(concatenate_list, dim=1)  # (N, D*H+Sb+B)

        mean = self._forward_internal_layers(op, self.mean_internal_layers, self.activation_func)
        mean = self.mean_output(mean)

        if self.phase == MVETrainingPhase.MeanAndVar:
            logvar = self._forward_internal_layers(op, self.logvar_internal_layers, self.activation_func)
            logvar = self.logvar_output(logvar)
            var = torch.exp(logvar)
        else:
            var = torch.ones_like(mean)

        return mean, var

    def configure_optimizers(self):
        param_groups = [
            {
                'params': chain(self.subject_history.parameters(), self.embeddings.parameters())
            },
            {
                'params': chain(self.mean_internal_layers.parameters(), self.mean_output.parameters()),
                'weight_decay': self.mean_l2weight
            },
        ]
        if self.phase == MVETrainingPhase.MeanAndVar:
            param_groups.append({
                'params': chain(self.logvar_internal_layers.parameters(), self.logvar_output.parameters()),
                'weight_decay': self.logvar_l2weight
            })

        optimizer = Adam(param_groups, lr=self.lr)
        if self.exp_lr:
            lr_scheduler = ExponentialLR(optimizer, gamma=0.98)
            return {
                'optimizer': optimizer,
                'lr_scheduler': {
                    'scheduler': lr_scheduler,
                    'interval': 'epoch',
                    'frequency': 1,
                    'name': 'exp_lr',
                },
            }
        else:
            return optimizer


class BaseMVERTModel(BaseMVEModel, ABC):

    metric = 'rt'

    def _common_step(self, batch, btype):
        not_training = btype != 'train'
        lstm_inp, sub_emb, block_emb, rt_target = batch
        rt_pred, var = self(lstm_inp, sub_emb, block_emb)
        mse = MSELoss()(rt_pred, rt_target)
        per_sample_loss = torch.log(var) + (rt_target - rt_pred) ** 2 / var
        loss = per_sample_loss.mean()
        self.log(f'phase{self.phase.value}_{btype}/mse', mse, on_step=False, on_epoch=True, prog_bar=False, logger=True,
                 reduce_fx=torch.mean, sync_dist=not_training)
        self.log(f'phase{self.phase.value}_{btype}/loss', loss, on_step=False, on_epoch=True, prog_bar=True, logger=True,
                 reduce_fx=torch.mean, sync_dist=not_training)
        return loss

    def predict_step(self, batch, batch_idx):
        lstm_inp, sub_emb, block_emb, rt_target = batch
        rt_pred, var = self(lstm_inp, sub_emb, block_emb)
        return rt_target.cpu().numpy(), rt_pred.cpu().numpy(), var.cpu().numpy()
