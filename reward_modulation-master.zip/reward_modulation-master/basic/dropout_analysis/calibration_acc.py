import pandas
from config import project_dir
from utils_processing import seeds, mc_seeds
import plotly.express as px
from utils_data.helper import sigmoid, inverse_sigmoid
from numpy import log, log2, abs
import numpy
import plotly.graph_objs as go
from utils_data import num_gain_blocks, num_subjects
from sklearn.linear_model import LogisticRegression

pred_cols = list(map(lambda x: f'acc_pred_{x}', range(len(mc_seeds))))
trial_id = ['sub_num', 'gain_block_num', 'trial_num']


def compare_bce_variance(mc_values):
    mc_values['pred_var'] = mc_values[pred_cols].var(ddof=1, axis=1)
    mc_values['bce'] = mc_values.apply(lambda row: -log(row.acc_pred) if row.acc_target else -log(1 - row.acc_pred), axis=1)
    fig = px.scatter(mc_values, x='bce', y='pred_var',
                     marginal_x='histogram', marginal_y='histogram',
                     labels={'bce': 'BCE (Predicted Acc, Observed Acc)',
                             'pred_var': 'Variance of Predicted Acc'})
    fig.update_layout(font_size=20)
    fig.show()


def is_error(row):
    if row.acc_pred > 0.5:  # predicted is 1
        if row.acc_target == 1:
            return 0
        else:
            return 1
    if row.acc_pred < 0.5:
        if row.acc_target == 0:
            return 0
        else:
            return 1


def get_mc_values(result_dir):
    mc_values = pandas.read_pickle(result_dir)
    mc_values[pred_cols] = mc_values[pred_cols].applymap(sigmoid)
    mc_values['acc_pred'] = mc_values[pred_cols].mean(axis=1)
    mc_values['err'] = mc_values.apply(is_error, axis=1)
    return mc_values


def entropy(p):
    ent = -p * log(p) - (1-p) * log(1-p)
    return ent / log(2)


def calibration_plot(mc_values, n_bins, stage):
    mc_values = mc_values.copy()
    mc_values['uncert'] = mc_values.acc_pred.apply(entropy)

    bin_boundaries = numpy.linspace(0, 1, n_bins + 1)
    bin_lowers, bin_uppers = bin_boundaries[:-1], bin_boundaries[1:]

    bins_data = []
    for bin_lower, bin_upper in zip(bin_lowers, bin_uppers):
        in_bin = (bin_lower <= mc_values.uncert) & (mc_values.uncert <= bin_upper)
        if in_bin.sum() == 0:  # if no elements in that bin
            continue

        bin_values = mc_values[in_bin]
        proportion = in_bin.mean()
        err = bin_values.err.mean()
        uncert = bin_values.uncert.mean()
        uce = proportion * abs(err - uncert)
        bins_data.append({'err': err, 'uncert': uncert, 'uce': uce})

    bin_df = pandas.DataFrame(bins_data)
    uce = bin_df.uce.sum()
    fig = px.scatter(bin_df, x='uncert', y='err',
                     labels={'uncert': 'Mean(Uncertainty) in Bin', 'err': 'Mean(Err) in Bin'})
    axis_max = max(bin_df.err.max(), bin_df.uncert.max())
    fig.add_trace(go.Scatter(x=[0, axis_max], y=[0, axis_max], mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_layout(title=dict(text=f'{stage} - UCE = {uce:.3f}', xanchor='center', x=0.5), height=600, width=600,
                      legend=dict(yanchor='top', y=0.1, xanchor='left', x=0.85))
    fig.show()


def calibrate(mc_val_values, mc_test_values, n_bins):
    calibration_plot(mc_val_values, n_bins, stage='Validation Set - Pre-Calibration')
    calibration_plot(mc_test_values, n_bins, stage='Test Set - Pre-Calibration')

    weights = dict()
    for seed in seeds[:3]:
        for btest in range(num_gain_blocks):
            split_df = mc_val_values.query(f'seed == {seed} & btest == {btest}').copy()
            split_df[pred_cols] = split_df[pred_cols].applymap(inverse_sigmoid)  # get logits
            logits, targets = [], []
            for pred_col in pred_cols:
                logits.extend(split_df[pred_col].tolist())
                targets.extend(split_df['acc_target'].tolist())
            assert len(logits) == len(targets)
            assert len(logits) == len(split_df) * len(pred_cols)
            logits, targets = numpy.array(logits), numpy.array(targets)
            logits = logits.reshape(-1, 1)
            lr = LogisticRegression(penalty='none', fit_intercept=False, random_state=0)
            lr.fit(logits, targets)
            inv_temp = lr.coef_[0][0].item()
            assert inv_temp > 0
            weights[(seed, btest)] = inv_temp

    mc_val_values[pred_cols] = mc_val_values[pred_cols].applymap(inverse_sigmoid)
    mc_test_values[pred_cols] = mc_test_values[pred_cols].applymap(inverse_sigmoid)
    for pred_col in pred_cols:
        mc_val_values[pred_col] = mc_val_values.apply(lambda row: row[pred_col] * weights[(row.seed, row.btest)], axis=1)
        mc_test_values[pred_col] = mc_test_values.apply(lambda row: row[pred_col] * weights[(row.seed, row.btest)], axis=1)
    mc_val_values[pred_cols] = mc_val_values[pred_cols].applymap(sigmoid)
    mc_test_values[pred_cols] = mc_test_values[pred_cols].applymap(sigmoid)

    mc_val_values['acc_pred_old'] = mc_val_values['acc_pred']
    mc_test_values['acc_pred_old'] = mc_test_values['acc_pred']
    mc_val_values['acc_pred'] = mc_val_values[pred_cols].mean(axis=1)
    mc_test_values['acc_pred'] = mc_test_values[pred_cols].mean(axis=1)

    calibration_plot(mc_val_values, n_bins, stage='Validation Set - Post-Calibration')
    calibration_plot(mc_test_values, n_bins, stage='Test Set - Post-Calibration')


if __name__ == '__main__':
    dropout = 0.2
    res_dir = project_dir + 'basic/results/sans_block_bs=64_maxep=100_acc/'
    mc_test_values_df = get_mc_values(res_dir + f'mc-p={dropout}-test_values.pkl')
    mc_val_values_df = get_mc_values(res_dir + f'mc-p={dropout}-val_values.pkl')
    # compare_bce_variance(mc_test_values_df)
    # compare_bce_variance(mc_val_values_df)
    calibrate(mc_val_values_df, mc_test_values_df, 200)
