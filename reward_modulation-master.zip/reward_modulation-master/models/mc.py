from models.final import OnlyRTWithHistoryBasicFinal, OnlyAccWithHistoryBasicFinal


class OnlyRTWithHistoryBasicFinalDropout(OnlyRTWithHistoryBasicFinal):

    def __init__(self, kwargs):
        super().__init__(**kwargs)

    def predict_step(self, batch, batch_idx):
        # These two are affected by dropout
        self.dropout.train()
        self.subject_history.train()
        return super().predict_step(batch, batch_idx)


class OnlyAccWithHistoryBasicFinalDropout(OnlyAccWithHistoryBasicFinal):

    def __init__(self, kwargs):
        super().__init__(**kwargs)

    def predict_step(self, batch, batch_idx):
        # These two are affected by dropout
        self.dropout.train()
        self.subject_history.train()
        return super().predict_step(batch, batch_idx)
