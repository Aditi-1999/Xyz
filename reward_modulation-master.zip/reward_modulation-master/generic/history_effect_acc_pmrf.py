import pandas
import matplotlib.pyplot as plt
from config import project_dir
from sklearn.metrics import roc_curve, RocCurveDisplay
from utils_data.helper import sigmoid, inverse_sigmoid


def plot_rocs(values_df):
    values_df = values_df[values_df.sub_emb == 0].copy()  # important
    values_df['sub_emb'] = values_df.sub_emb.apply(int).apply(str)
    values_df['block_emb'] = values_df.block_emb.apply(int).apply(str)

    values_df['acc_pred'] = values_df.acc_pred.apply(sigmoid)
    values_df = values_df.groupby(['sub_emb', 'block_emb', 'trial_num']) \
        .agg({'acc_target': 'mean', 'acc_pred': 'mean'})\
        .reset_index()
    values_df['acc_pred'] = values_df.acc_pred.apply(inverse_sigmoid)

    fprs, tprs = roc_curve(values_df['acc_target'], values_df['acc_pred'])[:2]

    plt.rcParams['axes.unicode_minus'] = False
    plt.rcParams['font.sans-serif'] = "Arial"
    plt.rcParams['font.family'] = "sans-serif"
    fig, ax = plt.subplots(1, 1, figsize=(5, 5))

    ax.plot([0, 1], [0, 1], color='black', linestyle='--', label='Chance-Level')
    viz = RocCurveDisplay(fpr=fprs, tpr=tprs, estimator_name='ROC')
    viz.plot(ax=ax)

    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.legend(loc="upper left")
    fig.suptitle('Receiver Operating Curve (ROC) for Accuracy predictions\nfor an Exemplar Participant')

    plt.savefig(project_dir + 'generic/roc_curve.png', dpi=400)

    ax.fill_between(fprs, tprs, alpha=0.2, color='blue')
    plt.savefig(project_dir + 'generic/roc_curve_filled.png', dpi=400)


if __name__ == '__main__':
    result_folder = project_dir + f'basic/results/sans_block_bs=64_maxep=100_acc/'
    values = pandas.read_pickle(result_folder + 'overall-values.pkl')
    plot_rocs(values)
