rt_subjects = [13, 5, 10, 2, 8, 14]
acc_subjects = [5, 13, 3, 8, 18, 6]

optuna_storage = "mysql://root:password@localhost/RewardModulationSubjWise"
