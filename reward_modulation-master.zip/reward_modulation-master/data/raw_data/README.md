**Types of modulation:**
- spatial reward modulation = d' modulation 
- response reward modulation = cc modulation


**Data table format:**

| Column | Column Info                                                                                                |
|:------:|------------------------------------------------------------------------------------------------------------|
| Col_01 | TRIAL NUMBER                                                                                               |
| Col_02 | HEMIFIELD PROBES: (-1) left probed, (1) right probed                                                       |
| Col_03 | REWARD for the Left hemifield/stimulus in each trial:                                                      | 
|        | (-6) FIXED loss, (+6) VARIABLE loss, (-3) FIXED gain, (+3) VARIABLE gain                                   | 
|        | (-1): fixed (FX) and 1: variable (VR) stimulus and                                                         | 
|        | (6): loss, (3): gain block                                                                                 |
| Col_04 | REWARD PROBES: (0) FX, (1) VR contingency1, (2) VR contingency2                                            |
| Col_05 | CHANGE FLAG LEFT hemifield: (0) no change, (1) change                                                      |
| Col_06 | CHANGE FLAG RIGHT hemifield: (0) no change, (1) change                                                     |
| Col_07 | CONTINGENCY type in a trial (determined by the VR contingency): (1) VR1, (2) VR2 (--- always fixed for FX) |
| Col_08 | STIM + CUE DISPLAY DURATION - ignore - erroneous (use t_cuestimulus)                                       |
| Col_09 | RESPONSE KEY: (0) no change, (1) change, (5) response missing                                              |

t_cuestimulus = cue+stimulus time in seconds

t_response = response time in seconds (NaN for response missing)

trial_score = score for each trial and internal mapping based on starting from 360 (-15 for response missing)

Max score magnitude per block = 360 

**Contingency Structure: [hit, miss, fa, cr]**

_spatial reward modulation task_

- FX contingency = [ 7.5, 0, 0, 7.5] or [ 0, -7.5, -7.5, 0]
- VR contingency 1 = [12.5, 0, 0,12.5] or [ 0,-12.5,-12.5, 0] (expected: VR d' > FX d': High VR condition)
- VR contingency 2 = [ 2.5, 0, 0, 2.5] or [ 0, -2.5, -2.5, 0] (expected: VR d' < FX d': Low VR Condition)

_response reward modulation task_ 

- FX contingency = [ 7.5, 0, 0, 7.5] or [ 0, -7.5, -7.5, 0]
- VR contingency 1 = [12.5, 0, 0, 2.5] or [ 0,-12.5,-2.5, 0] (expected: VR Y>N: Liberal VR condition)
- VR contingency 2 = [ 2.5, 0, 0, 12.5] or [ 0, -2.5, -12.5, 0] (expected: VR Y<N: Conservative VR Condition)


EyeTracking - Any row with all NaNs is rejected for ET reasons 

# spatial_msc_vrfx.mat

1. x locations are in relation to VR and FX: VR on the left and FX on the right 
2. NaNs are trials rejected in ET
3. Amplitude = gaze movement distance (in pixels)
4. Phi = direction in radians 
5. Times are all from -200 of probe onset

- GL: 1 - gain, 2 - loss
