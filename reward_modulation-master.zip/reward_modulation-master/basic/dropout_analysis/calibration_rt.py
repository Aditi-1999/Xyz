import pandas
from config import project_dir
from utils_processing import seeds, mc_seeds
import plotly.express as px
from numpy import sqrt, abs
import numpy
import plotly.graph_objs as go
from utils_data import num_gain_blocks, num_subjects

pred_cols = list(map(lambda x: f'rt_pred_{x}', range(len(mc_seeds))))
trial_id = ['sub_num', 'gain_block_num', 'trial_num']


def get_mc_values(result_dir):
    mc_values: pandas.DataFrame = pandas.read_pickle(result_dir)
    mc_values['rt_pred'] = mc_values[pred_cols].mean(axis=1)
    mc_values['pred_var'] = mc_values[pred_cols].var(ddof=1, axis=1)
    mc_values['mse'] = (mc_values['rt_pred'] - mc_values['rt_target']) ** 2
    return mc_values


def get_uce_df(mc_values, n_bins):
    bin_boundaries = numpy.linspace(mc_values.pred_var.min(), mc_values.pred_var.max(), n_bins + 1)
    bin_lowers, bin_uppers = bin_boundaries[:-1], bin_boundaries[1:]

    bins_data = []
    for bin_lower, bin_upper in zip(bin_lowers, bin_uppers):
        in_bin = (bin_lower <= mc_values.pred_var) & (mc_values.pred_var <= bin_upper)
        if in_bin.sum() == 0:  # if no elements in that bin
            continue

        bin_values = mc_values[in_bin]
        proportion = in_bin.mean()
        err = bin_values.mse.mean()
        uncert = bin_values.pred_var.mean()
        uce = proportion * abs(err - uncert)
        bins_data.append({'err': err, 'uncert': uncert, 'uce': uce})

    bin_df = pandas.DataFrame(bins_data)
    return bin_df


def compare_mse_variance(mc_values):
    mc_values['sqrt_mse'] = mc_values.mse.apply(sqrt)
    mc_values['pred_std'] = mc_values.pred_var.apply(sqrt)

    fig = px.scatter(mc_values, x='sqrt_mse', y='pred_std',
                     marginal_x='histogram', marginal_y='histogram',
                     labels={'sqrt_mse': 'Sqrt of MSE (Predicted RT, Observed RT)',
                             'pred_std': 'Standard Deviation of Predicted RT'})
    fig.update_layout(font_size=20)
    fig.show()


def calibration_plot(mc_values, n_bins, stage):
    bin_df = get_uce_df(mc_values, n_bins)
    uce = bin_df.uce.sum()
    fig = px.scatter(bin_df, x='uncert', y='err',
                     labels={'uncert': 'Mean(Variance) in Bin', 'err': 'Mean(MSE) in Bin'})
    axis_max = max(bin_df.err.max(), bin_df.uncert.max())
    fig.add_trace(go.Scatter(x=[0, axis_max], y=[0, axis_max], mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_layout(title=dict(text=f'{stage} - UCE = {uce:.3f}', xanchor='center', x=0.5), height=600, width=600,
                      legend=dict(yanchor='top', y=0.1, xanchor='left', x=0.85))
    fig.show()


def calibrate(mc_val_values, mc_test_values, n_bins):
    calibration_plot(mc_val_values, n_bins, stage='Validation Set - Pre-Calibration')
    calibration_plot(mc_test_values, n_bins, stage='Test Set - Pre-Calibration')

    s_sqs = dict()
    for seed in seeds[:3]:
        for btest in range(num_gain_blocks):
            split_df = mc_val_values.query(f'seed == {seed} & btest == {btest}').copy()
            split_df['ratio'] = split_df['mse'] / split_df['pred_var']
            s_sq = split_df['ratio'].mean()
            s_sqs[(seed, btest)] = s_sq
            # dividing learned s^2 by 4 gives least UCE of ~0.8 on val set

    mc_val_values['pred_var'] = mc_val_values.apply(lambda row: row.pred_var * s_sqs[(row.seed, row.btest)], axis=1)
    mc_test_values['pred_var'] = mc_test_values.apply(lambda row: row.pred_var * s_sqs[(row.seed, row.btest)], axis=1)

    calibration_plot(mc_val_values, n_bins, stage='Validation Set - Post-Calibration')
    calibration_plot(mc_test_values, n_bins, stage='Test Set - Post-Calibration')


if __name__ == '__main__':
    dropout = 0.2
    res_dir = project_dir + 'basic/results/sans_block_bs=64_maxep=100_rt/'
    mc_test_values_df = get_mc_values(res_dir + f'mc-p={dropout}-test_values.pkl')
    mc_val_values_df = get_mc_values(res_dir + f'mc-p={dropout}-val_values.pkl')
    compare_mse_variance(mc_test_values_df)
    compare_mse_variance(mc_val_values_df)
    calibrate(mc_val_values_df, mc_test_values_df, 50)
