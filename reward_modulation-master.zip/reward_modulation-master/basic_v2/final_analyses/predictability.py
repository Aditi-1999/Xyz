from basic_v2.final_analyses import get_sub_actual_corrs, get_sub_actual_mses, plot_subj_values, \
    get_ttest_wilcoxon_text, rt_file, acc_file, get_sub_actual_aurocs, get_sub_actual_bces
import plotly.graph_objs as go
from config import project_dir
import numpy


def compare_correlations(values_df, title):
    fig = go.Figure()
    actual_corrs = get_sub_actual_corrs(values_df)
    plot_subj_values(fig, actual_corrs, 'Actual')

    # test if x > 0.4
    test_text = get_ttest_wilcoxon_text(x=actual_corrs, y=numpy.ones_like(actual_corrs) * 0.4, direction='greater')
    fig.add_annotation(x='Actual', y=0.7, showarrow=False, text=f'Robust Correlations > 0.4 <br>{test_text}')
    fig.update_layout(width=400, height=800, font_size=15, title=dict(text=title, xanchor='center', x=0.5))
    fig.update_xaxes(title_text='History Type')
    fig.update_yaxes(title_text='Robust Correlation (Predicted RT, Observed RT)')
    fig.update_yaxes(range=[-0.2, 0.8])
    fig.show()


def compare_mses(values_df, title):
    fig = go.Figure()
    actual_mses = get_sub_actual_mses(values_df)
    plot_subj_values(fig, actual_mses, 'Actual')

    # test if x < 1
    test_text = get_ttest_wilcoxon_text(x=actual_mses, y=numpy.ones_like(actual_mses), direction='less')
    fig.add_annotation(x='Actual', y=1.7, showarrow=False, text=f'MSE < 1 <br>{test_text}')
    fig.update_layout(width=400, height=800, font_size=15, title=dict(text=title, xanchor='center', x=0.5))
    fig.update_xaxes(title_text='History Type')
    fig.update_yaxes(title_text='MSE (Predicted RT, Observed RT)')
    fig.update_yaxes(range=[0, 2])
    fig.show()


def predictability_rt():
    model_type = f'SRM - RT'
    values = rt_file(project_dir + f'basic_v2/results/sans_block_v3_bs=64_maxep=100_rt/mc-test_values.pkl')
    compare_correlations(values, model_type)
    compare_mses(values, model_type)


def compare_aurocs(values_df, title):
    fig = go.Figure()
    actual_aurocs = get_sub_actual_aurocs(values_df)
    plot_subj_values(fig, actual_aurocs, 'Actual')

    # test if x > 0.5
    test_text = get_ttest_wilcoxon_text(x=actual_aurocs, y=numpy.ones_like(actual_aurocs) * 0.5, direction='greater')
    fig.add_annotation(x='Actual', y=0.95, showarrow=False, text=f'AUROC > 0.5 <br>{test_text}')
    fig.add_hline(y=1, line_color='red')
    fig.add_hline(y=0.5, line_color='red', line_dash='dash')
    fig.update_layout(width=400, height=800, font_size=15, title=dict(text=title, xanchor='center', x=0.5))
    fig.update_xaxes(title_text='History Type')
    fig.update_yaxes(title_text='AUROC (Predicted Acc, Observed Acc)')
    fig.update_yaxes(range=[0, 1.1])
    fig.show()


def compare_bces(values_df, title):
    fig = go.Figure()
    actual_bces = get_sub_actual_bces(values_df)
    plot_subj_values(fig, actual_bces, 'Actual')

    # test if x < 0.666
    test_text = get_ttest_wilcoxon_text(x=actual_bces, y=numpy.ones_like(actual_bces) * 0.666, direction='less')
    fig.add_annotation(x='Actual', y=0.8, showarrow=False, text=f'BCE < 0.666 <br>{test_text}')
    fig.update_layout(width=400, height=800, font_size=15, title=dict(text=title, xanchor='center', x=0.5))
    fig.update_xaxes(title_text='History Type')
    fig.update_yaxes(title_text='BCE (Predicted Acc, Observed Acc)')
    fig.update_yaxes(range=[0, 1])
    fig.show()


def predictability_acc():
    model_type = f'SRM - Acc'
    values = acc_file(project_dir + f'basic_v2/results/sans_block_v3_bs=64_maxep=100_acc/mc-test_values.pkl')
    compare_aurocs(values, model_type)
    compare_bces(values, model_type)


if __name__ == '__main__':
    predictability_rt()
    predictability_acc()
