from os import environ as env

server = env.get('REWARD_SERVER', 'local')

if server == 'local':
    project_dir = '/Users/rajjain/PycharmProjects/reward_modulation/'
    use_gpu = False
    num_cpus = 2
elif server == 'coglab_system':
    project_dir = '/home/raj/Desktop/Projects/reward_modulation/'
    use_gpu = False
    num_cpus = 12
elif server == 'magnus':
    project_dir = '/raven/raj/Projects/reward_modulation/'
    use_gpu = True
    num_cpus = 1
elif server == 'nova':
    project_dir = '/home/raj/Projects/reward_modulation/'
    use_gpu = True
    num_cpus = 1
elif server == 'wellsfargo':
    project_dir = '/data5/home/rajv/Projects/reward_modulation/'
    use_gpu = True
    num_cpus = 1
elif server == 'beagle':
    project_dir = '/BeagleAttic/users/sridharanlab/rajv/Projects/reward_modulation/'
    use_gpu = True
    num_cpus = 1
else:
    raise Exception('Unknown server')

data_dir = project_dir + 'data/'

code_update_webhook = 'https://indianinstituteofscience.webhook.office.com/webhookb2/d9cda447-3f3a-4323-8705-8b1d4d' \
                      '5f2d37@6f15cd97-f6a7-41e3-b2c5-ad4193976476/IncomingWebhook/69fa0fc559a04f0ba9ed64dca57b8c2d' \
                      '/780e3153-6405-430c-af56-8a35bc281ea4'

wandb_project = 'RewardModulation'
