from utils_processing.common_proc import read_data_and_preprocess
from utils_training.training_rt import make_predictions
from utils_data import num_gain_blocks
from utils_processing import seeds
from basic import optuna_storage
from config import project_dir
from typing import Optional
import optuna
import pandas


def summarise_rt_filtered(model_class, bs: int, num_epochs: int, prefix: str, gpu_num: list[int], trial_filter,
                          threshold, exp_type: str):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_rt'
    res_dir = project_dir + 'basic/results/' + folder_name + '/'
    values_df = []
    proc_df_dict = {}

    storage = optuna.storages.get_storage(optuna_storage)

    for seed in seeds[:3]:
        for b in range(num_gain_blocks):
            btest = b
            bval = (b + 1) % num_gain_blocks

            study_name = f'{folder_name}_{seed}_{b}'
            study = optuna.load_study(study_name=study_name, storage=storage)
            df = study.trials_dataframe()
            fil_df = df[df.user_attrs_config.apply(trial_filter)]
            best_config = fil_df.sort_values('value').iloc[0].user_attrs_config
            trial_id = best_config['trial_id']

            best_model_path = res_dir + f'{study_name}/{trial_id}/best.ckpt'
            best_model = model_class.load_from_checkpoint(best_model_path)

            T = best_config['T']
            if T in proc_df_dict:
                proc_df = proc_df_dict[T]
            else:
                proc_df = read_data_and_preprocess(T, return_raw=False, exp_type=exp_type)
                proc_df_dict[T] = proc_df

            value_df, sub_config = make_predictions(best_model, seed, btest, bval, bs, num_epochs, proc_df, gpu_num,
                                                    threshold)
            values_df.append(value_df)

    all_values_df = pandas.concat(values_df, ignore_index=True)
    return all_values_df


def summarise_rt(model_class, bs: int, num_epochs: int, prefix: str, gpu_num: list[int], threshold: Optional[float],
                 exp_type: str):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_rt'
    res_dir = project_dir + 'basic/results/' + folder_name + '/'

    def trial_filter(d):
        return True

    all_values_df = summarise_rt_filtered(model_class, bs, num_epochs, prefix, gpu_num, trial_filter, threshold,
                                          exp_type)
    all_values_df.to_pickle(res_dir + f'overall-values.pkl')


def summarise_rt_T(model_class, bs: int, num_epochs: int, prefix: str, gpu_num: list[int], threshold: Optional[float],
                   exp_type: str):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_rt'
    res_dir = project_dir + 'basic/results/' + folder_name + '/'

    for T in [1, 3, 10, 15]:

        def trial_filter(d):
            return d['T'] == T

        all_values_df = summarise_rt_filtered(model_class, bs, num_epochs, prefix, gpu_num, trial_filter, threshold,
                                              exp_type)
        all_values_df.to_pickle(res_dir + f'T={T}-values.pkl')


def summarise_rt_noreg(model_class, bs: int, num_epochs: int, prefix: str, gpu_num: list[int], threshold: Optional[float],
                       exp_type: str):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_rt'
    res_dir = project_dir + 'basic/results/' + folder_name + '/'

    def trial_filter(d):
        return not d['l2reg'] and d['dropout'] == 0

    all_values_df = summarise_rt_filtered(model_class, bs, num_epochs, prefix, gpu_num, trial_filter, threshold,
                                          exp_type)
    all_values_df.to_pickle(res_dir + f'noreg-values.pkl')


def summarise_rt_l2reg(model_class, bs: int, num_epochs: int, prefix: str, gpu_num: list[int], threshold: Optional[float],
                       exp_type: str):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_rt'
    res_dir = project_dir + 'basic/results/' + folder_name + '/'

    def trial_filter(d):
        return d['l2reg']

    all_values_df = summarise_rt_filtered(model_class, bs, num_epochs, prefix, gpu_num, trial_filter, threshold,
                                          exp_type)
    all_values_df.to_pickle(res_dir + f'l2reg-values.pkl')


def summarise_rt_dropout(model_class, bs: int, num_epochs: int, prefix: str, gpu_num: list[int], threshold: Optional[float],
                         exp_type: str):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_rt'
    res_dir = project_dir + 'basic/results/' + folder_name + '/'

    def trial_filter(d):
        return d['dropout'] > 0

    all_values_df = summarise_rt_filtered(model_class, bs, num_epochs, prefix, gpu_num, trial_filter, threshold,
                                          exp_type)
    all_values_df.to_pickle(res_dir + f'dropout-values.pkl')
