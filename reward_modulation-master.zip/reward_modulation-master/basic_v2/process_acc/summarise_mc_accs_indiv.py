from utils_processing.common_proc import read_data_and_preprocess
from utils_training.training_acc import make_mc_predictions
from utils_data import num_gain_blocks, num_subjects
from utils_processing import seeds, mc_seeds
from basic_v2 import optuna_storage
from config import project_dir
import optuna
import pandas


def common_part(model_class, bs, num_epochs, prefix, gpu_num, exp_type, trial_filter):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_acc'
    res_dir = project_dir + 'basic_v2/results/' + folder_name + '/'
    test_values_df, val_values_df = [], []
    proc_df_dict = {}

    storage = optuna.storages.get_storage(optuna_storage)

    for seed in seeds[:3]:
        for b in range(num_gain_blocks):
            btest = b
            bval = (b + 1) % num_gain_blocks

            for sub_num in range(num_subjects):
                study_name = f'{folder_name}_{seed}_{b}_{sub_num}'
                study = optuna.load_study(study_name=study_name, storage=storage)
                df = study.trials_dataframe()
                fil_df = df[df.user_attrs_config.apply(trial_filter)]
                best_config = fil_df.sort_values('value').iloc[0].user_attrs_config
                trial_id = best_config['trial_id']

                best_model_path = res_dir + f'{study_name}/{trial_id}/best.ckpt'
                best_model = model_class.load_from_checkpoint(best_model_path)

                T = best_config['T']
                if T in proc_df_dict:
                    proc_df = proc_df_dict[T]
                else:
                    proc_df = read_data_and_preprocess(T, return_raw=False, exp_type=exp_type)
                    proc_df_dict[T] = proc_df

                sub_df = proc_df.query(f'sub_num == {sub_num}').copy()
                val_value_df, test_value_df = make_mc_predictions(best_model, seed, btest, bval, bs, num_epochs, sub_df,
                                                                  gpu_num, mc_seeds)
                test_values_df.append(test_value_df)
                val_values_df.append(val_value_df)

    all_test_values_df = pandas.concat(test_values_df, ignore_index=True)
    all_val_values_df = pandas.concat(val_values_df, ignore_index=True)
    return all_test_values_df, all_val_values_df


def get_mc_predictions(model_class, bs: int, num_epochs: int, prefix: str, gpu_num: list[int],
                       exp_type: str, dropout: float):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_acc'
    res_dir = project_dir + 'basic_v2/results/' + folder_name + '/'
    all_test_values_df, all_val_values_df = common_part(model_class, bs, num_epochs, prefix, gpu_num,
                                                        exp_type, lambda d: d['dropout'] == dropout)
    all_test_values_df.to_pickle(res_dir + f'mc-p={dropout}-test_values.pkl')
    all_val_values_df.to_pickle(res_dir + f'mc-p={dropout}-val_values.pkl')


def get_mc_predictions_overall(model_class, bs: int, num_epochs: int, prefix: str, gpu_num: list[int],
                               exp_type: str):
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_acc'
    res_dir = project_dir + 'basic_v2/results/' + folder_name + '/'
    all_test_values_df, all_val_values_df = common_part(model_class, bs, num_epochs, prefix, gpu_num,
                                                        exp_type, lambda d: d['dropout'] > 0)

    all_test_values_df.to_pickle(res_dir + f'mc-test_values.pkl')
    all_val_values_df.to_pickle(res_dir + f'mc-val_values.pkl')
