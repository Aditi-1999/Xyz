from torch.nn import LSTM, GRU
from pytorch_lightning.utilities.seed import seed_everything
import torch
from torch.nn import init
from models_custom.rnns.lstm import variational_lstm
from models_custom.rnns.gru import variational_gru

input_size, hidden_size = 7, 3
batch_size = 64
T = 4


def init_lstm(lstm):
    lstm.double()
    seed_everything(0)
    for name, param in lstm.named_parameters():
        if 'weight_ih' in name:
            init.xavier_uniform_(param)
        elif 'weight_hh' in name:
            init.orthogonal_(param)
        elif 'bias_ih' in name:
            init.zeros_(param)
        elif 'bias_hh' in name:
            param.data = torch.tensor([0] * hidden_size + [1] * hidden_size + [0] * hidden_size * 2,
                                      dtype=torch.double)
    return lstm


def get_pyt_lstm(num_layers, bidirectional):
    pyt_lstm = LSTM(input_size=input_size, hidden_size=hidden_size, num_layers=num_layers,
                    bidirectional=bidirectional, dropout=0, batch_first=True)
    pyt_lstm = init_lstm(pyt_lstm)
    return pyt_lstm


def get_var_lstm(num_layers, bidirectional, dropout=0.):
    var_lstm = variational_lstm(input_size=input_size, hidden_size=hidden_size, num_layers=num_layers,
                                bidirectional=bidirectional, dropout=dropout)
    var_lstm = init_lstm(var_lstm)
    return var_lstm


def test_lstm():
    for num_layers in [1, 2, 3]:
        for bidirectional in [True, False]:
            pyt_lstm = get_pyt_lstm(num_layers, bidirectional)
            var_lstm = get_var_lstm(num_layers, bidirectional)

            seed_everything(0)
            inp = torch.randn(batch_size, T, input_size, dtype=torch.double)
            nl = 2 * num_layers if bidirectional else num_layers
            state = (torch.randn(nl, batch_size, hidden_size, dtype=torch.double),
                     torch.randn(nl, batch_size, hidden_size, dtype=torch.double))

            pyt_out, (pyt_h, pyt_c) = pyt_lstm(inp, state)
            var_out, (var_h, var_c) = var_lstm(inp, state)

            assert torch.allclose(pyt_out, var_out, rtol=0, atol=1e-15)
            assert torch.allclose(pyt_h, var_h, rtol=0, atol=1e-15)
            assert torch.allclose(pyt_c, var_c, rtol=0, atol=1e-15)


def test_dropout_lstm():
    for num_layers in [1, 2, 3]:
        for bidirectional in [True, False]:
            seed_everything(0)
            inp = torch.randn(batch_size, T, input_size, dtype=torch.double)
            nl = 2 * num_layers if bidirectional else num_layers
            state = (torch.randn(nl, batch_size, hidden_size, dtype=torch.double),
                     torch.randn(nl, batch_size, hidden_size, dtype=torch.double))

            var_lstm = get_var_lstm(num_layers, bidirectional, dropout=0.2)

            var_lstm.train()
            tvar_out, (tvar_h, tvar_c) = var_lstm(inp, state)

            var_lstm.eval()
            evar_out, (evar_h, evar_c) = var_lstm(inp, state)


def init_gru(gru):
    gru.double()
    seed_everything(0)
    for name, param in gru.named_parameters():
        if 'weight_ih' in name:
            init.xavier_uniform_(param)
        elif 'weight_hh' in name:
            init.orthogonal_(param)
        elif 'bias_ih' in name:
            init.zeros_(param)
        elif 'bias_hh' in name:
            init.zeros_(param)
    return gru


def get_pyt_gru(num_layers, bidirectional):
    pyt_gru = GRU(input_size=input_size, hidden_size=hidden_size, num_layers=num_layers,
                  bidirectional=bidirectional, dropout=0, batch_first=True)
    pyt_gru = init_gru(pyt_gru)
    return pyt_gru


def get_var_gru(num_layers, bidirectional, dropout=0.):
    var_gpu = variational_gru(input_size=input_size, hidden_size=hidden_size, num_layers=num_layers,
                              bidirectional=bidirectional, dropout=dropout)
    var_gpu = init_gru(var_gpu)
    return var_gpu


def test_gru():
    for num_layers in [1, 2, 3]:
        for bidirectional in [True, False]:
            pyt_gru = get_pyt_gru(num_layers, bidirectional)
            var_gru = get_var_gru(num_layers, bidirectional)

            seed_everything(0)
            inp = torch.randn(batch_size, T, input_size, dtype=torch.double)
            nl = 2 * num_layers if bidirectional else num_layers
            state = torch.randn(nl, batch_size, hidden_size, dtype=torch.double)

            pyt_out, pyt_h = pyt_gru(inp, state)
            var_out, var_h = var_gru(inp, state)

            assert torch.allclose(pyt_out, var_out, rtol=0, atol=1e-15)
            assert torch.allclose(pyt_h, var_h, rtol=0, atol=1e-15)


def test_dropout_gpu():
    for num_layers in [1, 2, 3]:
        for bidirectional in [True, False]:
            seed_everything(0)
            inp = torch.randn(batch_size, T, input_size, dtype=torch.double)
            nl = 2 * num_layers if bidirectional else num_layers
            state = torch.randn(nl, batch_size, hidden_size, dtype=torch.double)

            var_gru = get_var_gru(num_layers, bidirectional, dropout=0.2)

            var_gru.train()
            tvar_out, tvar_h = var_gru(inp, state)

            var_gru.eval()
            evar_out, evar_h = var_gru(inp, state)
