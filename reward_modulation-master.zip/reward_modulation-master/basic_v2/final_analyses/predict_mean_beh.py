from utils_processing.common_proc import read_data_and_preprocess
from basic_v2.hp_checks import hp_checks
from basic_v2.analyses.se_analysis import best_block_hp
from tqdm import tqdm
import pandas
from models_v2.final import OnlyRTWithLSTMHistoryFinalV2, OnlyAccWithLSTMHistoryFinalV2
import plotly.express as px
from utils_processing.metrics import compute_robust_corr, p_val_text
from utils_data.helper import sigmoid, inverse_sigmoid
import plotly.graph_objs as go
from basic_v2.final_analyses import make_se_predictions, get_subj_embed_df, get_test_df_rt, get_test_df_acc

hp_keys = ['T', 'rnn_layers', 'rnn_bidirectional', 'rnn_hidden_size', 'hidden_sizes', 'dropout']


def predict_mean_rt():
    results = hp_checks([0, 10, 20], 'sans_block_v3', 64, 100, lambda d: True, 'rt', hp_keys)
    hp_results = best_block_hp(results)
    proc_dfs = {}
    for T in hp_results['T'].unique():
        proc_dfs[T] = read_data_and_preprocess(T, return_raw=False, exp_type='gain_d')

    subj_dfs = []
    for idx, row in tqdm(hp_results.iterrows()):
        trial = row.to_dict()
        test_df = get_test_df_rt(trial, proc_dfs)
        rt = test_df.groupby('sub_num').response_time.mean()
        df_subj = get_subj_embed_df(OnlyRTWithLSTMHistoryFinalV2, trial['folder_path'])
        df_subj['target'] = rt.loc[df_subj.subject].tolist()
        df_subj = make_se_predictions(df_subj)
        subj_dfs.append(df_subj)

    subj_df = pandas.concat(subj_dfs, ignore_index=True)
    avg_data = subj_df.groupby('subject').agg({'target': 'mean', 'pred': 'mean'}).reset_index()
    corr = compute_robust_corr(avg_data, 'target', 'pred', 'greater')
    fig = px.scatter(avg_data, x='target', y='pred',
                     labels={'target': 'Observed Mean RT', 'pred': 'Predicted Mean RT from Embeddings'},
                     trendline='ols', trendline_color_override='black',
                     title=f'SRM RT - R.Corr = {corr["corr"]:.3f}; {p_val_text(corr["pval"])} for R.Corr > 0',
                     height=600, width=600)
    prange = [0.32, 0.98]
    fig.add_trace(go.Scatter(x=prange, y=prange, mode='lines', line=dict(color='red'), showlegend=False))
    fig.update_layout(xaxis_range=prange, yaxis_range=prange, title=dict(xanchor='center', x=0.5))
    fig.show()


def predict_mean_acc():
    results = hp_checks([0, 10, 20], 'sans_block_v3', 64, 100, lambda d: True, 'acc', hp_keys)
    hp_results = best_block_hp(results)
    proc_dfs = {}
    for T in hp_results['T'].unique():
        proc_dfs[T] = read_data_and_preprocess(T, return_raw=False, exp_type='gain_d')

    subj_dfs = []
    for idx, row in tqdm(hp_results.iterrows()):
        trial = row.to_dict()
        test_df = get_test_df_acc(trial, proc_dfs)
        acc = test_df.groupby('sub_num').accuracy.mean()
        df_subj = get_subj_embed_df(OnlyAccWithLSTMHistoryFinalV2, trial['folder_path'])
        df_subj['target'] = acc.loc[df_subj.subject].tolist()
        assert (df_subj['target'] < 1).all()
        df_subj['target'] = df_subj.target.apply(inverse_sigmoid)
        df_subj = make_se_predictions(df_subj)
        df_subj['target'] = df_subj.target.apply(sigmoid)
        df_subj['pred'] = df_subj.pred.apply(sigmoid)
        subj_dfs.append(df_subj)

    subj_df = pandas.concat(subj_dfs, ignore_index=True)
    avg_data = subj_df.groupby('subject').agg({'target': 'mean', 'pred': 'mean'}).reset_index()
    corr = compute_robust_corr(avg_data, 'target', 'pred', 'greater')
    fig = px.scatter(avg_data, x='target', y='pred',
                     labels={'target': 'Observed Mean Accuracy', 'pred': 'Predicted Mean Accuracy from Embeddings'},
                     trendline='ols', trendline_color_override='black',
                     title=f'SRM Acc - R.Corr = {corr["corr"]:.3f}; {p_val_text(corr["pval"])} for R.Corr > 0',
                     height=600, width=600)
    prange = [0.45, 0.75]
    fig.add_trace(go.Scatter(x=prange, y=prange, mode='lines', line=dict(color='red'), showlegend=False))
    fig.update_layout(xaxis_range=prange, yaxis_range=prange, title=dict(xanchor='center', x=0.5))
    fig.show()


if __name__ == '__main__':
    predict_mean_rt()
    predict_mean_acc()
