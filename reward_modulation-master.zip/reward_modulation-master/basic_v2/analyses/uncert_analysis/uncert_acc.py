import pandas
from config import project_dir
from utils_processing import mc_seeds
from utils_data.helper import sigmoid, entropy
from scipy.stats import wilcoxon, ttest_rel
from utils_processing.metrics import p_val_text
import plotly.graph_objs as go

mtype_title = {
    'ratio': 'Ent(Actual) / Ent(Shuffled)',
    'modulated_sum': '(Ent(Actual) - Ent(Shuffled)) / (Ent(Actual) + Ent(Shuffled))',
}


def measure_type_ent(values_df, mtype):
    if mtype == 'ratio':
        values_df['measure'] = values_df['acc_pred_ent'] / values_df['acc_pred_bs_ent']
    elif mtype == 'modulated_sum':
        values_df['measure'] = (values_df['acc_pred_ent'] - values_df['acc_pred_bs_ent']) / (values_df['acc_pred_ent'] + values_df['acc_pred_bs_ent'])
    return values_df


def conditioned_entropy(result_dir, mtype, yrange, py):
    variable = 'side_probed'
    values_df = pandas.read_pickle(result_dir)
    values_df['side_probed'] = values_df['side_probed'].apply(lambda x: 'VR' if x == 1 else 'FX')
    values_df['sub_emb'] = values_df.sub_emb.apply(int).apply(str)

    # Trial Level Uncertainty
    pred_cols = list(map(lambda x: f'acc_pred_{x}', range(len(mc_seeds))))
    values_df['acc_pred'] = values_df[pred_cols].applymap(sigmoid).mean(axis=1)
    pred_cols = list(map(lambda x: f'acc_pred_bs_{x}', range(len(mc_seeds))))
    values_df['acc_pred_bs'] = values_df[pred_cols].applymap(sigmoid).mean(axis=1)
    values_df['acc_pred_ent'] = values_df.acc_pred.apply(entropy)
    values_df['acc_pred_bs_ent'] = values_df.acc_pred_bs.apply(entropy)

    # Mean of Uncertainty Per Split, Per Block, Per Subject, Per Condition
    values_df = values_df.groupby(['sub_emb', 'seed', 'btest', variable]) \
        .agg({'acc_pred_ent': 'mean', 'acc_pred_bs_ent': 'mean'}) \
        .reset_index()

    # Median Per Subject, Per Condition
    values_df = values_df.groupby(['sub_emb', variable]) \
        .agg({'acc_pred_ent': 'median', 'acc_pred_bs_ent': 'median'}) \
        .reset_index()

    # Calculate Metric
    values_df = measure_type_ent(values_df, mtype)

    cond = values_df.copy()
    con0 = cond[cond[variable] == 'FX']
    con1 = cond[cond[variable] == 'VR']

    fig = go.Figure()
    fig.add_trace(go.Bar(x=['FX', 'VR'], y=[con0.measure.mean(), con1.measure.mean()], showlegend=False))

    pt_p_val = ttest_rel(a=con0.measure, b=con1.measure, alternative='two-sided')[1]  # test if a != b
    w_p_val = wilcoxon(x=con0.measure, y=con1.measure, alternative='two-sided')[1]  # test if x != y
    fig.add_annotation(x=0.5, y=py, showarrow=False,
                       text=f'FX != VR<br>{p_val_text(pt_p_val)}; Paired-t<br>{p_val_text(w_p_val)}; Wilcoxon')

    for sub_emb in cond.sub_emb.unique():
        sub0 = con0.query(f'sub_emb == "{sub_emb}"')
        sub1 = con1.query(f'sub_emb == "{sub_emb}"')
        fig.add_trace(go.Scatter(x=['FX', 'VR'], y=[sub0.measure.iloc[0], sub1.measure.iloc[0]],
                                 mode='lines+markers', marker=dict(color='red'), opacity=0.3,
                                 name=f'{sub_emb}',  # showlegend=False,
                                 ))

    fig.update_layout(width=400, height=800, font_size=15)
    fig.update_xaxes(title_text=variable)
    fig.update_yaxes(title_text=mtype_title[mtype])
    fig.update_yaxes(range=yrange)

    fig.show()


if __name__ == '__main__':
    res_dir = project_dir + 'basic_v2/results/reencode_bs=64_maxep=100_acc/'
    # conditioned_entropy(res_dir + f'mc-test_values.pkl', mtype='ratio', yrange=[0.96, 1.08], py=1.07, trial_level=True)
    # conditioned_entropy(res_dir + f'mc-test_values.pkl', mtype='modulated_sum', yrange=[-0.015, 0.015], py=0.01, trial_level=True)
    conditioned_entropy(res_dir + f'mc-test_values.pkl', mtype='ratio', yrange=[0.94, 1.04], py=1.03)
    conditioned_entropy(res_dir + f'mc-test_values.pkl', mtype='modulated_sum', yrange=[-0.025, 0.015], py=0.0075)
