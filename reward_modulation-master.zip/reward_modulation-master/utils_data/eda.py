import pandas
from config import data_dir
import plotly.express as px
from scipy.stats import boxcox, yeojohnson, shapiro
from utils_data import colours, num_subjects, num_gain_blocks
from statsmodels.stats.diagnostic import lilliefors
import pingouin as pg
from statsmodels.stats.proportion import proportions_ztest
from utils_data.helper import entropy


def same_sequence_for_all_subjects():
    data_df = pandas.read_json(data_dir + 'data.json', orient='columns')
    data_df = data_df[['sub_num', 'gain_block_num', 'trial_num',
                       'block_type', 'side_fixed', 'reward_vr_fx', 'stimulus_time',
                       'change_fixed', 'change_variable', 'side_probed']]
    data_df.sort_values(['sub_num', 'gain_block_num', 'trial_num'], inplace=True)
    data_df.set_index(['sub_num'], inplace=True)

    # Check if all subjects are exposed to same (block, trial) sequence
    for i in range(num_subjects):
        df_i = data_df.loc[i].reset_index(drop=True)
        for j in range(i + 1, num_subjects):
            df_j = data_df.loc[j].reset_index(drop=True)
            assert not df_i.equals(df_j)  # No two subjects have the same (block, trial) sequence

    # Check if trial sequence is same for every block
    sub0 = data_df.loc[0].reset_index(drop=True)
    sub0.set_index(['gain_block_num'], inplace=True)
    for i in range(num_gain_blocks):
        df_i = sub0.loc[i].reset_index(drop=True)
        for j in range(i + 1, num_gain_blocks):
            df_j = sub0.loc[j].reset_index(drop=True)
            assert not df_i.equals(df_j)


def rt_as_uncertainty():
    data_df: pandas.DataFrame = pandas.read_json(data_dir + 'gain_d_data.json', orient='columns')
    accs = data_df.groupby('sub_num').accuracy.mean()
    rts = data_df[data_df.accuracy == 1].groupby('sub_num').response_time.mean()
    df = pandas.concat([accs, rts], axis=1).reset_index()
    px.scatter(df, x='accuracy', y='response_time', text='sub_num').show()
    df['entropy'] = df['accuracy'].apply(entropy)
    px.scatter(df, x='entropy', y='response_time', text='sub_num').show()


def stimulus_time_pattern():
    data_df: pandas.DataFrame = pandas.read_json(data_dir + 'gain_d_data.json', orient='columns')
    print(data_df.stimulus_time.quantile(q=[0.25, 0.5, 0.75]).tolist())

    stimulus_time_list = data_df.groupby(['sub_num', 'gain_block_num']).stimulus_time.apply(list)
    stimulus_time_str = stimulus_time_list.apply(str)
    unique_list = stimulus_time_str.unique()
    # Same stimulus time pattern for each participant for each block
    assert len(unique_list) == 1


def block_type_seq(seq):
    str_seq = map(lambda x: 'L' if x == 0 else 'G', seq)
    return ''.join(str_seq)


def block_sequence_pattern():
    data_df: pandas.DataFrame = pandas.read_json(data_dir + 'data.json', orient='columns')
    block_types = data_df.groupby(['sub_num', 'block_num']).block_type.unique()

    # Check if any block has multiple block types in it
    assert len(block_types.apply(len).unique()) == 1

    block_type_seqs = block_types.apply(lambda x: x[0]).reset_index() \
        .groupby('sub_num').block_type.apply(list) \
        .apply(block_type_seq).value_counts()
    print(block_type_seqs)


def subject_accs():
    data_df: pandas.DataFrame = pandas.read_json(data_dir + 'data.json', orient='columns')
    data_df.dropna(subset=['accuracy'], inplace=True)
    accs = data_df.groupby(['sub_num', 'block_num']).accuracy.mean().reset_index()
    accs = accs.groupby('sub_num').accuracy.agg(acc='mean', max='max', min='min', std='std').reset_index()
    fig = px.bar(accs, x='sub_num', y='acc', text='acc', text_auto='.2f', error_y='std',
                 labels=dict(sub_num='Subject ID', acc='Accuracy'))
    # fig.update_traces(error_y={
    #     "type": "data",
    #     "symmetric": False,
    #     "array": accs["max"] - accs["acc"],
    #     "arrayminus": accs["acc"] - accs["min"],
    # })
    fig.update_layout(font_size=15)
    fig.update_xaxes(tickmode='linear', tick0=0, dtick=1)
    fig.show()


def subject_nas():
    data_df: pandas.DataFrame = pandas.read_json(data_dir + 'data.json', orient='columns')
    na_counts = data_df.groupby(['sub_num']).apply(lambda df: df.response.isna().sum() / len(df) * 100)
    na_counts.name = 'na_perc'
    na_counts = na_counts.reset_index()
    fig = px.bar(na_counts, x='sub_num', y='na_perc', text='na_perc', text_auto='.2f',
                 labels=dict(sub_num='Subject ID', na_perc='NaN %age'))
    fig.update_layout(font_size=15)
    fig.update_xaxes(tickmode='linear', tick0=0, dtick=1)
    fig.show()
    print(f'{data_df.response.isna().sum()} / {len(data_df)} = {na_counts.na_perc.mean().round(2)}% Overall')


def get_sub_config_box(response_times):
    transformed, lmbda = boxcox(response_times)
    return {
        'mean': transformed.mean(),
        'std': transformed.std(),
        'lambda': lmbda,
    }


def get_sub_config_yj(response_times):
    transformed, lmbda = yeojohnson(response_times)
    return {
        'mean': transformed.mean().item(),
        'std': transformed.std().item(),
        'lambda': lmbda.item(),
    }


def visualise_rt():
    data_df: pandas.DataFrame = pandas.read_json(data_dir + 'data.json', orient='columns')
    data_df.dropna(subset=['response_time'], inplace=True)

    sub_config_box = data_df.groupby('sub_num').response_time.apply(get_sub_config_box).to_dict()
    data_df['rt_box_zscored'] = data_df.apply(
        lambda row: (boxcox(row['response_time'], sub_config_box[(row['sub_num'], 'lambda')]).item() - sub_config_box[
            (row['sub_num'], 'mean')]) / sub_config_box[(row['sub_num'], 'std')],
        axis=1)

    box_test_lillie = data_df.groupby('sub_num').rt_box_zscored.apply(lambda rts: lilliefors(rts)[1])
    box_test_shapiro = data_df.groupby('sub_num').rt_box_zscored.apply(lambda rts: shapiro(rts).pvalue)
    print(box_test_lillie)
    print(box_test_shapiro.round(6))

    sub_config_yj = data_df.groupby('sub_num').response_time.apply(get_sub_config_yj).to_dict()
    data_df['rt_yj_zscored'] = data_df.apply(
        lambda row: (yeojohnson(row['response_time'], sub_config_yj[(row['sub_num'], 'lambda')]).item() -
                     sub_config_yj[(row['sub_num'], 'mean')]) / sub_config_yj[(row['sub_num'], 'std')],
        axis=1)

    yj_test_lillie = data_df.groupby('sub_num').rt_yj_zscored.apply(lambda rts: lilliefors(rts)[1])
    yj_test_shapiro = data_df.groupby('sub_num').rt_yj_zscored.apply(lambda rts: shapiro(rts).pvalue)
    print(yj_test_lillie)
    print(yj_test_shapiro.round(6))

    # # BoxCox seems better overall
    for col, x_title in [
        ('response_time', 'Raw Response Time'),
        ('rt_box_zscored', 'RT Zscored after BoxCox'),
        ('rt_yj_zscored', 'RT Zscored after YeoJohnson'),
    ]:
        fig = px.histogram(data_df, x=col, color='sub_num', barmode='overlay', opacity=0.3,
                           color_discrete_sequence=colours)
        fig.update_layout(xaxis_title=x_title, yaxis_title='Count', font_size=18)
        fig.show()


def perceived_contingency_mismatch():
    data_df: pandas.DataFrame = pandas.read_json(data_dir + 'data.json', orient='columns')

    data_df['cont_match'] = (data_df['perc_contingency'] == data_df['reward_vr_fx']).apply(int)
    mean_match = data_df.groupby(['sub_num', 'gain_block_num']).cont_match.mean()
    mean_acc = data_df.groupby(['sub_num', 'gain_block_num']).accuracy.mean()

    corr = pg.corr(mean_acc, mean_match, method='percbend').iloc[0]
    print(corr)  # mild correlation

    fig = px.scatter(x=mean_acc.tolist(), y=mean_match.tolist(),
                     trendline='ols', trendline_scope='overall', trendline_color_override='black')
    fig.show()


def pval_text(pval):
    if pval < 0.001:
        return '***'
    if pval < 0.01:
        return '**'
    if pval < 0.05:
        return '*'
    return 'n.s.'


def subject_accs_ztest():
    data_df: pandas.DataFrame = pandas.read_json(data_dir + 'data.json', orient='columns')
    data_df.dropna(subset=['accuracy'], inplace=True)
    corrects = data_df.groupby(['sub_num']).accuracy.sum().to_dict()
    counts = data_df.groupby(['sub_num']).accuracy.count().to_dict()

    pvals = []
    for sub_num in data_df.sub_num.unique():
        _, pval = proportions_ztest(corrects[sub_num], counts[sub_num],
                                    value=0.5, alternative='larger')  # proportion > value
        pvals.append({
            'pval': pval,
            'sub': sub_num,
        })

    pval_df = pandas.DataFrame(pvals)
    pval_df['text'] = pval_df['pval'].apply(pval_text)

    fig = px.bar(pval_df, x='sub', y='pval', text='text',
                 labels=dict(sub='Subject ID', pval='p-val for accuracy > 0.5; z-test'))
    fig.update_traces(textposition="outside")
    fig.update_xaxes(tickmode='linear', tick0=0, dtick=1)
    fig.update_layout(showlegend=False)
    fig.show()


if __name__ == '__main__':
    rt_as_uncertainty()
