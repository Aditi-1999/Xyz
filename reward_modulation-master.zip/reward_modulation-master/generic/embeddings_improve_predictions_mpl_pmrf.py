from aistats_figures import acc_file, get_sub_metrics, color, data_dir, p_text
from scipy.stats import ttest_rel
import matplotlib.pyplot as plt
from config import project_dir
import pandas
import numpy
from matplotlib import rc


point_size = 100
font_size = 15


def get_acc_metrics(acc_fname, experiment):
    values = acc_file(acc_fname)
    auroc = get_sub_metrics(values, experiment=experiment, metric='acc', measure='auroc', shuffled=False)
    auroc.name = 'auroc'
    bce = get_sub_metrics(values, experiment=experiment, metric='acc', measure='bce', shuffled=False)
    bce.name = 'bce'
    return pandas.DataFrame([auroc, bce]).transpose()


def get_all_acc_metrics(experiment):
    bisann = get_acc_metrics(data_dir + experiment + '/bisann_acc.pkl', experiment=experiment)
    sanspe = get_acc_metrics(data_dir + experiment + '/sanspe_acc.pkl', experiment=experiment)
    indiv = get_acc_metrics(data_dir + experiment + '/indiv_acc.pkl', experiment=experiment)
    return bisann, sanspe, indiv


def plot(control):
    # rc('text', usetex=True)
    plt.rcParams['axes.unicode_minus'] = False
    plt.rcParams['font.sans-serif'] = "Arial"
    plt.rcParams['font.family'] = "sans-serif"
    fig, ax = plt.subplots(1, 1, figsize=(5, 5))
    ax.set_aspect('equal', 'box')

    srm_bisann, srm_sanspe, srm_indiv = get_all_acc_metrics(experiment='srm')

    if control == 'sanspe':
        srm_control = srm_sanspe.copy()
        p_pos = (0.5, 0.8)
        ylabel = r'$\bf{Without}$ Embeddings' + '\nAUROC (Accuracy)'
    else:
        srm_control = srm_indiv.copy()
        p_pos = (0.5, 0.8)
        ylabel = r'$\bf{Individual}$' + '\nAUROC (Accuracy)'

    vrange = [0.4, 0.91]
    xlabel = r'$\bf{With}$ Embeddings' + '\nAUROC (Accuracy)'
    ticks = numpy.arange(0.4, 0.91, 0.1)

    # ax.scatter(x=srm_bisann['auroc'], y=srm_control['auroc'], label=None, edgecolor='white',
    #            color=color['srm'], marker='o', s=point_size)
    ax.plot(vrange, vrange, color='black', linestyle='--')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.set_xlim(*vrange)
    ax.set_ylim(*vrange)
    ax.set_xlabel(xlabel, fontsize=font_size)
    ax.set_ylabel(ylabel, fontsize=font_size)
    ax.set_xticks(ticks)
    ax.set_yticks(ticks)
    for tick in ax.get_xticklabels() + ax.get_yticklabels():
        tick.set_fontsize(font_size)
    # main_p = ttest_rel(a=srm_bisann['auroc'], b=srm_control['auroc'], alternative='greater')[1]
    # main_p = p_text(main_p)
    # ax.text(*p_pos, s=main_p, ha='center', va='center', fontsize=font_size, fontweight='bold')

    plt.tight_layout(rect=[0, 0, 1, 1])
    plt.savefig(project_dir + f'generic/embeddings_improve_predictions_{control}_pmrf-inter.png', dpi=400)


if __name__ == '__main__':
    # plot(control='sanspe')
    plot(control='indiv')
