import pandas
import plotly.graph_objs as go
import plotly.express as px
from config import project_dir
from utils_data import colours
from utils_processing.metrics import compute_robust_corr, compute_mse


def get_actual_metrics(values_df):
    # Actual History Predictions
    actual_corrs = values_df.groupby(['sub_emb', 'seed']).apply(lambda df: compute_robust_corr(df, 'rt_target', 'rt_pred')['corr'])
    actual_corrs.name = 'metric'
    actual_corrs = actual_corrs.reset_index()
    actual_corrs = actual_corrs.groupby(['sub_emb']).metric.mean()

    actual_mses = values_df.groupby(['sub_emb', 'seed']).apply(lambda df: compute_mse(df, 'rt_target', 'rt_pred'))
    actual_mses.name = 'metric'
    actual_mses = actual_mses.reset_index()
    actual_mses = actual_mses.groupby(['sub_emb']).metric.mean()

    return actual_corrs, actual_mses


def compare_metrics(common_values_df, subjwise_values_df, title):
    common_corr, common_mse = get_actual_metrics(common_values_df)
    subj_corr, subj_mse = get_actual_metrics(subjwise_values_df)

    # Robust Correlation Scatter
    corr_range = [-0.2, 0.5]
    corr_df = pandas.DataFrame({'common': common_corr, 'subj': subj_corr}).reset_index()
    corr_df['sub_emb'] = corr_df.sub_emb.apply(int).apply(str)
    fig = px.scatter(corr_df, x='common', y='subj', color='sub_emb', color_discrete_sequence=colours,
                     labels={'common': 'Common Model Robust Corr', 'subj': 'Subject Wise Models Robust Corr',
                             'sub_emb': 'Subject ID'})
    fig.add_trace(go.Scatter(x=corr_range, y=corr_range, mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_layout(width=900, height=800, font_size=15, xaxis_range=corr_range, yaxis_range=corr_range,
                      title=dict(text=title + ' - Comparing Robust Corr', xanchor='center', x=0.5))
    fig.show()

    # MSE Scatter
    mse_range = [0.8, 2.1]
    mse_df = pandas.DataFrame({'common': common_mse, 'subj': subj_mse}).reset_index()
    mse_df['sub_emb'] = mse_df.sub_emb.apply(int).apply(str)
    fig = px.scatter(mse_df, x='common', y='subj', color='sub_emb', color_discrete_sequence=colours,
                     labels={'common': 'Common Model MSE', 'subj': 'Subject Wise Models MSE',
                             'sub_emb': 'Subject ID'})
    fig.add_trace(go.Scatter(x=mse_range, y=mse_range, mode='lines', line=dict(color='red'), name='y=x'))
    fig.update_layout(width=900, height=800, font_size=15,
                      title=dict(text=title + ' - Comparing MSE', xanchor='center', x=0.5))
    fig.show()


if __name__ == '__main__':
    subj_folder = project_dir + f'subj_wise/results/subj_wise_bs=32_maxep=100_rt/'
    subj_values = pandas.read_pickle(subj_folder + f'overall-values.pkl')

    common_folder = project_dir + f'basic/results/basic_sans_block_bs=64_maxep=100_rt/'
    common_values = pandas.read_pickle(common_folder + f'overall-values.pkl')
    # common_values = common_values.query(f'sub_emb in {rt_subjects}').copy()

    compare_metrics(common_values, subj_values, 'Basic Comparison')
