from config import project_dir
from utils_data import num_gain_blocks
import pandas
import os
import torch.nn.functional as f
import torch
from torch.utils.data import DataLoader, TensorDataset
import numpy


def get_func_from_str(func_name):
    if func_name == 'relu':
        return f.relu
    if func_name == 'selu':
        return f.selu
    if func_name == 'sigmoid':
        return torch.sigmoid
    if func_name == 'tanh':
        return torch.tanh
    if func_name == 'gelu':
        return f.gelu
    if func_name == 'hardtanh':
        return f.hardtanh
    if func_name is None:
        return None
    raise Exception('Unknown activation function')


def save_predictions_if_missing_acc(model_class, seed_list, trials, bs, num_epochs, prefix, T, proc_df):
    from utils_training.training_acc import make_predictions
    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_acc'
    value_dfs = []
    for seed in seed_list:
        for b in range(num_gain_blocks):
            btest = b
            bval = (btest + 1) % num_gain_blocks

            # Get appropriate run
            fil_trials = trials.query(f'seed == {seed} & btest == {b}').copy()
            assert len(fil_trials) == 1
            trial = fil_trials.iloc[0].to_dict()

            if os.path.exists(trial['folder_path'] + 'values.pkl'):
                values_df = pandas.read_pickle(trial['folder_path'] + 'values.pkl')
            else:
                actual_model = model_class.load_from_checkpoint(trial['folder_path'] + 'best.ckpt')
                values_df = make_predictions(actual_model, seed, btest, bval, bs, num_epochs, proc_df, [0])
                values_df.to_pickle(trial['folder_path'] + 'values.pkl')

            value_dfs.append(values_df)

    all_values_df = pandas.concat(value_dfs, ignore_index=True)
    all_values_df.to_pickle(project_dir + f'basic/results/{folder_name}/bestHyper-T={T}-values.pkl')


def save_predictions_if_missing_rt(model_class, seed_list, trials, bs, num_epochs, proc_df):
    from utils_training.training_rt import make_predictions
    for seed in seed_list:
        for b in range(num_gain_blocks):
            btest = b
            bval = (btest + 1) % num_gain_blocks

            # Get appropriate run
            fil_trials = trials.query(f'seed == {seed} & btest == {b}').copy()
            assert len(fil_trials) == 1
            trial = fil_trials.iloc[0].to_dict()

            if not os.path.exists(trial['folder_path'] + 'values.pkl'):
                actual_model = model_class.load_from_checkpoint(trial['folder_path'] + 'best.ckpt')
                values_df, _ = make_predictions(actual_model, seed, btest, bval, bs, num_epochs, proc_df, [0], None)
                values_df.to_pickle(trial['folder_path'] + 'values.pkl')


def generate_predictions_if_missing_acc(model_class, trials, bs, num_epochs, proc_dfs):
    from utils_training.training_acc import make_predictions

    for idx, trial in trials.iterrows():
        T = trial['T']
        proc_df = proc_dfs[T]
        seed, b = trial['seed'], trial['b']
        btest = b
        bval = (btest + 1) % num_gain_blocks

        if not os.path.exists(trial['folder_path'] + 'values.pkl'):
            actual_model = model_class.load_from_checkpoint(trial['folder_path'] + 'best.ckpt')
            values_df = make_predictions(actual_model, seed, btest, bval, bs, num_epochs, proc_df, [0])
            values_df.to_pickle(trial['folder_path'] + 'values.pkl')


def generate_predictions_if_missing_rt(model_class, trials, bs, num_epochs, proc_dfs):
    from utils_training.training_rt import make_predictions

    for idx, trial in trials.iterrows():
        T = trial['T']
        proc_df = proc_dfs[T]
        seed, b = trial['seed'], trial['b']
        btest = b
        bval = (btest + 1) % num_gain_blocks

        if not os.path.exists(trial['folder_path'] + 'values.pkl'):
            actual_model = model_class.load_from_checkpoint(trial['folder_path'] + 'best.ckpt')
            values_df, _ = make_predictions(actual_model, seed, btest, bval, bs, num_epochs, proc_df, [0], None)
            values_df.to_pickle(trial['folder_path'] + 'values.pkl')


def get_tensors(section_df, lstm_inp_flat, sub_emb, block_emb):
    """Get tensors that will be fed into a TensorDataset"""
    return [
        torch.tensor(section_df[lstm_inp_flat].values, dtype=torch.float64).double(),
        torch.tensor(section_df[sub_emb].values, dtype=torch.float64).double(),
        torch.tensor(section_df[block_emb].values, dtype=torch.float64).double(),
    ]


def get_background(data_df, test_idxs, lstm_cols, sub_cols, block_cols):
    train_df = data_df.loc[~data_df.index.isin(test_idxs)].copy().reset_index()
    train_dataset = TensorDataset(*get_tensors(train_df, lstm_cols, sub_cols, block_cols))
    train_dataloader = DataLoader(train_dataset, batch_size=1000, shuffle=True)
    return train_df, next(iter(train_dataloader))


def get_test(data_df, test_idxs, lstm_cols, sub_cols, block_cols):
    test_df = data_df.loc[data_df.index.isin(test_idxs)].copy().reset_index()
    test_dataset = TensorDataset(*get_tensors(test_df, lstm_cols, sub_cols, block_cols))
    test_dataloader = DataLoader(test_dataset, batch_size=len(test_df), shuffle=False)
    return test_df, next(iter(test_dataloader))


def correctness_check_rt(shap_model, shap_test, trial, seed, b):
    shap_predictions = shap_model(*shap_test).detach().numpy()[:, 0]
    actual_predictions = pandas.read_pickle(trial['folder_path'] + 'values.pkl').rt_pred.values
    correctness_check(shap_predictions, actual_predictions, f'{seed}, {b}')


def correctness_check_acc(shap_model, shap_test, trial, seed, b):
    shap_predictions = shap_model(*shap_test).detach().numpy()[:, 0]
    actual_predictions = pandas.read_pickle(trial['folder_path'] + 'values.pkl').acc_pred.values
    correctness_check(shap_predictions, actual_predictions, f'{seed}, {b}')


def correctness_check(shap_predictions, actual_predictions, config):
    if shap_predictions.shape[0] != actual_predictions.shape[0]:
        msg = f'Size mismatch in correctness check for {config}'
        raise AssertionError(msg)

    diff = shap_predictions - actual_predictions
    equality = not numpy.any(diff.round(10))
    if not equality:
        msg = f'Assertion Error for {config}\n' \
              f'Min diff: {diff.min():.2E}, Max diff: {diff.max():.2E}'
        raise AssertionError(msg)
