import numpy
import random
import pandas
from config import data_dir
from utils_processing import seeds
from utils_data import num_gain_blocks, num_subjects
from pytorch_lightning.utilities.seed import seed_everything
from tqdm import tqdm
from multiprocessing import Pool
from utils_data.preprocess_data import data_columns

final_columns = data_columns + [
    'sub_emb', 'block_emb',

    'change_fixed_prespast', 'change_variable_prespast', 'side_probed_prespast',
    'stimulus_time_prespast', 'accrued_score_prespast',
    'is_correct_prespast_acc', 'is_wrong_prespast_acc',  # special for accuracy prediction
    'reward_vr_fx_prespast', 'perc_vr_gt_fx_prespast',
    'reward_yes_no_prespast', 'perc_yes_gt_no_prespast',

    'change_fixed_prespast_bs', 'change_variable_prespast_bs', 'side_probed_prespast_bs',
    'stimulus_time_prespast_bs', 'accrued_score_prespast_bs',
    'is_correct_prespast_acc_bs', 'is_wrong_prespast_acc_bs',  # special for accuracy prediction
    'reward_vr_fx_prespast_bs', 'perc_vr_gt_fx_prespast_bs',
    'reward_yes_no_prespast_bs', 'perc_yes_gt_no_prespast_bs',

    'rt_prespast', 'rt_prespast_bs', 'acc_prespast', 'acc_prespast_bs',
    'rt_prespast_cc', 'rt_prespast_cc_bs', 'acc_prespast_cc', 'acc_prespast_cc_bs',
    'rt_perccont_prespast', 'rt_perccont_prespast_bs',
    'acc_perccont_prespast', 'acc_perccont_prespast_bs',
    'rt_bothcont_prespast', 'rt_bothcont_prespast_bs',
    'rt_perccont_sansaccrued_prespast', 'rt_perccont_sansaccrued_prespast_bs',
    'acc_perccont_sansaccrued_prespast', 'acc_perccont_sansaccrued_prespast_bs',
    'rt_perccont_sansstimdura_prespast', 'rt_perccont_sansstimdura_prespast_bs',
    'acc_perccont_sansstimdura_prespast', 'acc_perccont_sansstimdura_prespast_bs',
    'rt_perccont_sansiswrong_prespast', 'rt_perccont_sansiswrong_prespast_bs',
]

prespast_columns = {
    'rt_prespast': [
        'reward_vr_fx_prespast', 'change_fixed_prespast', 'change_variable_prespast', 'side_probed_prespast',
        'stimulus_time_prespast', 'is_correct_prespast_acc', 'is_wrong_prespast_acc', 'accrued_score_prespast',
    ],
    'rt_prespast_bs': [
        'reward_vr_fx_prespast_bs', 'change_fixed_prespast_bs', 'change_variable_prespast_bs', 'side_probed_prespast_bs',
        'stimulus_time_prespast_bs', 'is_correct_prespast_acc_bs', 'is_wrong_prespast_acc_bs', 'accrued_score_prespast_bs',
    ],
    'rt_prespast_cc': [
        'reward_yes_no_prespast', 'change_fixed_prespast', 'change_variable_prespast', 'side_probed_prespast',
        'stimulus_time_prespast', 'is_correct_prespast_acc', 'is_wrong_prespast_acc', 'accrued_score_prespast',
    ],
    'rt_prespast_cc_bs': [
        'reward_yes_no_prespast_bs', 'change_fixed_prespast_bs', 'change_variable_prespast_bs', 'side_probed_prespast_bs',
        'stimulus_time_prespast_bs', 'is_correct_prespast_acc_bs', 'is_wrong_prespast_acc_bs', 'accrued_score_prespast_bs',
    ],
    'acc_prespast': [
        'reward_vr_fx_prespast', 'change_fixed_prespast', 'change_variable_prespast', 'side_probed_prespast',
        'stimulus_time_prespast', 'is_correct_prespast_acc', 'is_wrong_prespast_acc', 'accrued_score_prespast',
    ],
    'acc_prespast_bs': [
        'reward_vr_fx_prespast_bs', 'change_fixed_prespast_bs', 'change_variable_prespast_bs', 'side_probed_prespast_bs',
        'stimulus_time_prespast_bs', 'is_correct_prespast_acc_bs', 'is_wrong_prespast_acc_bs', 'accrued_score_prespast_bs',
    ],
    'acc_prespast_cc': [
        'reward_yes_no_prespast', 'change_fixed_prespast', 'change_variable_prespast', 'side_probed_prespast',
        'stimulus_time_prespast', 'is_correct_prespast_acc', 'is_wrong_prespast_acc', 'accrued_score_prespast',
    ],
    'acc_prespast_cc_bs': [
        'reward_yes_no_prespast_bs', 'change_fixed_prespast_bs', 'change_variable_prespast_bs', 'side_probed_prespast_bs',
        'stimulus_time_prespast_bs', 'is_correct_prespast_acc_bs', 'is_wrong_prespast_acc_bs', 'accrued_score_prespast_bs',
    ],
    'rt_perccont_prespast': [
        'perc_vr_gt_fx_prespast', 'change_fixed_prespast', 'change_variable_prespast', 'side_probed_prespast',
        'stimulus_time_prespast', 'is_correct_prespast_acc', 'is_wrong_prespast_acc', 'accrued_score_prespast',
    ],
    'rt_perccont_prespast_bs': [
        'perc_vr_gt_fx_prespast_bs', 'change_fixed_prespast_bs', 'change_variable_prespast_bs', 'side_probed_prespast_bs',
        'stimulus_time_prespast_bs', 'is_correct_prespast_acc_bs', 'is_wrong_prespast_acc_bs', 'accrued_score_prespast_bs',
    ],
    'acc_perccont_prespast': [
        'perc_vr_gt_fx_prespast', 'change_fixed_prespast', 'change_variable_prespast', 'side_probed_prespast',
        'stimulus_time_prespast', 'is_correct_prespast_acc', 'is_wrong_prespast_acc', 'accrued_score_prespast',
    ],
    'acc_perccont_prespast_bs': [
        'perc_vr_gt_fx_prespast_bs', 'change_fixed_prespast_bs', 'change_variable_prespast_bs', 'side_probed_prespast_bs',
        'stimulus_time_prespast_bs', 'is_correct_prespast_acc_bs', 'is_wrong_prespast_acc_bs', 'accrued_score_prespast_bs',
    ],
    'rt_bothcont_prespast': [
        'reward_vr_fx_prespast', 'perc_vr_gt_fx_prespast', 'change_fixed_prespast', 'change_variable_prespast', 'side_probed_prespast',
        'stimulus_time_prespast', 'is_correct_prespast_acc', 'is_wrong_prespast_acc', 'accrued_score_prespast',
    ],
    'rt_bothcont_prespast_bs': [
        'reward_vr_fx_prespast_bs', 'perc_vr_gt_fx_prespast_bs', 'change_fixed_prespast_bs', 'change_variable_prespast_bs', 'side_probed_prespast_bs',
        'stimulus_time_prespast_bs', 'is_correct_prespast_acc_bs', 'is_wrong_prespast_acc_bs', 'accrued_score_prespast_bs',
    ],
    'rt_perccont_sansaccrued_prespast': [
        'perc_vr_gt_fx_prespast', 'change_fixed_prespast', 'change_variable_prespast', 'side_probed_prespast',
        'stimulus_time_prespast', 'is_correct_prespast_acc', 'is_wrong_prespast_acc',
    ],
    'rt_perccont_sansaccrued_prespast_bs': [
        'perc_vr_gt_fx_prespast_bs', 'change_fixed_prespast_bs', 'change_variable_prespast_bs', 'side_probed_prespast_bs',
        'stimulus_time_prespast_bs', 'is_correct_prespast_acc_bs', 'is_wrong_prespast_acc_bs',
    ],
    'acc_perccont_sansaccrued_prespast': [
        'perc_vr_gt_fx_prespast', 'change_fixed_prespast', 'change_variable_prespast', 'side_probed_prespast',
        'stimulus_time_prespast', 'is_correct_prespast_acc', 'is_wrong_prespast_acc',
    ],
    'acc_perccont_sansaccrued_prespast_bs': [
        'perc_vr_gt_fx_prespast_bs', 'change_fixed_prespast_bs', 'change_variable_prespast_bs', 'side_probed_prespast_bs',
        'stimulus_time_prespast_bs', 'is_correct_prespast_acc_bs', 'is_wrong_prespast_acc_bs',
    ],
    'rt_perccont_sansstimdura_prespast': [
        'perc_vr_gt_fx_prespast', 'change_fixed_prespast', 'change_variable_prespast', 'side_probed_prespast',
        'is_correct_prespast_acc', 'is_wrong_prespast_acc', 'accrued_score_prespast',
    ],
    'rt_perccont_sansstimdura_prespast_bs': [
        'perc_vr_gt_fx_prespast_bs', 'change_fixed_prespast_bs', 'change_variable_prespast_bs', 'side_probed_prespast_bs',
        'is_correct_prespast_acc_bs', 'is_wrong_prespast_acc_bs', 'accrued_score_prespast_bs',
    ],
    'acc_perccont_sansstimdura_prespast': [
        'perc_vr_gt_fx_prespast', 'change_fixed_prespast', 'change_variable_prespast', 'side_probed_prespast',
        'is_correct_prespast_acc', 'is_wrong_prespast_acc', 'accrued_score_prespast',
    ],
    'acc_perccont_sansstimdura_prespast_bs': [
        'perc_vr_gt_fx_prespast_bs', 'change_fixed_prespast_bs', 'change_variable_prespast_bs', 'side_probed_prespast_bs',
        'is_correct_prespast_acc_bs', 'is_wrong_prespast_acc_bs', 'accrued_score_prespast_bs',
    ],
    'rt_perccont_sansiswrong_prespast': [
        'perc_vr_gt_fx_prespast', 'change_fixed_prespast', 'change_variable_prespast', 'side_probed_prespast',
        'stimulus_time_prespast', 'is_correct_prespast_acc', 'accrued_score_prespast',
    ],
    'rt_perccont_sansiswrong_prespast_bs': [
        'perc_vr_gt_fx_prespast_bs', 'change_fixed_prespast_bs', 'change_variable_prespast_bs', 'side_probed_prespast_bs',
        'stimulus_time_prespast_bs', 'is_correct_prespast_acc_bs', 'accrued_score_prespast_bs',
    ],
}


def create_train_test_split_df():
    blocks = list(range(num_gain_blocks))
    indices = []
    for seed in seeds:
        random.seed(seed)
        for sub_num in range(num_subjects):
            perm = random.sample(blocks, k=num_gain_blocks)
            assert perm != blocks  # deliberately make sure the permutation is not same as the actual ordering
            indices.append({'seed': seed, 'sub_num': sub_num, 'perm': perm})
    df = pandas.DataFrame(indices)
    block_col_names = list(map(lambda b: f'block{b}', range(num_gain_blocks)))
    df[block_col_names] = df.perm.tolist()
    df.drop(columns=['perm'], inplace=True)
    df.to_json(data_dir + 'all_train_test_indices.json', orient='columns')


def get_train_test_split_df(seed):
    """Use the train test split made initially"""
    all_train_test_indices_df = pandas.read_json(data_dir + 'all_train_test_indices.json', orient='columns')
    all_train_test_indices_df.rename(columns={'sub_num': 'sub_emb'}, inplace=True)
    seed_filtered = all_train_test_indices_df.query(f'seed == {seed}')
    if seed_filtered.empty:
        raise Exception('Empty train test split')
    block_col_names = list(map(lambda b: f'block{b}', range(num_gain_blocks)))
    col_names = ['sub_emb'] + block_col_names
    return seed_filtered[col_names]


def create_subject_subsets():
    num_subj_per_subset = 4
    subjects = list(range(num_subjects))
    final_split = {}
    for seed in [0, 10, 20]:
        random.seed(seed)
        perm = random.sample(subjects, k=num_subjects)
        assert perm != subjects  # deliberately make sure the permutation is not same as the actual ordering
        subsets = {}
        for i, x in enumerate(range(0, num_subjects, num_subj_per_subset)):
            subsets[i] = perm[x: x + num_subj_per_subset]
        final_split[seed] = subsets
    return final_split


def add_seq_features(proc_df: pandas.DataFrame, T: int, shuffled_df: pandas.DataFrame):
    for feat in ['change_fixed', 'change_variable', 'side_probed', 'stimulus_time', 'accrued_score',
                 'reward_vr_fx', 'perc_vr_gt_fx',
                 'reward_yes_no', 'perc_yes_gt_no']:
        # =============== Actual Past & Actual Current input in LSTM ===============
        var = feat + '_prespast'

        proc_df[var] = [window.to_list() for window in proc_df[feat].rolling(T)]
        proc_df[var] = proc_df[var].shift(1).tolist()
        proc_df[var] = proc_df[[var, feat]].apply(lambda row: (row[var] if isinstance(row[var], list) else []) + [row[feat]], axis=1)

        # =============== Shuffled Past & Actual Current input in LSTM ===============
        var += '_bs'

        proc_df[var] = [window.to_list() for window in shuffled_df[feat].rolling(T)]
        proc_df[var] = proc_df[var].shift(1).tolist()
        proc_df[var] = proc_df[[var, feat]].apply(lambda row: (row[var] if isinstance(row[var], list) else []) + [row[feat]], axis=1)

    for feat in ['is_correct', 'is_wrong']:  # special for accuracy prediction
        # =============== Actual Past & Actual Current input in LSTM ===============
        var = feat + '_prespast_acc'

        proc_df[var] = [window.to_list() for window in proc_df[feat].rolling(T)]
        proc_df[var] = proc_df[var].shift(1).tolist()
        proc_df[var] = proc_df[[var, feat]].apply(lambda row: (row[var] if isinstance(row[var], list) else []) + [0], axis=1)

        # =============== Shuffled Past & Actual Current input in LSTM ===============
        var += '_bs'

        proc_df[var] = [window.to_list() for window in shuffled_df[feat].rolling(T)]
        proc_df[var] = proc_df[var].shift(1).tolist()
        proc_df[var] = proc_df[[var, feat]].apply(lambda row: (row[var] if isinstance(row[var], list) else []) + [0], axis=1)

    for col_name, col_list in prespast_columns.items():
        proc_df[col_name] = proc_df[col_list].apply(lambda row: numpy.array(row.values.tolist()).transpose().tolist(), axis=1)

    return proc_df


def process_one_block(num, block_df, T: int):
    # =============== Basic Processing ===============
    proc_df: pandas.DataFrame = block_df.copy().reset_index(drop=True)

    # =============== Embeddings ===============
    sub_num, gain_block_num = block_df.iloc[0][['sub_num', 'gain_block_num']]
    proc_df['sub_emb'] = sub_num
    proc_df['block_emb'] = gain_block_num

    # =============== Shuffled DataFrame ===============
    rng = numpy.random.default_rng(seed=num)
    shuffled_df = proc_df.copy()
    shuffled_index = rng.permutation(shuffled_df.index)
    shuffled_df = shuffled_df.reindex(shuffled_index)
    shuffled_df = shuffled_df.reset_index(drop=True)

    # =============== Add Sequential Features ===============
    proc_df = add_seq_features(proc_df, T, shuffled_df)

    # ============================================= Final processing =============================================
    proc_df = proc_df[final_columns].copy()
    raw_df = proc_df.copy()
    proc_df = proc_df.iloc[T:].copy()  # remove first T rows as they won't have past T trials
    return raw_df, proc_df


def read_data_and_preprocess(T: int, return_raw: bool, exp_type: str):
    data_df = pandas.read_json(data_dir + f'{exp_type}_data.json', orient='columns')

    raw_df_list, proc_df_list = [], []

    seed_everything(0, workers=True)

    with Pool(processes=10) as pool:
        results = []
        # count = 50
        # c = 0
        for num, (_, block_df) in tqdm(enumerate(data_df.groupby(['sub_num', 'gain_block_num'])), desc='Scheduling Block Processing'):
            result = pool.apply_async(process_one_block, (num, block_df, T))
            results.append(result)
            # c = c + 1
            # if c > count:
            #     break

        for result in tqdm(results, desc='Block Processing Results'):
            raw_df, proc_df = result.get(timeout=10)
            raw_df_list.append(raw_df), proc_df_list.append(proc_df)

    raw_df, proc_df = pandas.concat(raw_df_list, ignore_index=True), pandas.concat(proc_df_list, ignore_index=True)

    proc_df.set_index(['sub_emb', 'block_emb'], inplace=True)
    raw_df.set_index(['sub_emb', 'block_emb'], inplace=True)

    if return_raw:
        return raw_df, proc_df
    return proc_df
