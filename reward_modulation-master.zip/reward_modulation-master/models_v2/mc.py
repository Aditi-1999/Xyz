from models_v2.final import OnlyRTWithLSTMHistoryFinalV2, OnlyAccWithLSTMHistoryFinalV2, \
    OnlyRTWithLSTMHistoryFinalV2ReEncode, OnlyAccWithLSTMHistoryFinalV2ReEncode, \
    OnlyRTWithLSTMHistoryFinalV2ReEncodeV2, OnlyAccWithLSTMHistoryFinalV2ReEncodeV2, \
    OnlyRTWithGRUHistoryFinalV2, OnlyAccWithGRUHistoryFinalV2, \
    OnlyAccWithoutHistoryFinalV2, \
    OnlyRTWithLSTMHistoryFinalV2RemoveHistory, OnlyAccWithLSTMHistoryFinalV2RemoveHistory


class OnlyRTWithLSTMHistoryFinalV2MC(OnlyRTWithLSTMHistoryFinalV2):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def predict_step(self, batch, batch_idx):
        self.train()
        return super().predict_step(batch, batch_idx)


class OnlyAccWithLSTMHistoryFinalV2MC(OnlyAccWithLSTMHistoryFinalV2):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def predict_step(self, batch, batch_idx):
        self.train()
        return super().predict_step(batch, batch_idx)


class OnlyRTWithLSTMHistoryFinalV2ReEncodeMC(OnlyRTWithLSTMHistoryFinalV2ReEncode):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def predict_step(self, batch, batch_idx):
        self.train()
        return super().predict_step(batch, batch_idx)


class OnlyAccWithLSTMHistoryFinalV2ReEncodeMC(OnlyAccWithLSTMHistoryFinalV2ReEncode):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def predict_step(self, batch, batch_idx):
        self.train()
        return super().predict_step(batch, batch_idx)


class OnlyRTWithLSTMHistoryFinalV2ReEncodeV2MC(OnlyRTWithLSTMHistoryFinalV2ReEncodeV2):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def predict_step(self, batch, batch_idx):
        self.train()
        return super().predict_step(batch, batch_idx)


class OnlyAccWithLSTMHistoryFinalV2ReEncodeV2MC(OnlyAccWithLSTMHistoryFinalV2ReEncodeV2):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def predict_step(self, batch, batch_idx):
        self.train()
        return super().predict_step(batch, batch_idx)


class OnlyRTWithGRUHistoryFinalV2MC(OnlyRTWithGRUHistoryFinalV2):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def predict_step(self, batch, batch_idx):
        self.train()
        return super().predict_step(batch, batch_idx)


class OnlyAccWithGRUHistoryFinalV2MC(OnlyAccWithGRUHistoryFinalV2):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def predict_step(self, batch, batch_idx):
        self.train()
        return super().predict_step(batch, batch_idx)


class OnlyRTWithLSTMHistoryFinalV2RemoveHistoryMC(OnlyRTWithLSTMHistoryFinalV2RemoveHistory):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def predict_step(self, batch, batch_idx):
        self.train()
        return super().predict_step(batch, batch_idx)


class OnlyAccWithLSTMHistoryFinalV2RemoveHistoryMC(OnlyAccWithLSTMHistoryFinalV2RemoveHistory):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def predict_step(self, batch, batch_idx):
        self.train()
        return super().predict_step(batch, batch_idx)


class OnlyAccWithoutHistoryFinalV2MC(OnlyAccWithoutHistoryFinalV2):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def predict_step(self, batch, batch_idx):
        self.train()
        return super().predict_step(batch, batch_idx)
