import pandas
from config import project_dir
from utils_processing import mc_seeds
from scipy.stats import shapiro
from statsmodels.stats.diagnostic import lilliefors
import plotly.express as px


def mean_prediction_equality(result_dir):
    """Is the mean of predictions obtained with dropout on = Prediction obtained with dropout off? Ans: Yes"""
    drop_values = pandas.read_pickle(result_dir + f'dropout-values.pkl')
    mc_values = pandas.read_pickle(result_dir + f'mc-values.pkl')
    assert drop_values['rt_target'].tolist() == mc_values['rt_target'].tolist()

    mc_values['rt_pred_ex'] = drop_values['rt_pred'].tolist()
    pred_cols = list(map(lambda x: f'rt_pred_{x}', range(len(mc_seeds))))
    mc_values['rt_pred_mean'] = mc_values[pred_cols].mean(axis=1)

    fig = px.scatter(mc_values, x='rt_pred_mean', y='rt_pred_ex', trendline='ols',
                     labels={'rt_pred_mean': 'Mean of Predictions', 'rt_pred_ex': 'Prediction with Dropout off'})
    fig.show()


def check_normality(result_dir, dropout):
    """Are the predictions obtained with dropout on distributed normally, for each sample? Ans: For Most Samples"""
    mc_values: pandas.DataFrame = pandas.read_pickle(result_dir + f'mc-p={dropout}-test_values.pkl')
    pred_cols = list(map(lambda x: f'rt_pred_{x}', range(len(mc_seeds))))

    mc_values['p_shapiro'] = mc_values.apply(lambda row: shapiro(row[pred_cols].to_list()).pvalue, axis=1)
    mc_values['p_lillie'] = mc_values.apply(lambda row: lilliefors(row[pred_cols].to_list())[1], axis=1)

    fig = px.histogram(x=mc_values['p_shapiro'])
    fig.show()

    fig = px.histogram(x=mc_values['p_lillie'])
    fig.show()


def variance_histogram(result_dir, dropout):
    mc_values: pandas.DataFrame = pandas.read_pickle(result_dir + f'mc-p={dropout}-test_values.pkl')
    pred_cols = list(map(lambda x: f'rt_pred_{x}', range(len(mc_seeds))))
    mc_values['pred_var'] = mc_values[pred_cols].var(ddof=1, axis=1)

    print(f'Least Variance: {mc_values.pred_var.min()}')

    fig = px.histogram(mc_values, x='pred_var')
    fig.show()


if __name__ == '__main__':
    res_dir = project_dir + 'basic/results/sans_block_bs=64_maxep=100_rt/'
    mean_prediction_equality(res_dir)
    check_normality(res_dir, 0.2)
    check_normality(res_dir, 0.5)
    variance_histogram(res_dir, 0.2)
    variance_histogram(res_dir, 0.5)
