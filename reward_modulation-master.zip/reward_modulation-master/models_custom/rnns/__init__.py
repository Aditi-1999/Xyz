from typing import List
from torch import Tensor
import torch.nn as nn


def reverse(lst: List[Tensor]) -> List[Tensor]:
    return lst[::-1]


def init_stacked_rnn(layer, model):
    layers = nn.ModuleList()
    dirs = 2 if model.bidirectional else 1
    layers.append(layer(input_size=model.input_size, hidden_size=model.hidden_size, dropout=model.dropout))
    for _ in range(model.num_layers - 1):
        layers.append(layer(input_size=model.hidden_size * dirs, hidden_size=model.hidden_size, dropout=model.dropout))
    return layers


def reorder(x):
    return x.view([-1] + list(x.shape[2:]))
