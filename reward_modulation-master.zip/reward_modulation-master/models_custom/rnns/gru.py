import torch
from torch.nn import Parameter
from typing import List, Tuple, Optional
from torch import Tensor
from torch import device as Device, dtype as DType
import torch.nn as nn
from models_custom.rnns import reverse, init_stacked_rnn, reorder


class GRUCell(nn.Module):

    def __init__(self, input_size: int, hidden_size: int):
        super().__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.weight_ih = Parameter(torch.Tensor(3 * hidden_size, input_size))
        self.weight_hh = Parameter(torch.Tensor(3 * hidden_size, hidden_size))
        self.bias_ih = Parameter(torch.Tensor(3 * hidden_size))
        self.bias_hh = Parameter(torch.Tensor(3 * hidden_size))

    def forward(self,
                inpt: Tensor,  # N, I
                state: Tensor,  # N, H
                input_masks: Tensor,  # 3, N, I
                hidden_masks: Tensor,  # 3, N, H
                ) -> Tensor:  # N, H
        prev_h = state

        input_weights = self.weight_ih.reshape(3, self.hidden_size, self.input_size).permute((0, 2, 1))  # 3, I, H
        input_biases = self.bias_ih.reshape(3, 1, self.hidden_size)  # 3, 1, H
        hidden_weights = self.weight_hh.reshape(3, self.hidden_size, self.hidden_size).permute((0, 2, 1))  # 3, H, H
        hidden_biases = self.bias_hh.reshape(3, 1, self.hidden_size)  # 3, 1, H

        masked_input = torch.mul(inpt, input_masks)  # 3, N, I
        masked_hidden = torch.mul(prev_h, hidden_masks)  # 3, N, H

        input_side = torch.baddbmm(input_biases, masked_input, input_weights)  # 3, N, H
        hidden_side = torch.baddbmm(hidden_biases, masked_hidden, hidden_weights)  # 3, N, H

        reset_gate = torch.sigmoid(input_side[0, :, :] + hidden_side[0, :, :])  # N, H
        update_gate = torch.sigmoid(input_side[1, :, :] + hidden_side[1, :, :])  # N, H
        new_gate = torch.tanh(input_side[2, :, :] + reset_gate * hidden_side[2, :, :])  # N, H
        new_h = (1 - update_gate) * new_gate + update_gate * prev_h  # N, H

        return new_h


class CoreGRULayer(nn.Module):

    def __init__(self, dropout: float, **cell_kwargs):
        super().__init__()
        assert 0 <= dropout < 1
        self.dropout = dropout
        self.cell = GRUCell(**cell_kwargs)

    def get_dropout_masks(self, batch_size: int, input_size: int, hidden_size: int, device: Device, dtype: DType):
        input_masks = torch.ones((3, batch_size, input_size), device=device, dtype=dtype)  # 3, N, I
        hidden_masks = torch.ones((3, batch_size, hidden_size), device=device, dtype=dtype)  # 3, N, H
        if self.training and self.dropout > 0:
            keep_prob = 1 - self.dropout
            # sample dropout once for the sequence & scale (inverted dropout method)
            return torch.bernoulli(input_masks * keep_prob) / keep_prob, torch.bernoulli(hidden_masks * keep_prob) / keep_prob
        else:
            # no dropout & no scaling
            return input_masks, hidden_masks

    def forward(self,
                inputs: List[Tensor],  # N, I of length T
                state: Tensor  # N, H
                ) -> Tuple[List[Tensor], Tensor]:  # N, T, H & N, H
        batch_size = inputs[0].size(dim=0)
        device, dtype = inputs[0].device, inputs[0].dtype
        input_size, hidden_size = self.cell.input_size, self.cell.hidden_size
        input_masks, hidden_masks = self.get_dropout_masks(batch_size, input_size, hidden_size, device, dtype)
        outputs: List[Tensor] = []
        for i in range(len(inputs)):
            state = self.cell(inputs[i], state, input_masks, hidden_masks)
            outputs += [state]
        return outputs, state


class GRULayer(nn.Module):

    def __init__(self, **core_kwargs):
        super().__init__()
        self.core_layer = CoreGRULayer(**core_kwargs)

    def forward(self,
                inpt: Tensor,  # N, T, I
                state: Tensor  # N, H
                ) -> Tuple[Tensor, Tensor]:  # N, T, H & All N, H
        inputs = inpt.unbind(1)  # split on time axis
        outputs, state = self.core_layer(inputs, state)
        return torch.stack(outputs, dim=1), state


class ReverseGRULayer(nn.Module):

    def __init__(self, **core_kwargs):
        super().__init__()
        self.core_layer = CoreGRULayer(**core_kwargs)

    def forward(self,
                inpt: Tensor,  # N, T, I
                state: Tensor  # N, H
                ) -> Tuple[Tensor, Tensor]:  # N, T, H & All N, H
        inputs = reverse(inpt.unbind(1))  # split on time axis
        outputs, state = self.core_layer(inputs, state)
        return torch.stack(reverse(outputs), dim=1), state


class BiDirGRULayer(nn.Module):

    def __init__(self, **core_kwargs):
        super().__init__()
        self.directions = nn.ModuleList(
            [
                GRULayer(**core_kwargs),
                ReverseGRULayer(**core_kwargs),
            ]
        )

    def forward(self,
                inpt: Tensor,  # N, T, I
                states: Tensor  # 2, N, H
                ) -> Tuple[Tensor, List[Tensor]]:  # N, T, 2H & All N, H
        outputs: List[Tensor] = []
        output_states: List[Tensor] = []
        for i, direction in enumerate(self.directions):
            state = states[i, :, :]
            out, out_state = direction(inpt, state)
            outputs += [out]
            output_states += [out_state]
        return torch.cat(outputs, -1), output_states


class StackedUniGRU(nn.Module):

    def __init__(self, input_size, hidden_size, num_layers, dropout):
        super().__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.bidirectional = False
        self.dropout = dropout
        self.layers = init_stacked_rnn(GRULayer, self)

    def forward(self,
                inpt: Tensor,  # N, T, I
                states: Optional[Tensor] = None  # L, N, H
                ) -> Tuple[Tensor, Tensor]:  # N, T, H & L, N, H
        output_states: List[Tensor] = []
        output = inpt
        batch_size = inpt.size(dim=0)
        if states is None:
            device, dtype = inpt.device, inpt.dtype
            zeros = torch.zeros((self.num_layers, batch_size, self.hidden_size), device=device, dtype=dtype)
            states = zeros
        for i, rnn_layer in enumerate(self.layers):
            state = states[i, :, :]
            output, out_state = rnn_layer(output, state)
            output_states += [out_state]
        return output, torch.stack(output_states)


class StackedBiGRU(nn.Module):

    def __init__(self, input_size, hidden_size, num_layers, dropout):
        super().__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.bidirectional = True
        self.dropout = dropout
        self.layers = init_stacked_rnn(BiDirGRULayer, self)

    def forward(self,
                inpt: Tensor,  # N, T, I
                states: Optional[Tensor] = None  # 2L, N, H
                ) -> Tuple[Tensor, Tensor]:  # N, T, 2H & 2L, N, H
        output_states: List[List[Tensor]] = []
        output = inpt
        batch_size = inpt.size(dim=0)
        if states is None:
            device, dtype = inpt.device, inpt.dtype
            zeros = torch.zeros((2 * self.num_layers, batch_size, self.hidden_size), device=device, dtype=dtype)
            states = zeros
        for i, rnn_layer in enumerate(self.layers):
            state = states[2 * i:2 * i + 2, :, :]
            output, out_state = rnn_layer(output, state)
            output_states += [out_state]

        first_flatten: List[Tensor] = []
        for inner in output_states:
            first_flatten.append(torch.stack(inner))
        second_flatten = torch.stack(first_flatten)
        return output, reorder(second_flatten)


def variational_gru(
    input_size: int,
    hidden_size: int,
    num_layers: int,
    bidirectional: bool,
    dropout: float,
):
    """
    Returns a ScriptModule implementation of GRU based on Variational LSTM
    (Ref: https://papers.nips.cc/paper_files/paper/2016/hash/076a0c97d09cf1a0ec3e19c7f2529f2b-Abstract.html)
    When dropout=0, it behaves like PyTorch's GRU (with dropout=0)
    Dropout probability is tied i.e., one dropout value for all layers
    """
    stack_type = StackedBiGRU if bidirectional else StackedUniGRU
    module = stack_type(
        input_size=input_size,
        hidden_size=hidden_size,
        num_layers=num_layers,
        dropout=dropout,
    )
    return torch.jit.script(module)
