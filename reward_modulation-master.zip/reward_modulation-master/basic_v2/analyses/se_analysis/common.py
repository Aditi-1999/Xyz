from utils_data import num_subjects
from sklearn.linear_model import LinearRegression

cols = list(map(lambda x: f'x{x}', range(1, 6)))


def make_se_predictions(df_subj):
    assert len(df_subj) == num_subjects
    predictions = []
    for sub in range(num_subjects):
        train_data = df_subj[df_subj.subject != sub]
        test_data = df_subj[df_subj.subject == sub]
        lr = LinearRegression()
        lr.fit(X=train_data[cols], y=train_data['target'])
        pred = lr.predict(X=test_data[cols])[0].item()
        predictions.append(pred)
    df_subj['pred'] = predictions
    return df_subj
