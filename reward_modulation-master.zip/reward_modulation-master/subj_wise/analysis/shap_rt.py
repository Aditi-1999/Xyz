import os.path
import shap
import pandas
import numpy
import torch
from tqdm import tqdm
from utils_processing import seeds
from config import project_dir
import torch.nn.functional as f
from subj_wise.analysis.model_choose import get_all_results, best_hyper_config
from models.base import WithHistoryBase
from torch.utils.data import DataLoader, TensorDataset
from utils_data import num_gain_blocks
from utils_processing.common_proc import get_train_test_split_df, read_data_and_preprocess, prespast_columns
from torch.nn import Parameter
from multiprocessing import get_context
from utils_training.training_rt import make_predictions
from subj_wise import rt_subjects

task_vars = ['reward_vr_fx', 'change_fx', 'change_vr', 'side_probed', 'stimulus_time', 'is_correct', 'is_wrong',
             'accrued_score']
lstm_vars = prespast_columns['rt_prespast']


class SHAPForRT(WithHistoryBase):

    def __init__(self, T, rnn_input_size, rnn_hidden_size, rnn_layers, rnn_bidirectional, rnn_initial, **kwargs):
        super(SHAPForRT, self).__init__(rnn_input_size=rnn_input_size, rnn_hidden_size=rnn_hidden_size,
                                        rnn_layers=rnn_layers, rnn_bidirectional=rnn_bidirectional, rnn_initial=rnn_initial,
                                        num_subjects=0, num_blocks=0, sub_emb_dim=0, block_emb_dim=0,
                                        output_size=1, output_activation_func=None,
                                        **kwargs)

        if rnn_initial != 'none':
            raise NotImplemented

        self.rnn_input_size = rnn_input_size
        self.rnn_initial = rnn_initial
        self.T = T

        tot_rnn_layers = (2 if rnn_bidirectional else 1) * rnn_layers
        self.h_0 = Parameter(torch.zeros(tot_rnn_layers, rnn_hidden_size), requires_grad=False)
        self.c_0 = Parameter(torch.zeros(tot_rnn_layers, rnn_hidden_size), requires_grad=False)

        self.double()

    def form_lstm_inp(self, lstm_inp_flattened):
        N = lstm_inp_flattened.shape[0]
        return torch.reshape(lstm_inp_flattened, (N, self.rnn_input_size, self.T + 1)).transpose(1, 2)

    def forward(self, lstm_inp_flattened):
        lstm_inp = self.form_lstm_inp(lstm_inp_flattened)

        N = lstm_inp.shape[0]
        h_0 = self.h_0.unsqueeze(1).repeat(1, N, 1)
        c_0 = self.c_0.unsqueeze(1).repeat(1, N, 1)

        concatenate_list = [
            self._get_lstm_output(self.subject_history, lstm_inp, (h_0, c_0)),
        ]
        op = torch.cat(concatenate_list, dim=1)
        op = self._forward_internal_layers(op)
        op = self._forward_output_layer(op)
        return op

    def _common_step(self, batch, btype):
        pass

    def predict_step(self, batch, batch_idx):
        pass


def get_tensors(section_df, lstm_inp_flat):
    """Get tensors that will be fed into a TensorDataset"""
    return [
        torch.tensor(section_df[lstm_inp_flat].values, dtype=torch.float64).double(),
    ]


def get_background(data_df, test_idxs, lstm_cols):
    train_df = data_df.loc[~data_df.index.isin(test_idxs)].copy().reset_index()
    train_dataset = TensorDataset(*get_tensors(train_df, lstm_cols))
    train_dataloader = DataLoader(train_dataset, batch_size=1000, shuffle=True)
    return train_df, next(iter(train_dataloader))


def get_test(data_df, test_idxs, lstm_cols):
    test_df = data_df.loc[data_df.index.isin(test_idxs)].copy().reset_index()
    test_dataset = TensorDataset(*get_tensors(test_df, lstm_cols))
    test_dataloader = DataLoader(test_dataset, batch_size=len(test_df), shuffle=False)
    return test_df, next(iter(test_dataloader))


def get_actual_test(test_df, lstm_variable):
    test_tensors = [
        torch.tensor(test_df[lstm_variable].values.tolist(), dtype=torch.float64).double(),
        torch.tensor(test_df.sub_emb.tolist()).long(),
        torch.tensor(test_df.block_emb.tolist()).long(),
    ]
    test_dataset = TensorDataset(*test_tensors)
    test_dataloader = DataLoader(test_dataset, batch_size=len(test_df), shuffle=False)
    return next(iter(test_dataloader))


def get_func_from_str(func_name):
    if func_name == 'relu':
        return f.relu
    if func_name == 'selu':
        return f.selu
    if func_name == 'sigmoid':
        return torch.sigmoid
    if func_name == 'tanh':
        return torch.tanh
    if func_name == 'gelu':
        return f.gelu
    if func_name == 'hardtanh':
        return f.hardtanh
    if func_name is None:
        return None
    raise Exception('Unknown activation function')


def correctness_check(shap_model, shap_test, trial, seed, b):
    shap_predictions = shap_model(*shap_test).detach().numpy()[:, 0]
    actual_predictions = pandas.read_pickle(trial['folder_path'] + 'values.pkl').rt_pred.values
    try:
        assert numpy.array_equal(shap_predictions, actual_predictions)
    except AssertionError:
        assert numpy.array_equal(shap_predictions.round(10),
                                 actual_predictions.round(10)), f'Assertion Error for {seed}, {b}'


def process_one_model(seed, b, model_class, trial, data_df, T):
    config = trial['user_attrs_config']
    time_steps = list(range(0, T + 1))

    # Create SHAP model
    actual_model = model_class.load_from_checkpoint(trial['folder_path'] + 'best.ckpt')

    model = SHAPForRT(T=T, rnn_input_size=model_class.E, rnn_hidden_size=config['rnn_hidden_size'],
                      rnn_layers=config['rnn_layers'], rnn_bidirectional=config['rnn_bidirectional'],
                      rnn_initial=config['rnn_initial'], rnn_init_hidden_sizes=config['rnn_init_hidden_sizes'],
                      rnn_init_activation_func=get_func_from_str(config['rnn_init_activation_func']),
                      rnn_init_output_activation_func=get_func_from_str(config['rnn_init_output_activation_func']),
                      hidden_sizes=config['hidden_sizes'], activation_func=get_func_from_str(config['activation_func']),
                      dropout=config['dropout'],
                      lr=0, cycle_lr=False, cycle_config={}, exp_lr=False, l2reg=False, l2weight=0, mseed=0)
    model.subject_history.load_state_dict(actual_model.subject_history.state_dict())
    model.internal_layers.load_state_dict(actual_model.internal_layers.state_dict())
    model.output_layer.load_state_dict(actual_model.output_layer.state_dict())

    # Prepare data
    lstm_cols = []
    for task_var, lstm_var in zip(task_vars, lstm_vars):
        new_names = list(map(lambda x: f'{task_var}{x}', time_steps))
        data_df[new_names] = pandas.DataFrame(data_df[lstm_var].tolist(), index=data_df.index)
        lstm_cols.extend(new_names)

    # Prepare background and test for SHAP
    train_test_split_df = get_train_test_split_df(seed)
    test_block = 'block{}'.format(b)
    test_idxs = list(train_test_split_df[['sub_emb', test_block]].itertuples(index=False, name=None))

    _, background = get_background(data_df, test_idxs, lstm_cols)
    test_df, test = get_test(data_df, test_idxs, lstm_cols)

    # Correctness check
    correctness_check(model, test, trial, seed, b)

    # Get SHAP values
    model = model.float()
    background = [x.float() for x in background]
    test = [x.float() for x in test]

    e = shap.GradientExplainer(model, background)
    shap_values = e.shap_values(test)

    lstm_var_df = pandas.DataFrame(test[0].detach().numpy(), columns=lstm_cols)

    lstm_shap_cols = list(map(lambda x: x + '_shap', lstm_cols))

    lstm_shap_df = pandas.DataFrame(shap_values, columns=lstm_shap_cols)

    concatenate_df = pandas.concat([lstm_var_df, lstm_shap_df], axis=1)
    concatenate_df['seed'] = seed
    concatenate_df['b'] = b
    concatenate_df['sub_num'] = config['sub_num']
    return concatenate_df


def get_shap_values(model_class, seed_list, prefix, bs, num_epochs, T):

    def trial_filter(d):
        return d['T'] == T

    all_results_df = get_all_results(seed_list=seed_list, prefix=prefix, bs=bs, num_epochs=num_epochs,
                                     trial_filter=trial_filter, metric='rt')
    trials = best_hyper_config(all_results_df)
    trials['btest'] = trials.user_attrs_config.apply(lambda d: d['btest'])

    proc_df = read_data_and_preprocess(T, return_raw=False)
    proc_df.dropna(subset=['response_time'], inplace=True)

    value_dfs = []
    for seed in seed_list:
        for b in range(num_gain_blocks):
            btest = b
            bval = (btest + 1) % num_gain_blocks

            for sub_num in rt_subjects:

                # Get appropriate run
                fil_trials = trials.query(f'seed == {seed} & btest == {b} & sub_num == {sub_num}').copy()
                assert len(fil_trials) == 1
                trial = fil_trials.iloc[0].to_dict()

                sub_df = proc_df.query(f'sub_num == {sub_num}').copy()

                if os.path.exists(trial['folder_path'] + 'values.pkl'):
                    values_df = pandas.read_pickle(trial['folder_path'] + 'values.pkl')
                else:
                    actual_model = model_class.load_from_checkpoint(trial['folder_path'] + 'best.ckpt')
                    values_df, _ = make_predictions(actual_model, seed, btest, bval, bs, num_epochs, sub_df, [0])
                    values_df.to_pickle(trial['folder_path'] + 'values.pkl')

                value_dfs.append(values_df)

    all_values_df = pandas.concat(value_dfs, ignore_index=True)

    shap_dfs = []
    with get_context('spawn').Pool(processes=5) as pool:
        results = []
        for seed in tqdm(seed_list, desc='Seed Dispatch'):
            for b in tqdm(range(num_gain_blocks), desc='Block Dispatch'):
                for sub_num in rt_subjects:
                    sub_df = proc_df.query(f'sub_num == {sub_num}').copy()
                    trial = trials.query(f'seed == {seed} & btest == {b} & sub_num == {sub_num}').iloc[0].to_dict()
                    result = pool.apply_async(process_one_model, (seed, b, model_class, trial, sub_df.copy(), T))
                    results.append(result)

        for result in tqdm(results, desc='Parallel Results'):
            concatenate_df = result.get(timeout=None)  # should we put a timelimit?
            shap_dfs.append(concatenate_df)

    all_shap_df = pandas.concat(shap_dfs)

    time_steps = list(range(0, T + 1))
    for time in time_steps:
        cols = list(map(lambda v: f'{v}{time}_shap', task_vars))
        all_shap_df[f't{time}_shap'] = all_shap_df[cols].sum(axis=1)

    for var in task_vars:
        cols = list(map(lambda t: f'{var}{t}_shap', time_steps))
        all_shap_df[f'{var}_shap'] = all_shap_df[cols].sum(axis=1)

    folder_name = f'{prefix}_bs={bs}_maxep={num_epochs}_rt'
    all_shap_df.to_csv(project_dir + f'subj_wise/results/{folder_name}/T={T}-shap_gradient.csv', index=False)
    with open(project_dir + f'subj_wise/results/{folder_name}/hyper_config-T={T}.txt', 'w') as f:
        f.write(trial['hyper_config'])
    all_values_df.to_pickle(project_dir + f'subj_wise/results/{folder_name}/bestHyper-T={T}-values.pkl')


if __name__ == '__main__':
    from models.final import OnlyRTWithHistoryBasicFinal
    get_shap_values(OnlyRTWithHistoryBasicFinal, [0], 'subj_wise', 32, 100, T=3)
    get_shap_values(OnlyRTWithHistoryBasicFinal, [0, 10, 20], 'subj_wise_nohist_lstm', 32, 100, T=0)
