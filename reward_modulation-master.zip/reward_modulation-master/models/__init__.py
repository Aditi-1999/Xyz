from functools import partial
from torch.nn import Dropout, AlphaDropout
import torch.nn.functional as f
from torch.nn import init
import torch
from typing import Optional


def choose_init_function(activation_func):
    if activation_func == f.relu:
        return partial(init.kaiming_normal_, nonlinearity='relu')
    if activation_func == f.selu:
        return partial(init.kaiming_normal_, nonlinearity='linear')
    if activation_func == torch.sigmoid:
        return init.xavier_uniform_
    if activation_func == torch.tanh:
        return init.xavier_uniform_
    if activation_func == f.gelu:
        return init.orthogonal_
    if activation_func == f.hardtanh:
        return init.xavier_uniform_
    if activation_func is None:
        return init.xavier_uniform_
    raise Exception("Unknown activation function")


def choose_dropout_function(activation_func):
    if activation_func == f.relu:
        return Dropout
    if activation_func == f.selu:
        return AlphaDropout
    if activation_func == torch.sigmoid:
        return Dropout
    if activation_func == torch.tanh:
        return Dropout
    if activation_func == f.gelu:
        return Dropout
    if activation_func == f.hardtanh:
        return Dropout
    if activation_func is None:
        return Dropout
    raise Exception("Unknown activation function")


def choose_function(func_name: Optional[str]):
    if func_name == 'relu':
        return f.relu
    if func_name == 'selu':
        return f.selu
    if func_name == 'sigmoid':
        return torch.sigmoid
    if func_name == 'tanh':
        return torch.tanh
    if func_name == 'gelu':
        return f.gelu
    if func_name == 'hardtanh':
        return f.hardtanh
    if func_name is None:
        return None
    raise Exception("Unknown activation function")
