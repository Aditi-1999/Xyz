import argparse
from basic.process_acc.processor_acc_sans_block import execute_study
from models.final import OnlyAccWithHistoryBasicFinal
from utils_generic import send_message


if __name__ == '__main__':
    bs = 64
    num_epochs = 100
    prefix = 'sans_block'

    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', dest='seed', type=int)
    parser.add_argument('--btest', dest='btest', type=int)
    parser.add_argument('--gpu', dest='gpu', type=int, default=0)
    args = parser.parse_args()

    execute_study(OnlyAccWithHistoryBasicFinal, args.seed, args.btest, bs, num_epochs, prefix, [args.gpu], 'gain_d')

    send_message(f'Acc SansBlock - {prefix} for {args} Finished')
