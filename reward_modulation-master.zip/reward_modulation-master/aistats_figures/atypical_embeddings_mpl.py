from aistats_figures import rt_file, acc_file, get_sub_metrics, color, data_dir, p_text
from utils_processing.metrics import compute_robust_corr
from matplotlib.axes import Axes
from numpy.typing import NDArray
import matplotlib.pyplot as plt
from config import project_dir
import pandas
import numpy

point_size = 250
font_size = 15
lfont_size = 17


def get_rt_metrics(rt_fname, experiment):
    values = rt_file(rt_fname)
    corr = get_sub_metrics(values, experiment=experiment, metric='rt', measure='corr', shuffled=False)
    corr.name = 'corr'
    mse = get_sub_metrics(values, experiment=experiment, metric='rt', measure='mse', shuffled=False)
    mse.name = 'mse'
    return pandas.DataFrame([corr, mse]).transpose()


def get_all_rt_metrics(experiment):
    bisann = get_rt_metrics(data_dir + experiment + '/bisann_rt.pkl', experiment=experiment)
    sanspe = get_rt_metrics(data_dir + experiment + '/sanspe_rt.pkl', experiment=experiment)
    median = get_rt_metrics(data_dir + experiment + '/median_rt.pkl', experiment=experiment)
    dist = pandas.read_pickle(data_dir + experiment + '/bisann_l2dist_rt.pkl')
    dist['sp_delta'] = bisann['mse'] - sanspe['mse']
    dist['me_delta'] = bisann['mse'] - median['mse']
    return dist


def get_acc_metrics(acc_fname, experiment):
    values = acc_file(acc_fname)
    auroc = get_sub_metrics(values, experiment=experiment, metric='acc', measure='auroc', shuffled=False)
    auroc.name = 'auroc'
    bce = get_sub_metrics(values, experiment=experiment, metric='acc', measure='bce', shuffled=False)
    bce.name = 'bce'
    return pandas.DataFrame([auroc, bce]).transpose()


def get_all_acc_metrics(experiment):
    bisann = get_acc_metrics(data_dir + experiment + '/bisann_acc.pkl', experiment=experiment)
    sanspe = get_acc_metrics(data_dir + experiment + '/sanspe_acc.pkl', experiment=experiment)
    median = get_acc_metrics(data_dir + experiment + '/median_acc.pkl', experiment=experiment)
    dist = pandas.read_pickle(data_dir + experiment + '/bisann_l2dist_acc.pkl')
    dist['sp_delta'] = bisann['bce'] - sanspe['bce']
    dist['me_delta'] = bisann['bce'] - median['bce']
    return dist


def plot_metrics(ax: Axes, xrange, yrange, ylabel, xticks, yticks, dist, experiment, showlegend, text_pos,
                 showxlabel):
    new_name = 'SRC' if experiment == 'srm' else 'SPC'
    ax.scatter(x=dist['l2_median'], y=dist['sp_delta'], alpha=0.7,
               color=color[experiment], marker='o', s=point_size,
               label=f'SansPE - {new_name}' if showlegend else None)
    ax.scatter(x=dist['l2_median'], y=dist['me_delta'],
               color=color[experiment], marker='o', s=point_size, facecolor='white',
               label=f'Median - {new_name}' if showlegend else None)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.set_xlim(*xrange)
    ax.set_ylim(*yrange)
    if showxlabel:
        ax.set_xlabel('L2 Distance from Median Embedding', fontsize=font_size)
    ax.set_ylabel(ylabel, fontsize=font_size)
    ax.set_xticks(xticks)
    ax.set_yticks(yticks)
    for tick in ax.get_xticklabels() + ax.get_yticklabels():
        tick.set_fontsize(font_size)

    corr = compute_robust_corr(dist, 'l2_median', 'sp_delta')
    sp_corr = corr['corr']
    sp_val = p_text(corr['pval'])
    corr = compute_robust_corr(dist, 'l2_median', 'me_delta')
    me_corr = corr['corr']
    me_pval = p_text(corr['pval'])

    text = f'R.Corr(SansPE) = {sp_corr:.3f}; {sp_val}\n' \
           f'R.Corr(Median) = {me_corr:.3f}; {me_pval}'
    ax.text(*text_pos, s=text, ha='left', va='center', fontsize=16)


def make_rt_subplots(axs: NDArray[Axes]):  # two column axes for first row
    dist = get_all_rt_metrics(experiment='srm')
    plot_metrics(axs[0], [0.25, 1], [-0.15, 0.05], 'MSE(PRERNA) - MSE(Control)',
                 numpy.arange(0.25, 1, 0.2), numpy.arange(-0.15, 0.05, 0.05),
                 dist, 'srm', True, (0.3, -0.125), False)
    dist = get_all_rt_metrics(experiment='tms')
    plot_metrics(axs[1], [0.4, 2.2], [-0.7, 0.05], '',
                 numpy.arange(0.4, 2.2, 0.4), numpy.arange(-0.7, 0.05, 0.2),
                 dist, 'tms', True, (0.5, -0.55), False)


def make_acc_subplots(axs: NDArray[Axes]):  # two column axes for second row
    dist = get_all_acc_metrics(experiment='srm')
    plot_metrics(axs[0], [0.3, 1.7], [-0.25, 0.05], 'BCE(PRERNA) - BCE(Control)',
                 numpy.arange(0.3, 1.7, 0.4), numpy.arange(-0.25, 0.05, 0.1),
                 dist, 'srm', False, (0.35, -0.2), True)
    dist = get_all_acc_metrics(experiment='tms')
    plot_metrics(axs[1], [0.2, 1.8], [-0.1, 0.03], '',
                 numpy.arange(0.2, 1.8, 0.4), numpy.arange(-0.1, 0.05, 0.05),
                 dist, 'tms', False, (0.25, -0.055), True)


def plot():
    plt.rcParams['axes.unicode_minus'] = False
    plt.rcParams['font.sans-serif'] = "Arial"
    plt.rcParams['font.family'] = "sans-serif"
    fig, axs = plt.subplots(2, 2, figsize=(11, 11))

    make_rt_subplots(axs[0])
    make_acc_subplots(axs[1])

    fig.text(0.01, 0.95, "A", fontweight='bold', ha='left', va='center', fontsize=lfont_size)
    fig.text(0.5, 0.95, "B", fontweight='bold', ha='left', va='center', fontsize=lfont_size)

    fig.text(0.01, 0.475, "C", fontweight='bold', ha='left', va='center', fontsize=lfont_size)
    fig.text(0.5, 0.475, "D", fontweight='bold', ha='left', va='center', fontsize=lfont_size)

    legend = fig.legend(loc='upper right', bbox_to_anchor=(1, 1), ncol=4,
                        borderaxespad=0, bbox_transform=fig.transFigure)
    # legend.get_frame().set_visible(False)
    for legend_text in legend.get_texts():
        legend_text.set_fontsize(font_size)

    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.savefig(project_dir + 'aistats_figures/plots/atypical_embeddings2.png', dpi=400)
    # plt.show()


if __name__ == '__main__':
    plot()
